<script>
    canvas2.add(new fabric.Polygon([{
            x: 0.0,
            y: 0.0
        },
        {
            x: 0.0,
            y: 62.5
        },
        {
            x: 63.0,
            y: 62.5
        },
        {
            x: 63.0,
            y: 0.0
        },
    ], {
        fill: green,
        id: 'x2id1'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 137.0,
            y: 0.0
        },
        {
            x: 74.0,
            y: 0.0
        },
        {
            x: 74.0,
            y: 62.5
        },
        {
            x: 137.0,
            y: 62.5
        },
        {
            x: 137.0,
            y: 0.0
        },
    ], {
        fill: green,
        id: 'x2id2'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 211.0,
            y: 0.0
        },
        {
            x: 148.0,
            y: 0.0
        },
        {
            x: 148.0,
            y: 62.5
        },
        {
            x: 211.0,
            y: 62.5
        },
        {
            x: 211.0,
            y: 0.0
        },
    ], {
        fill: green,
        id: 'x2id3'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 285.0,
            y: 0.0
        },
        {
            x: 222.0,
            y: 0.0
        },
        {
            x: 222.0,
            y: 62.5
        },
        {
            x: 285.0,
            y: 62.5
        },
        {
            x: 285.0,
            y: 0.0
        },
    ], {
        fill: green,
        id: 'x2id4'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 359.0,
            y: 0.0
        },
        {
            x: 296.0,
            y: 0.0
        },
        {
            x: 296.0,
            y: 62.5
        },
        {
            x: 359.0,
            y: 62.5
        },
        {
            x: 359.0,
            y: 0.0
        },
    ], {
        fill: green,
        id: 'x2id5'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 433.0,
            y: 0.0
        },
        {
            x: 370.0,
            y: 0.0
        },
        {
            x: 370.0,
            y: 62.5
        },
        {
            x: 433.0,
            y: 62.5
        },
        {
            x: 433.0,
            y: 0.0
        },
    ], {
        fill: green,
        id: 'x2id6'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 507.0,
            y: 0.0
        },
        {
            x: 444.0,
            y: 0.0
        },
        {
            x: 444.0,
            y: 62.5
        },
        {
            x: 507.0,
            y: 62.5
        },
        {
            x: 507.0,
            y: 0.0
        },
    ], {
        fill: green,
        id: 'x2id7'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 581.0,
            y: 0.0
        },
        {
            x: 518.0,
            y: 0.0
        },
        {
            x: 518.0,
            y: 62.5
        },
        {
            x: 581.0,
            y: 62.5
        },
        {
            x: 581.0,
            y: 0.0
        },
    ], {
        fill: green,
        id: 'x2id8'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 655.0,
            y: 0.0
        },
        {
            x: 592.0,
            y: 0.0
        },
        {
            x: 592.0,
            y: 62.5
        },
        {
            x: 655.0,
            y: 62.5
        },
        {
            x: 655.0,
            y: 0.0
        },
    ], {
        fill: green,
        id: 'x2id9'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 729.0,
            y: 0.0
        },
        {
            x: 666.0,
            y: 0.0
        },
        {
            x: 666.0,
            y: 62.5
        },
        {
            x: 729.0,
            y: 62.5
        },
        {
            x: 729.0,
            y: 0.0
        },
    ], {
        fill: green,
        id: 'x2id10'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 803.0,
            y: 0.0
        },
        {
            x: 740.0,
            y: 0.0
        },
        {
            x: 740.0,
            y: 62.5
        },
        {
            x: 803.0,
            y: 62.5
        },
        {
            x: 803.0,
            y: 0.0
        },
    ], {
        fill: green,
        id: 'x2id11'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 877.0,
            y: 0.0
        },
        {
            x: 814.0,
            y: 0.0
        },
        {
            x: 814.0,
            y: 62.5
        },
        {
            x: 877.0,
            y: 62.5
        },
        {
            x: 877.0,
            y: 0.0
        },
    ], {
        fill: green,
        id: 'x2id12'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 951.0,
            y: 0.0
        },
        {
            x: 888.0,
            y: 0.0
        },
        {
            x: 888.0,
            y: 62.5
        },
        {
            x: 951.0,
            y: 62.5
        },
        {
            x: 951.0,
            y: 0.0
        },
    ], {
        fill: green,
        id: 'x2id13'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 1025.0,
            y: 0.0
        },
        {
            x: 962.0,
            y: 0.0
        },
        {
            x: 962.0,
            y: 62.5
        },
        {
            x: 1025.0,
            y: 62.5
        },
        {
            x: 1025.0,
            y: 0.0
        },
    ], {
        fill: green,
        id: 'x2id14'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 1099.0,
            y: 0.0
        },
        {
            x: 1036.0,
            y: 0.0
        },
        {
            x: 1036.0,
            y: 62.5
        },
        {
            x: 1099.0,
            y: 62.5
        },
        {
            x: 1099.0,
            y: 0.0
        },
    ], {
        fill: green,
        id: 'x2id15'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 63.0,
            y: 73.5
        },
        {
            x: 0.0,
            y: 73.5
        },
        {
            x: 0.0,
            y: 136.0
        },
        {
            x: 63.0,
            y: 136.0
        },
        {
            x: 63.0,
            y: 73.5
        },
    ], {
        fill: green,
        id: 'x2id16'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 137.0,
            y: 73.5
        },
        {
            x: 74.0,
            y: 73.5
        },
        {
            x: 74.0,
            y: 136.0
        },
        {
            x: 137.0,
            y: 136.0
        },
        {
            x: 137.0,
            y: 73.5
        },
    ], {
        fill: green,
        id: 'x2id17'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 211.0,
            y: 73.5
        },
        {
            x: 148.0,
            y: 73.5
        },
        {
            x: 148.0,
            y: 136.0
        },
        {
            x: 211.0,
            y: 136.0
        },
        {
            x: 211.0,
            y: 73.5
        },
    ], {
        fill: green,
        id: 'x2id18'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 285.0,
            y: 73.5
        },
        {
            x: 222.0,
            y: 73.5
        },
        {
            x: 222.0,
            y: 136.0
        },
        {
            x: 285.0,
            y: 136.0
        },
        {
            x: 285.0,
            y: 73.5
        },
    ], {
        fill: green,
        id: 'x2id19'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 359.0,
            y: 73.5
        },
        {
            x: 296.0,
            y: 73.5
        },
        {
            x: 296.0,
            y: 136.0
        },
        {
            x: 359.0,
            y: 136.0
        },
        {
            x: 359.0,
            y: 73.5
        },
    ], {
        fill: green,
        id: 'x2id20'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 433.0,
            y: 73.5
        },
        {
            x: 370.0,
            y: 73.5
        },
        {
            x: 370.0,
            y: 136.0
        },
        {
            x: 433.0,
            y: 136.0
        },
        {
            x: 433.0,
            y: 73.5
        },
    ], {
        fill: green,
        id: 'x2id21'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 507.0,
            y: 73.5
        },
        {
            x: 444.0,
            y: 73.5
        },
        {
            x: 444.0,
            y: 136.0
        },
        {
            x: 507.0,
            y: 136.0
        },
        {
            x: 507.0,
            y: 73.5
        },
    ], {
        fill: green,
        id: 'x2id22'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 581.0,
            y: 73.5
        },
        {
            x: 518.0,
            y: 73.5
        },
        {
            x: 518.0,
            y: 136.0
        },
        {
            x: 581.0,
            y: 136.0
        },
        {
            x: 581.0,
            y: 73.5
        },
    ], {
        fill: green,
        id: 'x2id23'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 655.0,
            y: 73.5
        },
        {
            x: 592.0,
            y: 73.5
        },
        {
            x: 592.0,
            y: 136.0
        },
        {
            x: 655.0,
            y: 136.0
        },
        {
            x: 655.0,
            y: 73.5
        },
    ], {
        fill: green,
        id: 'x2id24'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 729.0,
            y: 73.5
        },
        {
            x: 666.0,
            y: 73.5
        },
        {
            x: 666.0,
            y: 136.0
        },
        {
            x: 729.0,
            y: 136.0
        },
        {
            x: 729.0,
            y: 73.5
        },
    ], {
        fill: green,
        id: 'x2id25'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 803.0,
            y: 73.5
        },
        {
            x: 740.0,
            y: 73.5
        },
        {
            x: 740.0,
            y: 136.0
        },
        {
            x: 803.0,
            y: 136.0
        },
        {
            x: 803.0,
            y: 73.5
        },
    ], {
        fill: green,
        id: 'x2id26'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 877.0,
            y: 73.5
        },
        {
            x: 814.0,
            y: 73.5
        },
        {
            x: 814.0,
            y: 136.0
        },
        {
            x: 877.0,
            y: 136.0
        },
        {
            x: 877.0,
            y: 73.5
        },
    ], {
        fill: green,
        id: 'x2id27'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 951.0,
            y: 73.5
        },
        {
            x: 888.0,
            y: 73.5
        },
        {
            x: 888.0,
            y: 136.0
        },
        {
            x: 951.0,
            y: 136.0
        },
        {
            x: 951.0,
            y: 73.5
        },
    ], {
        fill: green,
        id: 'x2id28'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 1025.0,
            y: 73.5
        },
        {
            x: 962.0,
            y: 73.5
        },
        {
            x: 962.0,
            y: 136.0
        },
        {
            x: 1025.0,
            y: 136.0
        },
        {
            x: 1025.0,
            y: 73.5
        },
    ], {
        fill: green,
        id: 'x2id29'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 1099.0,
            y: 73.5
        },
        {
            x: 1036.0,
            y: 73.5
        },
        {
            x: 1036.0,
            y: 136.0
        },
        {
            x: 1099.0,
            y: 136.0
        },
        {
            x: 1099.0,
            y: 73.5
        },
    ], {
        fill: green,
        id: 'x2id30'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 63.0,
            y: 147.0
        },
        {
            x: 0.0,
            y: 147.0
        },
        {
            x: 0.0,
            y: 209.5
        },
        {
            x: 63.0,
            y: 209.5
        },
        {
            x: 63.0,
            y: 147.0
        },
    ], {
        fill: green,
        id: 'x2id31'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 137.0,
            y: 147.0
        },
        {
            x: 74.0,
            y: 147.0
        },
        {
            x: 74.0,
            y: 209.5
        },
        {
            x: 137.0,
            y: 209.5
        },
        {
            x: 137.0,
            y: 147.0
        },
    ], {
        fill: green,
        id: 'x2id32'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 211.0,
            y: 147.0
        },
        {
            x: 148.0,
            y: 147.0
        },
        {
            x: 148.0,
            y: 209.5
        },
        {
            x: 211.0,
            y: 209.5
        },
        {
            x: 211.0,
            y: 147.0
        },
    ], {
        fill: green,
        id: 'x2id33'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 285.0,
            y: 147.0
        },
        {
            x: 222.0,
            y: 147.0
        },
        {
            x: 222.0,
            y: 209.5
        },
        {
            x: 285.0,
            y: 209.5
        },
        {
            x: 285.0,
            y: 147.0
        },
    ], {
        fill: green,
        id: 'x2id34'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 359.0,
            y: 147.0
        },
        {
            x: 296.0,
            y: 147.0
        },
        {
            x: 296.0,
            y: 209.5
        },
        {
            x: 359.0,
            y: 209.5
        },
        {
            x: 359.0,
            y: 147.0
        },
    ], {
        fill: green,
        id: 'x2id35'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 433.0,
            y: 147.0
        },
        {
            x: 370.0,
            y: 147.0
        },
        {
            x: 370.0,
            y: 209.5
        },
        {
            x: 433.0,
            y: 209.5
        },
        {
            x: 433.0,
            y: 147.0
        },
    ], {
        fill: green,
        id: 'x2id36'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 507.0,
            y: 147.0
        },
        {
            x: 444.0,
            y: 147.0
        },
        {
            x: 444.0,
            y: 209.5
        },
        {
            x: 507.0,
            y: 209.5
        },
        {
            x: 507.0,
            y: 147.0
        },
    ], {
        fill: green,
        id: 'x2id37'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 581.0,
            y: 147.0
        },
        {
            x: 518.0,
            y: 147.0
        },
        {
            x: 518.0,
            y: 209.5
        },
        {
            x: 581.0,
            y: 209.5
        },
        {
            x: 581.0,
            y: 147.0
        },
    ], {
        fill: green,
        id: 'x2id38'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 655.0,
            y: 147.0
        },
        {
            x: 592.0,
            y: 147.0
        },
        {
            x: 592.0,
            y: 209.5
        },
        {
            x: 655.0,
            y: 209.5
        },
        {
            x: 655.0,
            y: 147.0
        },
    ], {
        fill: green,
        id: 'x2id39'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 729.0,
            y: 147.0
        },
        {
            x: 666.0,
            y: 147.0
        },
        {
            x: 666.0,
            y: 209.5
        },
        {
            x: 729.0,
            y: 209.5
        },
        {
            x: 729.0,
            y: 147.0
        },
    ], {
        fill: green,
        id: 'x2id40'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 803.0,
            y: 147.0
        },
        {
            x: 740.0,
            y: 147.0
        },
        {
            x: 740.0,
            y: 209.5
        },
        {
            x: 803.0,
            y: 209.5
        },
        {
            x: 803.0,
            y: 147.0
        },
    ], {
        fill: green,
        id: 'x2id41'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 877.0,
            y: 147.0
        },
        {
            x: 814.0,
            y: 147.0
        },
        {
            x: 814.0,
            y: 209.5
        },
        {
            x: 877.0,
            y: 209.5
        },
        {
            x: 877.0,
            y: 147.0
        },
    ], {
        fill: green,
        id: 'x2id42'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 951.0,
            y: 147.0
        },
        {
            x: 888.0,
            y: 147.0
        },
        {
            x: 888.0,
            y: 209.5
        },
        {
            x: 951.0,
            y: 209.5
        },
        {
            x: 951.0,
            y: 147.0
        },
    ], {
        fill: green,
        id: 'x2id43'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 1025.0,
            y: 147.0
        },
        {
            x: 962.0,
            y: 147.0
        },
        {
            x: 962.0,
            y: 209.5
        },
        {
            x: 1025.0,
            y: 209.5
        },
        {
            x: 1025.0,
            y: 147.0
        },
    ], {
        fill: green,
        id: 'x2id44'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 1099.0,
            y: 147.0
        },
        {
            x: 1036.0,
            y: 147.0
        },
        {
            x: 1036.0,
            y: 209.5
        },
        {
            x: 1099.0,
            y: 209.5
        },
        {
            x: 1099.0,
            y: 147.0
        },
    ], {
        fill: green,
        id: 'x2id45'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 63.0,
            y: 220.5
        },
        {
            x: 0.0,
            y: 220.5
        },
        {
            x: 0.0,
            y: 283.0
        },
        {
            x: 63.0,
            y: 283.0
        },
        {
            x: 63.0,
            y: 220.5
        },
    ], {
        fill: green,
        id: 'x2id46'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 137.0,
            y: 220.5
        },
        {
            x: 74.0,
            y: 220.5
        },
        {
            x: 74.0,
            y: 283.0
        },
        {
            x: 137.0,
            y: 283.0
        },
        {
            x: 137.0,
            y: 220.5
        },
    ], {
        fill: green,
        id: 'x2id47'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 211.0,
            y: 220.5
        },
        {
            x: 148.0,
            y: 220.5
        },
        {
            x: 148.0,
            y: 283.0
        },
        {
            x: 211.0,
            y: 283.0
        },
        {
            x: 211.0,
            y: 220.5
        },
    ], {
        fill: green,
        id: 'x2id48'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 285.0,
            y: 220.5
        },
        {
            x: 222.0,
            y: 220.5
        },
        {
            x: 222.0,
            y: 283.0
        },
        {
            x: 285.0,
            y: 283.0
        },
        {
            x: 285.0,
            y: 220.5
        },
    ], {
        fill: green,
        id: 'x2id49'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 359.0,
            y: 220.5
        },
        {
            x: 296.0,
            y: 220.5
        },
        {
            x: 296.0,
            y: 283.0
        },
        {
            x: 359.0,
            y: 283.0
        },
        {
            x: 359.0,
            y: 220.5
        },
    ], {
        fill: green,
        id: 'x2id50'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 433.0,
            y: 220.5
        },
        {
            x: 370.0,
            y: 220.5
        },
        {
            x: 370.0,
            y: 283.0
        },
        {
            x: 433.0,
            y: 283.0
        },
        {
            x: 433.0,
            y: 220.5
        },
    ], {
        fill: green,
        id: 'x2id51'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 507.0,
            y: 220.5
        },
        {
            x: 444.0,
            y: 220.5
        },
        {
            x: 444.0,
            y: 283.0
        },
        {
            x: 507.0,
            y: 283.0
        },
        {
            x: 507.0,
            y: 220.5
        },
    ], {
        fill: green,
        id: 'x2id52'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 581.0,
            y: 220.5
        },
        {
            x: 518.0,
            y: 220.5
        },
        {
            x: 518.0,
            y: 283.0
        },
        {
            x: 581.0,
            y: 283.0
        },
        {
            x: 581.0,
            y: 220.5
        },
    ], {
        fill: green,
        id: 'x2id53'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 655.0,
            y: 220.5
        },
        {
            x: 592.0,
            y: 220.5
        },
        {
            x: 592.0,
            y: 283.0
        },
        {
            x: 655.0,
            y: 283.0
        },
        {
            x: 655.0,
            y: 220.5
        },
    ], {
        fill: green,
        id: 'x2id54'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 729.0,
            y: 220.5
        },
        {
            x: 666.0,
            y: 220.5
        },
        {
            x: 666.0,
            y: 283.0
        },
        {
            x: 729.0,
            y: 283.0
        },
        {
            x: 729.0,
            y: 220.5
        },
    ], {
        fill: green,
        id: 'x2id55'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 803.0,
            y: 220.5
        },
        {
            x: 740.0,
            y: 220.5
        },
        {
            x: 740.0,
            y: 283.0
        },
        {
            x: 803.0,
            y: 283.0
        },
        {
            x: 803.0,
            y: 220.5
        },
    ], {
        fill: green,
        id: 'x2id56'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 877.0,
            y: 220.5
        },
        {
            x: 814.0,
            y: 220.5
        },
        {
            x: 814.0,
            y: 283.0
        },
        {
            x: 877.0,
            y: 283.0
        },
        {
            x: 877.0,
            y: 220.5
        },
    ], {
        fill: green,
        id: 'x2id57'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 951.0,
            y: 220.5
        },
        {
            x: 888.0,
            y: 220.5
        },
        {
            x: 888.0,
            y: 283.0
        },
        {
            x: 951.0,
            y: 283.0
        },
        {
            x: 951.0,
            y: 220.5
        },
    ], {
        fill: green,
        id: 'x2id58'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 1025.0,
            y: 220.5
        },
        {
            x: 962.0,
            y: 220.5
        },
        {
            x: 962.0,
            y: 283.0
        },
        {
            x: 1025.0,
            y: 283.0
        },
        {
            x: 1025.0,
            y: 220.5
        },
    ], {
        fill: green,
        id: 'x2id59'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 1099.0,
            y: 220.5
        },
        {
            x: 1036.0,
            y: 220.5
        },
        {
            x: 1036.0,
            y: 283.0
        },
        {
            x: 1099.0,
            y: 283.0
        },
        {
            x: 1099.0,
            y: 220.5
        },
    ], {
        fill: green,
        id: 'x2id60'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 63.0,
            y: 294.0
        },
        {
            x: 0.0,
            y: 294.0
        },
        {
            x: 0.0,
            y: 356.5
        },
        {
            x: 63.0,
            y: 356.5
        },
        {
            x: 63.0,
            y: 294.0
        },
    ], {
        fill: green,
        id: 'x2id61'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 137.0,
            y: 294.0
        },
        {
            x: 74.0,
            y: 294.0
        },
        {
            x: 74.0,
            y: 356.5
        },
        {
            x: 137.0,
            y: 356.5
        },
        {
            x: 137.0,
            y: 294.0
        },
    ], {
        fill: green,
        id: 'x2id62'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 211.0,
            y: 294.0
        },
        {
            x: 148.0,
            y: 294.0
        },
        {
            x: 148.0,
            y: 356.5
        },
        {
            x: 211.0,
            y: 356.5
        },
        {
            x: 211.0,
            y: 294.0
        },
    ], {
        fill: green,
        id: 'x2id63'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 285.0,
            y: 294.0
        },
        {
            x: 222.0,
            y: 294.0
        },
        {
            x: 222.0,
            y: 356.5
        },
        {
            x: 285.0,
            y: 356.5
        },
        {
            x: 285.0,
            y: 294.0
        },
    ], {
        fill: green,
        id: 'x2id64'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 359.0,
            y: 294.0
        },
        {
            x: 296.0,
            y: 294.0
        },
        {
            x: 296.0,
            y: 356.5
        },
        {
            x: 359.0,
            y: 356.5
        },
        {
            x: 359.0,
            y: 294.0
        },
    ], {
        fill: green,
        id: 'x2id65'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 433.0,
            y: 294.0
        },
        {
            x: 370.0,
            y: 294.0
        },
        {
            x: 370.0,
            y: 356.5
        },
        {
            x: 433.0,
            y: 356.5
        },
        {
            x: 433.0,
            y: 294.0
        },
    ], {
        fill: green,
        id: 'x2id66'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 507.0,
            y: 294.0
        },
        {
            x: 444.0,
            y: 294.0
        },
        {
            x: 444.0,
            y: 356.5
        },
        {
            x: 507.0,
            y: 356.5
        },
        {
            x: 507.0,
            y: 294.0
        },
    ], {
        fill: green,
        id: 'x2id67'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 581.0,
            y: 294.0
        },
        {
            x: 518.0,
            y: 294.0
        },
        {
            x: 518.0,
            y: 356.5
        },
        {
            x: 581.0,
            y: 356.5
        },
        {
            x: 581.0,
            y: 294.0
        },
    ], {
        fill: green,
        id: 'x2id68'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 655.0,
            y: 294.0
        },
        {
            x: 592.0,
            y: 294.0
        },
        {
            x: 592.0,
            y: 356.5
        },
        {
            x: 655.0,
            y: 356.5
        },
        {
            x: 655.0,
            y: 294.0
        },
    ], {
        fill: green,
        id: 'x2id69'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 729.0,
            y: 294.0
        },
        {
            x: 666.0,
            y: 294.0
        },
        {
            x: 666.0,
            y: 356.5
        },
        {
            x: 729.0,
            y: 356.5
        },
        {
            x: 729.0,
            y: 294.0
        },
    ], {
        fill: green,
        id: 'x2id70'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 803.0,
            y: 294.0
        },
        {
            x: 740.0,
            y: 294.0
        },
        {
            x: 740.0,
            y: 356.5
        },
        {
            x: 803.0,
            y: 356.5
        },
        {
            x: 803.0,
            y: 294.0
        },
    ], {
        fill: green,
        id: 'x2id71'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 877.0,
            y: 294.0
        },
        {
            x: 814.0,
            y: 294.0
        },
        {
            x: 814.0,
            y: 356.5
        },
        {
            x: 877.0,
            y: 356.5
        },
        {
            x: 877.0,
            y: 294.0
        },
    ], {
        fill: green,
        id: 'x2id72'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 951.0,
            y: 294.0
        },
        {
            x: 888.0,
            y: 294.0
        },
        {
            x: 888.0,
            y: 356.5
        },
        {
            x: 951.0,
            y: 356.5
        },
        {
            x: 951.0,
            y: 294.0
        },
    ], {
        fill: green,
        id: 'x2id73'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 1025.0,
            y: 294.0
        },
        {
            x: 962.0,
            y: 294.0
        },
        {
            x: 962.0,
            y: 356.5
        },
        {
            x: 1025.0,
            y: 356.5
        },
        {
            x: 1025.0,
            y: 294.0
        },
    ], {
        fill: green,
        id: 'x2id74'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 1099.0,
            y: 294.0
        },
        {
            x: 1036.0,
            y: 294.0
        },
        {
            x: 1036.0,
            y: 356.5
        },
        {
            x: 1099.0,
            y: 356.5
        },
        {
            x: 1099.0,
            y: 294.0
        },
    ], {
        fill: green,
        id: 'x2id75'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 63.0,
            y: 367.5
        },
        {
            x: 0.0,
            y: 367.5
        },
        {
            x: 0.0,
            y: 430.0
        },
        {
            x: 63.0,
            y: 430.0
        },
        {
            x: 63.0,
            y: 367.5
        },
    ], {
        fill: green,
        id: 'x2id76'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 137.0,
            y: 367.5
        },
        {
            x: 74.0,
            y: 367.5
        },
        {
            x: 74.0,
            y: 430.0
        },
        {
            x: 137.0,
            y: 430.0
        },
        {
            x: 137.0,
            y: 367.5
        },
    ], {
        fill: green,
        id: 'x2id77'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 211.0,
            y: 367.5
        },
        {
            x: 148.0,
            y: 367.5
        },
        {
            x: 148.0,
            y: 430.0
        },
        {
            x: 211.0,
            y: 430.0
        },
        {
            x: 211.0,
            y: 367.5
        },
    ], {
        fill: green,
        id: 'x2id78'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 285.0,
            y: 367.5
        },
        {
            x: 222.0,
            y: 367.5
        },
        {
            x: 222.0,
            y: 430.0
        },
        {
            x: 285.0,
            y: 430.0
        },
        {
            x: 285.0,
            y: 367.5
        },
    ], {
        fill: green,
        id: 'x2id79'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 359.0,
            y: 367.5
        },
        {
            x: 296.0,
            y: 367.5
        },
        {
            x: 296.0,
            y: 430.0
        },
        {
            x: 359.0,
            y: 430.0
        },
        {
            x: 359.0,
            y: 367.5
        },
    ], {
        fill: green,
        id: 'x2id80'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 877.0,
            y: 367.5
        },
        {
            x: 814.0,
            y: 367.5
        },
        {
            x: 814.0,
            y: 430.0
        },
        {
            x: 877.0,
            y: 430.0
        },
        {
            x: 877.0,
            y: 367.5
        },
    ], {
        fill: green,
        id: 'x2id81'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 951.0,
            y: 367.5
        },
        {
            x: 888.0,
            y: 367.5
        },
        {
            x: 888.0,
            y: 430.0
        },
        {
            x: 951.0,
            y: 430.0
        },
        {
            x: 951.0,
            y: 367.5
        },
    ], {
        fill: green,
        id: 'x2id82'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 1025.0,
            y: 367.5
        },
        {
            x: 962.0,
            y: 367.5
        },
        {
            x: 962.0,
            y: 430.0
        },
        {
            x: 1025.0,
            y: 430.0
        },
        {
            x: 1025.0,
            y: 367.5
        },
    ], {
        fill: green,
        id: 'x2id83'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 1099.0,
            y: 367.5
        },
        {
            x: 1036.0,
            y: 367.5
        },
        {
            x: 1036.0,
            y: 430.0
        },
        {
            x: 1099.0,
            y: 430.0
        },
        {
            x: 1099.0,
            y: 367.5
        },
    ], {
        fill: green,
        id: 'x2id84'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 63.0,
            y: 441.0
        },
        {
            x: 0.0,
            y: 441.0
        },
        {
            x: 0.0,
            y: 503.6
        },
        {
            x: 63.0,
            y: 503.6
        },
        {
            x: 63.0,
            y: 441.0
        },
    ], {
        fill: green,
        id: 'x2id85'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 137.0,
            y: 441.0
        },
        {
            x: 74.0,
            y: 441.0
        },
        {
            x: 74.0,
            y: 503.6
        },
        {
            x: 137.0,
            y: 503.6
        },
        {
            x: 137.0,
            y: 441.0
        },
    ], {
        fill: green,
        id: 'x2id86'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 211.0,
            y: 441.0
        },
        {
            x: 148.0,
            y: 441.0
        },
        {
            x: 148.0,
            y: 503.6
        },
        {
            x: 211.0,
            y: 503.6
        },
        {
            x: 211.0,
            y: 441.0
        },
    ], {
        fill: green,
        id: 'x2id87'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 285.0,
            y: 441.0
        },
        {
            x: 222.0,
            y: 441.0
        },
        {
            x: 222.0,
            y: 503.6
        },
        {
            x: 285.0,
            y: 503.6
        },
        {
            x: 285.0,
            y: 441.0
        },
    ], {
        fill: green,
        id: 'x2id88'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 359.0,
            y: 441.0
        },
        {
            x: 296.0,
            y: 441.0
        },
        {
            x: 296.0,
            y: 503.6
        },
        {
            x: 359.0,
            y: 503.6
        },
        {
            x: 359.0,
            y: 441.0
        },
    ], {
        fill: green,
        id: 'x2id89'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 877.0,
            y: 441.0
        },
        {
            x: 814.0,
            y: 441.0
        },
        {
            x: 814.0,
            y: 503.6
        },
        {
            x: 877.0,
            y: 503.6
        },
        {
            x: 877.0,
            y: 441.0
        },
    ], {
        fill: green,
        id: 'x2id90'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 951.0,
            y: 441.0
        },
        {
            x: 888.0,
            y: 441.0
        },
        {
            x: 888.0,
            y: 503.6
        },
        {
            x: 951.0,
            y: 503.6
        },
        {
            x: 951.0,
            y: 441.0
        },
    ], {
        fill: green,
        id: 'x2id91'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 1025.0,
            y: 441.0
        },
        {
            x: 962.0,
            y: 441.0
        },
        {
            x: 962.0,
            y: 503.6
        },
        {
            x: 1025.0,
            y: 503.6
        },
        {
            x: 1025.0,
            y: 441.0
        },
    ], {
        fill: green,
        id: 'x2id92'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 1099.0,
            y: 441.0
        },
        {
            x: 1036.0,
            y: 441.0
        },
        {
            x: 1036.0,
            y: 503.6
        },
        {
            x: 1099.0,
            y: 503.6
        },
        {
            x: 1099.0,
            y: 441.0
        },
    ], {
        fill: green,
        id: 'x2id93'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 63.0,
            y: 514.6
        },
        {
            x: 0.0,
            y: 514.6
        },
        {
            x: 0.0,
            y: 577.1
        },
        {
            x: 63.0,
            y: 577.1
        },
        {
            x: 63.0,
            y: 514.6
        },
    ], {
        fill: green,
        id: 'x2id94'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 137.0,
            y: 514.6
        },
        {
            x: 74.0,
            y: 514.6
        },
        {
            x: 74.0,
            y: 577.1
        },
        {
            x: 137.0,
            y: 577.1
        },
        {
            x: 137.0,
            y: 514.6
        },
    ], {
        fill: green,
        id: 'x2id95'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 211.0,
            y: 514.6
        },
        {
            x: 148.0,
            y: 514.6
        },
        {
            x: 148.0,
            y: 577.1
        },
        {
            x: 211.0,
            y: 577.1
        },
        {
            x: 211.0,
            y: 514.6
        },
    ], {
        fill: green,
        id: 'x2id96'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 285.0,
            y: 514.6
        },
        {
            x: 222.0,
            y: 514.6
        },
        {
            x: 222.0,
            y: 577.1
        },
        {
            x: 285.0,
            y: 577.1
        },
        {
            x: 285.0,
            y: 514.6
        },
    ], {
        fill: green,
        id: 'x2id97'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 359.0,
            y: 514.6
        },
        {
            x: 296.0,
            y: 514.6
        },
        {
            x: 296.0,
            y: 577.1
        },
        {
            x: 359.0,
            y: 577.1
        },
        {
            x: 359.0,
            y: 514.6
        },
    ], {
        fill: green,
        id: 'x2id98'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 877.0,
            y: 514.6
        },
        {
            x: 814.0,
            y: 514.6
        },
        {
            x: 814.0,
            y: 577.1
        },
        {
            x: 877.0,
            y: 577.1
        },
        {
            x: 877.0,
            y: 514.6
        },
    ], {
        fill: green,
        id: 'x2id99'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 951.0,
            y: 514.6
        },
        {
            x: 888.0,
            y: 514.6
        },
        {
            x: 888.0,
            y: 577.1
        },
        {
            x: 951.0,
            y: 577.1
        },
        {
            x: 951.0,
            y: 514.6
        },
    ], {
        fill: green,
        id: 'x2id100'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 1025.0,
            y: 514.6
        },
        {
            x: 962.0,
            y: 514.6
        },
        {
            x: 962.0,
            y: 577.1
        },
        {
            x: 1025.0,
            y: 577.1
        },
        {
            x: 1025.0,
            y: 514.6
        },
    ], {
        fill: green,
        id: 'x2id101'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 1099.0,
            y: 514.6
        },
        {
            x: 1036.0,
            y: 514.6
        },
        {
            x: 1036.0,
            y: 577.1
        },
        {
            x: 1099.0,
            y: 577.1
        },
        {
            x: 1099.0,
            y: 514.6
        },
    ], {
        fill: green,
        id: 'x2id102'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 63.0,
            y: 588.1
        },
        {
            x: 0.0,
            y: 588.1
        },
        {
            x: 0.0,
            y: 650.6
        },
        {
            x: 63.0,
            y: 650.6
        },
        {
            x: 63.0,
            y: 588.1
        },
    ], {
        fill: green,
        id: 'x2id103'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 137.0,
            y: 588.1
        },
        {
            x: 74.0,
            y: 588.1
        },
        {
            x: 74.0,
            y: 650.6
        },
        {
            x: 137.0,
            y: 650.6
        },
        {
            x: 137.0,
            y: 588.1
        },
    ], {
        fill: green,
        id: 'x2id104'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 211.0,
            y: 588.1
        },
        {
            x: 148.0,
            y: 588.1
        },
        {
            x: 148.0,
            y: 650.6
        },
        {
            x: 211.0,
            y: 650.6
        },
        {
            x: 211.0,
            y: 588.1
        },
    ], {
        fill: green,
        id: 'x2id105'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 285.0,
            y: 588.1
        },
        {
            x: 222.0,
            y: 588.1
        },
        {
            x: 222.0,
            y: 650.6
        },
        {
            x: 285.0,
            y: 650.6
        },
        {
            x: 285.0,
            y: 588.1
        },
    ], {
        fill: green,
        id: 'x2id106'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 359.0,
            y: 588.1
        },
        {
            x: 296.0,
            y: 588.1
        },
        {
            x: 296.0,
            y: 650.6
        },
        {
            x: 359.0,
            y: 650.6
        },
        {
            x: 359.0,
            y: 588.1
        },
    ], {
        fill: green,
        id: 'x2id107'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 877.0,
            y: 588.1
        },
        {
            x: 814.0,
            y: 588.1
        },
        {
            x: 814.0,
            y: 650.6
        },
        {
            x: 877.0,
            y: 650.6
        },
        {
            x: 877.0,
            y: 588.1
        },
    ], {
        fill: green,
        id: 'x2id108'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 951.0,
            y: 588.1
        },
        {
            x: 888.0,
            y: 588.1
        },
        {
            x: 888.0,
            y: 650.6
        },
        {
            x: 951.0,
            y: 650.6
        },
        {
            x: 951.0,
            y: 588.1
        },
    ], {
        fill: green,
        id: 'x2id109'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 1025.0,
            y: 588.1
        },
        {
            x: 962.0,
            y: 588.1
        },
        {
            x: 962.0,
            y: 650.6
        },
        {
            x: 1025.0,
            y: 650.6
        },
        {
            x: 1025.0,
            y: 588.1
        },
    ], {
        fill: green,
        id: 'x2id110'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 1099.0,
            y: 588.1
        },
        {
            x: 1036.0,
            y: 588.1
        },
        {
            x: 1036.0,
            y: 650.6
        },
        {
            x: 1099.0,
            y: 650.6
        },
        {
            x: 1099.0,
            y: 588.1
        },
    ], {
        fill: green,
        id: 'x2id111'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 63.0,
            y: 661.6
        },
        {
            x: 0.0,
            y: 661.6
        },
        {
            x: 0.0,
            y: 724.1
        },
        {
            x: 63.0,
            y: 724.1
        },
        {
            x: 63.0,
            y: 661.6
        },
    ], {
        fill: green,
        id: 'x2id112'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 137.0,
            y: 661.6
        },
        {
            x: 74.0,
            y: 661.6
        },
        {
            x: 74.0,
            y: 724.1
        },
        {
            x: 137.0,
            y: 724.1
        },
        {
            x: 137.0,
            y: 661.6
        },
    ], {
        fill: green,
        id: 'x2id113'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 211.0,
            y: 661.6
        },
        {
            x: 148.0,
            y: 661.6
        },
        {
            x: 148.0,
            y: 724.1
        },
        {
            x: 211.0,
            y: 724.1
        },
        {
            x: 211.0,
            y: 661.6
        },
    ], {
        fill: green,
        id: 'x2id114'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 285.0,
            y: 661.6
        },
        {
            x: 222.0,
            y: 661.6
        },
        {
            x: 222.0,
            y: 724.1
        },
        {
            x: 285.0,
            y: 724.1
        },
        {
            x: 285.0,
            y: 661.6
        },
    ], {
        fill: green,
        id: 'x2id115'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 359.0,
            y: 661.6
        },
        {
            x: 296.0,
            y: 661.6
        },
        {
            x: 296.0,
            y: 724.1
        },
        {
            x: 359.0,
            y: 724.1
        },
        {
            x: 359.0,
            y: 661.6
        },
    ], {
        fill: green,
        id: 'x2id116'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 877.0,
            y: 661.6
        },
        {
            x: 814.0,
            y: 661.6
        },
        {
            x: 814.0,
            y: 724.1
        },
        {
            x: 877.0,
            y: 724.1
        },
        {
            x: 877.0,
            y: 661.6
        },
    ], {
        fill: green,
        id: 'x2id117'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 951.0,
            y: 661.6
        },
        {
            x: 888.0,
            y: 661.6
        },
        {
            x: 888.0,
            y: 724.1
        },
        {
            x: 951.0,
            y: 724.1
        },
        {
            x: 951.0,
            y: 661.6
        },
    ], {
        fill: green,
        id: 'x2id118'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 1025.0,
            y: 661.6
        },
        {
            x: 962.0,
            y: 661.6
        },
        {
            x: 962.0,
            y: 724.1
        },
        {
            x: 1025.0,
            y: 724.1
        },
        {
            x: 1025.0,
            y: 661.6
        },
    ], {
        fill: green,
        id: 'x2id119'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 1099.0,
            y: 661.6
        },
        {
            x: 1036.0,
            y: 661.6
        },
        {
            x: 1036.0,
            y: 724.1
        },
        {
            x: 1099.0,
            y: 724.1
        },
        {
            x: 1099.0,
            y: 661.6
        },
    ], {
        fill: green,
        id: 'x2id120'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 63.0,
            y: 735.1
        },
        {
            x: 0.0,
            y: 735.1
        },
        {
            x: 0.0,
            y: 797.6
        },
        {
            x: 63.0,
            y: 797.6
        },
        {
            x: 63.0,
            y: 735.1
        },
    ], {
        fill: green,
        id: 'x2id121'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 137.0,
            y: 735.1
        },
        {
            x: 74.0,
            y: 735.1
        },
        {
            x: 74.0,
            y: 797.6
        },
        {
            x: 137.0,
            y: 797.6
        },
        {
            x: 137.0,
            y: 735.1
        },
    ], {
        fill: green,
        id: 'x2id122'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 211.0,
            y: 735.1
        },
        {
            x: 148.0,
            y: 735.1
        },
        {
            x: 148.0,
            y: 797.6
        },
        {
            x: 211.0,
            y: 797.6
        },
        {
            x: 211.0,
            y: 735.1
        },
    ], {
        fill: green,
        id: 'x2id123'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 285.0,
            y: 735.1
        },
        {
            x: 222.0,
            y: 735.1
        },
        {
            x: 222.0,
            y: 797.6
        },
        {
            x: 285.0,
            y: 797.6
        },
        {
            x: 285.0,
            y: 735.1
        },
    ], {
        fill: green,
        id: 'x2id124'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 359.0,
            y: 735.1
        },
        {
            x: 296.0,
            y: 735.1
        },
        {
            x: 296.0,
            y: 797.6
        },
        {
            x: 359.0,
            y: 797.6
        },
        {
            x: 359.0,
            y: 735.1
        },
    ], {
        fill: green,
        id: 'x2id125'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 433.0,
            y: 735.1
        },
        {
            x: 370.0,
            y: 735.1
        },
        {
            x: 370.0,
            y: 797.6
        },
        {
            x: 433.0,
            y: 797.6
        },
        {
            x: 433.0,
            y: 735.1
        },
    ], {
        fill: green,
        id: 'x2id126'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 507.0,
            y: 735.1
        },
        {
            x: 444.0,
            y: 735.1
        },
        {
            x: 444.0,
            y: 797.6
        },
        {
            x: 507.0,
            y: 797.6
        },
        {
            x: 507.0,
            y: 735.1
        },
    ], {
        fill: green,
        id: 'x2id127'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 581.0,
            y: 735.1
        },
        {
            x: 518.0,
            y: 735.1
        },
        {
            x: 518.0,
            y: 797.6
        },
        {
            x: 581.0,
            y: 797.6
        },
        {
            x: 581.0,
            y: 735.1
        },
    ], {
        fill: green,
        id: 'x2id128'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 655.0,
            y: 735.1
        },
        {
            x: 592.0,
            y: 735.1
        },
        {
            x: 592.0,
            y: 797.6
        },
        {
            x: 655.0,
            y: 797.6
        },
        {
            x: 655.0,
            y: 735.1
        },
    ], {
        fill: green,
        id: 'x2id129'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 729.0,
            y: 735.1
        },
        {
            x: 666.0,
            y: 735.1
        },
        {
            x: 666.0,
            y: 797.6
        },
        {
            x: 729.0,
            y: 797.6
        },
        {
            x: 729.0,
            y: 735.1
        },
    ], {
        fill: green,
        id: 'x2id130'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 803.0,
            y: 735.1
        },
        {
            x: 740.0,
            y: 735.1
        },
        {
            x: 740.0,
            y: 797.6
        },
        {
            x: 803.0,
            y: 797.6
        },
        {
            x: 803.0,
            y: 735.1
        },
    ], {
        fill: green,
        id: 'x2id131'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 877.0,
            y: 735.1
        },
        {
            x: 814.0,
            y: 735.1
        },
        {
            x: 814.0,
            y: 797.6
        },
        {
            x: 877.0,
            y: 797.6
        },
        {
            x: 877.0,
            y: 735.1
        },
    ], {
        fill: green,
        id: 'x2id132'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 951.0,
            y: 735.1
        },
        {
            x: 888.0,
            y: 735.1
        },
        {
            x: 888.0,
            y: 797.6
        },
        {
            x: 951.0,
            y: 797.6
        },
        {
            x: 951.0,
            y: 735.1
        },
    ], {
        fill: green,
        id: 'x2id133'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 1025.0,
            y: 735.1
        },
        {
            x: 962.0,
            y: 735.1
        },
        {
            x: 962.0,
            y: 797.6
        },
        {
            x: 1025.0,
            y: 797.6
        },
        {
            x: 1025.0,
            y: 735.1
        },
    ], {
        fill: green,
        id: 'x2id134'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 1099.0,
            y: 735.1
        },
        {
            x: 1036.0,
            y: 735.1
        },
        {
            x: 1036.0,
            y: 797.6
        },
        {
            x: 1099.0,
            y: 797.6
        },
        {
            x: 1099.0,
            y: 735.1
        },
    ], {
        fill: green,
        id: 'x2id135'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 63.0,
            y: 808.6
        },
        {
            x: 0.0,
            y: 808.6
        },
        {
            x: 0.0,
            y: 871.1
        },
        {
            x: 63.0,
            y: 871.1
        },
        {
            x: 63.0,
            y: 808.6
        },
    ], {
        fill: green,
        id: 'x2id136'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 137.0,
            y: 808.6
        },
        {
            x: 74.0,
            y: 808.6
        },
        {
            x: 74.0,
            y: 871.1
        },
        {
            x: 137.0,
            y: 871.1
        },
        {
            x: 137.0,
            y: 808.6
        },
    ], {
        fill: green,
        id: 'x2id137'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 211.0,
            y: 808.6
        },
        {
            x: 148.0,
            y: 808.6
        },
        {
            x: 148.0,
            y: 871.1
        },
        {
            x: 211.0,
            y: 871.1
        },
        {
            x: 211.0,
            y: 808.6
        },
    ], {
        fill: green,
        id: 'x2id138'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 285.0,
            y: 808.6
        },
        {
            x: 222.0,
            y: 808.6
        },
        {
            x: 222.0,
            y: 871.1
        },
        {
            x: 285.0,
            y: 871.1
        },
        {
            x: 285.0,
            y: 808.6
        },
    ], {
        fill: green,
        id: 'x2id139'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 359.0,
            y: 808.6
        },
        {
            x: 296.0,
            y: 808.6
        },
        {
            x: 296.0,
            y: 871.1
        },
        {
            x: 359.0,
            y: 871.1
        },
        {
            x: 359.0,
            y: 808.6
        },
    ], {
        fill: green,
        id: 'x2id140'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 433.0,
            y: 808.6
        },
        {
            x: 370.0,
            y: 808.6
        },
        {
            x: 370.0,
            y: 871.1
        },
        {
            x: 433.0,
            y: 871.1
        },
        {
            x: 433.0,
            y: 808.6
        },
    ], {
        fill: green,
        id: 'x2id141'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 507.0,
            y: 808.6
        },
        {
            x: 444.0,
            y: 808.6
        },
        {
            x: 444.0,
            y: 871.1
        },
        {
            x: 507.0,
            y: 871.1
        },
        {
            x: 507.0,
            y: 808.6
        },
    ], {
        fill: green,
        id: 'x2id142'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 581.0,
            y: 808.6
        },
        {
            x: 518.0,
            y: 808.6
        },
        {
            x: 518.0,
            y: 871.1
        },
        {
            x: 581.0,
            y: 871.1
        },
        {
            x: 581.0,
            y: 808.6
        },
    ], {
        fill: green,
        id: 'x2id143'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 655.0,
            y: 808.6
        },
        {
            x: 592.0,
            y: 808.6
        },
        {
            x: 592.0,
            y: 871.1
        },
        {
            x: 655.0,
            y: 871.1
        },
        {
            x: 655.0,
            y: 808.6
        },
    ], {
        fill: green,
        id: 'x2id144'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 729.0,
            y: 808.6
        },
        {
            x: 666.0,
            y: 808.6
        },
        {
            x: 666.0,
            y: 871.1
        },
        {
            x: 729.0,
            y: 871.1
        },
        {
            x: 729.0,
            y: 808.6
        },
    ], {
        fill: green,
        id: 'x2id145'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 803.0,
            y: 808.6
        },
        {
            x: 740.0,
            y: 808.6
        },
        {
            x: 740.0,
            y: 871.1
        },
        {
            x: 803.0,
            y: 871.1
        },
        {
            x: 803.0,
            y: 808.6
        },
    ], {
        fill: green,
        id: 'x2id146'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 877.0,
            y: 808.6
        },
        {
            x: 814.0,
            y: 808.6
        },
        {
            x: 814.0,
            y: 871.1
        },
        {
            x: 877.0,
            y: 871.1
        },
        {
            x: 877.0,
            y: 808.6
        },
    ], {
        fill: green,
        id: 'x2id147'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 951.0,
            y: 808.6
        },
        {
            x: 888.0,
            y: 808.6
        },
        {
            x: 888.0,
            y: 871.1
        },
        {
            x: 951.0,
            y: 871.1
        },
        {
            x: 951.0,
            y: 808.6
        },
    ], {
        fill: green,
        id: 'x2id148'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 1025.0,
            y: 808.6
        },
        {
            x: 962.0,
            y: 808.6
        },
        {
            x: 962.0,
            y: 871.1
        },
        {
            x: 1025.0,
            y: 871.1
        },
        {
            x: 1025.0,
            y: 808.6
        },
    ], {
        fill: green,
        id: 'x2id149'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 1099.0,
            y: 808.6
        },
        {
            x: 1036.0,
            y: 808.6
        },
        {
            x: 1036.0,
            y: 871.1
        },
        {
            x: 1099.0,
            y: 871.1
        },
        {
            x: 1099.0,
            y: 808.6
        },
    ], {
        fill: green,
        id: 'x2id150'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 63.0,
            y: 882.1
        },
        {
            x: 0.0,
            y: 882.1
        },
        {
            x: 0.0,
            y: 944.6
        },
        {
            x: 63.0,
            y: 944.6
        },
        {
            x: 63.0,
            y: 882.1
        },
    ], {
        fill: green,
        id: 'x2id151'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 137.0,
            y: 882.1
        },
        {
            x: 74.0,
            y: 882.1
        },
        {
            x: 74.0,
            y: 944.6
        },
        {
            x: 137.0,
            y: 944.6
        },
        {
            x: 137.0,
            y: 882.1
        },
    ], {
        fill: green,
        id: 'x2id152'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 211.0,
            y: 882.1
        },
        {
            x: 148.0,
            y: 882.1
        },
        {
            x: 148.0,
            y: 944.6
        },
        {
            x: 211.0,
            y: 944.6
        },
        {
            x: 211.0,
            y: 882.1
        },
    ], {
        fill: green,
        id: 'x2id153'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 285.0,
            y: 882.1
        },
        {
            x: 222.0,
            y: 882.1
        },
        {
            x: 222.0,
            y: 944.6
        },
        {
            x: 285.0,
            y: 944.6
        },
        {
            x: 285.0,
            y: 882.1
        },
    ], {
        fill: green,
        id: 'x2id154'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 359.0,
            y: 882.1
        },
        {
            x: 296.0,
            y: 882.1
        },
        {
            x: 296.0,
            y: 944.6
        },
        {
            x: 359.0,
            y: 944.6
        },
        {
            x: 359.0,
            y: 882.1
        },
    ], {
        fill: green,
        id: 'x2id155'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 433.0,
            y: 882.1
        },
        {
            x: 370.0,
            y: 882.1
        },
        {
            x: 370.0,
            y: 944.6
        },
        {
            x: 433.0,
            y: 944.6
        },
        {
            x: 433.0,
            y: 882.1
        },
    ], {
        fill: green,
        id: 'x2id156'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 507.0,
            y: 882.1
        },
        {
            x: 444.0,
            y: 882.1
        },
        {
            x: 444.0,
            y: 944.6
        },
        {
            x: 507.0,
            y: 944.6
        },
        {
            x: 507.0,
            y: 882.1
        },
    ], {
        fill: green,
        id: 'x2id157'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 581.0,
            y: 882.1
        },
        {
            x: 518.0,
            y: 882.1
        },
        {
            x: 518.0,
            y: 944.6
        },
        {
            x: 581.0,
            y: 944.6
        },
        {
            x: 581.0,
            y: 882.1
        },
    ], {
        fill: green,
        id: 'x2id158'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 655.0,
            y: 882.1
        },
        {
            x: 592.0,
            y: 882.1
        },
        {
            x: 592.0,
            y: 944.6
        },
        {
            x: 655.0,
            y: 944.6
        },
        {
            x: 655.0,
            y: 882.1
        },
    ], {
        fill: green,
        id: 'x2id159'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 729.0,
            y: 882.1
        },
        {
            x: 666.0,
            y: 882.1
        },
        {
            x: 666.0,
            y: 944.6
        },
        {
            x: 729.0,
            y: 944.6
        },
        {
            x: 729.0,
            y: 882.1
        },
    ], {
        fill: green,
        id: 'x2id160'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 803.0,
            y: 882.1
        },
        {
            x: 740.0,
            y: 882.1
        },
        {
            x: 740.0,
            y: 944.6
        },
        {
            x: 803.0,
            y: 944.6
        },
        {
            x: 803.0,
            y: 882.1
        },
    ], {
        fill: green,
        id: 'x2id161'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 877.0,
            y: 882.1
        },
        {
            x: 814.0,
            y: 882.1
        },
        {
            x: 814.0,
            y: 944.6
        },
        {
            x: 877.0,
            y: 944.6
        },
        {
            x: 877.0,
            y: 882.1
        },
    ], {
        fill: green,
        id: 'x2id162'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 951.0,
            y: 882.1
        },
        {
            x: 888.0,
            y: 882.1
        },
        {
            x: 888.0,
            y: 944.6
        },
        {
            x: 951.0,
            y: 944.6
        },
        {
            x: 951.0,
            y: 882.1
        },
    ], {
        fill: green,
        id: 'x2id163'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 1025.0,
            y: 882.1
        },
        {
            x: 962.0,
            y: 882.1
        },
        {
            x: 962.0,
            y: 944.6
        },
        {
            x: 1025.0,
            y: 944.6
        },
        {
            x: 1025.0,
            y: 882.1
        },
    ], {
        fill: green,
        id: 'x2id164'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 1099.0,
            y: 882.1
        },
        {
            x: 1036.0,
            y: 882.1
        },
        {
            x: 1036.0,
            y: 944.6
        },
        {
            x: 1099.0,
            y: 944.6
        },
        {
            x: 1099.0,
            y: 882.1
        },
    ], {
        fill: green,
        id: 'x2id165'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 63.0,
            y: 955.6
        },
        {
            x: 0.0,
            y: 955.6
        },
        {
            x: 0.0,
            y: 1018.1
        },
        {
            x: 63.0,
            y: 1018.1
        },
        {
            x: 63.0,
            y: 955.6
        },
    ], {
        fill: green,
        id: 'x2id166'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 137.0,
            y: 955.6
        },
        {
            x: 74.0,
            y: 955.6
        },
        {
            x: 74.0,
            y: 1018.1
        },
        {
            x: 137.0,
            y: 1018.1
        },
        {
            x: 137.0,
            y: 955.6
        },
    ], {
        fill: green,
        id: 'x2id167'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 211.0,
            y: 955.6
        },
        {
            x: 148.0,
            y: 955.6
        },
        {
            x: 148.0,
            y: 1018.1
        },
        {
            x: 211.0,
            y: 1018.1
        },
        {
            x: 211.0,
            y: 955.6
        },
    ], {
        fill: green,
        id: 'x2id168'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 285.0,
            y: 955.6
        },
        {
            x: 222.0,
            y: 955.6
        },
        {
            x: 222.0,
            y: 1018.1
        },
        {
            x: 285.0,
            y: 1018.1
        },
        {
            x: 285.0,
            y: 955.6
        },
    ], {
        fill: green,
        id: 'x2id169'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 359.0,
            y: 955.6
        },
        {
            x: 296.0,
            y: 955.6
        },
        {
            x: 296.0,
            y: 1018.1
        },
        {
            x: 359.0,
            y: 1018.1
        },
        {
            x: 359.0,
            y: 955.6
        },
    ], {
        fill: green,
        id: 'x2id170'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 433.0,
            y: 955.6
        },
        {
            x: 370.0,
            y: 955.6
        },
        {
            x: 370.0,
            y: 1018.1
        },
        {
            x: 433.0,
            y: 1018.1
        },
        {
            x: 433.0,
            y: 955.6
        },
    ], {
        fill: green,
        id: 'x2id171'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 507.0,
            y: 955.6
        },
        {
            x: 444.0,
            y: 955.6
        },
        {
            x: 444.0,
            y: 1018.1
        },
        {
            x: 507.0,
            y: 1018.1
        },
        {
            x: 507.0,
            y: 955.6
        },
    ], {
        fill: green,
        id: 'x2id172'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 581.0,
            y: 955.6
        },
        {
            x: 518.0,
            y: 955.6
        },
        {
            x: 518.0,
            y: 1018.1
        },
        {
            x: 581.0,
            y: 1018.1
        },
        {
            x: 581.0,
            y: 955.6
        },
    ], {
        fill: green,
        id: 'x2id173'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 655.0,
            y: 955.6
        },
        {
            x: 592.0,
            y: 955.6
        },
        {
            x: 592.0,
            y: 1018.1
        },
        {
            x: 655.0,
            y: 1018.1
        },
        {
            x: 655.0,
            y: 955.6
        },
    ], {
        fill: green,
        id: 'x2id174'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 729.0,
            y: 955.6
        },
        {
            x: 666.0,
            y: 955.6
        },
        {
            x: 666.0,
            y: 1018.1
        },
        {
            x: 729.0,
            y: 1018.1
        },
        {
            x: 729.0,
            y: 955.6
        },
    ], {
        fill: green,
        id: 'x2id175'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 803.0,
            y: 955.6
        },
        {
            x: 740.0,
            y: 955.6
        },
        {
            x: 740.0,
            y: 1018.1
        },
        {
            x: 803.0,
            y: 1018.1
        },
        {
            x: 803.0,
            y: 955.6
        },
    ], {
        fill: green,
        id: 'x2id176'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 877.0,
            y: 955.6
        },
        {
            x: 814.0,
            y: 955.6
        },
        {
            x: 814.0,
            y: 1018.1
        },
        {
            x: 877.0,
            y: 1018.1
        },
        {
            x: 877.0,
            y: 955.6
        },
    ], {
        fill: green,
        id: 'x2id177'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 951.0,
            y: 955.6
        },
        {
            x: 888.0,
            y: 955.6
        },
        {
            x: 888.0,
            y: 1018.1
        },
        {
            x: 951.0,
            y: 1018.1
        },
        {
            x: 951.0,
            y: 955.6
        },
    ], {
        fill: green,
        id: 'x2id178'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 1025.0,
            y: 955.6
        },
        {
            x: 962.0,
            y: 955.6
        },
        {
            x: 962.0,
            y: 1018.1
        },
        {
            x: 1025.0,
            y: 1018.1
        },
        {
            x: 1025.0,
            y: 955.6
        },
    ], {
        fill: green,
        id: 'x2id179'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 1099.0,
            y: 955.6
        },
        {
            x: 1036.0,
            y: 955.6
        },
        {
            x: 1036.0,
            y: 1018.1
        },
        {
            x: 1099.0,
            y: 1018.1
        },
        {
            x: 1099.0,
            y: 955.6
        },
    ], {
        fill: green,
        id: 'x2id180'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 63.0,
            y: 1029.1
        },
        {
            x: 0.0,
            y: 1029.1
        },
        {
            x: 0.0,
            y: 1091.6
        },
        {
            x: 63.0,
            y: 1091.6
        },
        {
            x: 63.0,
            y: 1029.1
        },
    ], {
        fill: green,
        id: 'x2id181'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 137.0,
            y: 1029.1
        },
        {
            x: 74.0,
            y: 1029.1
        },
        {
            x: 74.0,
            y: 1091.6
        },
        {
            x: 137.0,
            y: 1091.6
        },
        {
            x: 137.0,
            y: 1029.1
        },
    ], {
        fill: green,
        id: 'x2id182'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 211.0,
            y: 1029.1
        },
        {
            x: 148.0,
            y: 1029.1
        },
        {
            x: 148.0,
            y: 1091.6
        },
        {
            x: 211.0,
            y: 1091.6
        },
        {
            x: 211.0,
            y: 1029.1
        },
    ], {
        fill: green,
        id: 'x2id183'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 285.0,
            y: 1029.1
        },
        {
            x: 222.0,
            y: 1029.1
        },
        {
            x: 222.0,
            y: 1091.6
        },
        {
            x: 285.0,
            y: 1091.6
        },
        {
            x: 285.0,
            y: 1029.1
        },
    ], {
        fill: green,
        id: 'x2id184'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 359.0,
            y: 1029.1
        },
        {
            x: 296.0,
            y: 1029.1
        },
        {
            x: 296.0,
            y: 1091.6
        },
        {
            x: 359.0,
            y: 1091.6
        },
        {
            x: 359.0,
            y: 1029.1
        },
    ], {
        fill: green,
        id: 'x2id185'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 433.0,
            y: 1029.1
        },
        {
            x: 370.0,
            y: 1029.1
        },
        {
            x: 370.0,
            y: 1091.6
        },
        {
            x: 433.0,
            y: 1091.6
        },
        {
            x: 433.0,
            y: 1029.1
        },
    ], {
        fill: green,
        id: 'x2id186'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 507.0,
            y: 1029.1
        },
        {
            x: 444.0,
            y: 1029.1
        },
        {
            x: 444.0,
            y: 1091.6
        },
        {
            x: 507.0,
            y: 1091.6
        },
        {
            x: 507.0,
            y: 1029.1
        },
    ], {
        fill: green,
        id: 'x2id187'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 581.0,
            y: 1029.1
        },
        {
            x: 518.0,
            y: 1029.1
        },
        {
            x: 518.0,
            y: 1091.6
        },
        {
            x: 581.0,
            y: 1091.6
        },
        {
            x: 581.0,
            y: 1029.1
        },
    ], {
        fill: green,
        id: 'x2id188'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 655.0,
            y: 1029.1
        },
        {
            x: 592.0,
            y: 1029.1
        },
        {
            x: 592.0,
            y: 1091.6
        },
        {
            x: 655.0,
            y: 1091.6
        },
        {
            x: 655.0,
            y: 1029.1
        },
    ], {
        fill: green,
        id: 'x2id189'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 729.0,
            y: 1029.1
        },
        {
            x: 666.0,
            y: 1029.1
        },
        {
            x: 666.0,
            y: 1091.6
        },
        {
            x: 729.0,
            y: 1091.6
        },
        {
            x: 729.0,
            y: 1029.1
        },
    ], {
        fill: green,
        id: 'x2id190'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 803.0,
            y: 1029.1
        },
        {
            x: 740.0,
            y: 1029.1
        },
        {
            x: 740.0,
            y: 1091.6
        },
        {
            x: 803.0,
            y: 1091.6
        },
        {
            x: 803.0,
            y: 1029.1
        },
    ], {
        fill: green,
        id: 'x2id191'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 877.0,
            y: 1029.1
        },
        {
            x: 814.0,
            y: 1029.1
        },
        {
            x: 814.0,
            y: 1091.6
        },
        {
            x: 877.0,
            y: 1091.6
        },
        {
            x: 877.0,
            y: 1029.1
        },
    ], {
        fill: green,
        id: 'x2id192'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 951.0,
            y: 1029.1
        },
        {
            x: 888.0,
            y: 1029.1
        },
        {
            x: 888.0,
            y: 1091.6
        },
        {
            x: 951.0,
            y: 1091.6
        },
        {
            x: 951.0,
            y: 1029.1
        },
    ], {
        fill: green,
        id: 'x2id193'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 1025.0,
            y: 1029.1
        },
        {
            x: 962.0,
            y: 1029.1
        },
        {
            x: 962.0,
            y: 1091.6
        },
        {
            x: 1025.0,
            y: 1091.6
        },
        {
            x: 1025.0,
            y: 1029.1
        },
    ], {
        fill: green,
        id: 'x2id194'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 1099.0,
            y: 1029.1
        },
        {
            x: 1036.0,
            y: 1029.1
        },
        {
            x: 1036.0,
            y: 1091.6
        },
        {
            x: 1099.0,
            y: 1091.6
        },
        {
            x: 1099.0,
            y: 1029.1
        },
    ], {
        fill: green,
        id: 'x2id195'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 803.0,
            y: 367.5
        },
        {
            x: 740.0,
            y: 367.5
        },
        {
            x: 740.0,
            y: 430.0
        },
        {
            x: 803.0,
            y: 430.0
        },
        {
            x: 803.0,
            y: 367.5
        },
    ], {
        fill: green,
        id: 'x2id196'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 803.0,
            y: 441.0
        },
        {
            x: 740.0,
            y: 441.0
        },
        {
            x: 740.0,
            y: 503.6
        },
        {
            x: 803.0,
            y: 503.6
        },
        {
            x: 803.0,
            y: 441.0
        },
    ], {
        fill: green,
        id: 'x2id197'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 803.0,
            y: 514.6
        },
        {
            x: 740.0,
            y: 514.6
        },
        {
            x: 740.0,
            y: 577.1
        },
        {
            x: 803.0,
            y: 577.1
        },
        {
            x: 803.0,
            y: 514.6
        },
    ], {
        fill: green,
        id: 'x2id198'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 803.0,
            y: 588.1
        },
        {
            x: 740.0,
            y: 588.1
        },
        {
            x: 740.0,
            y: 650.6
        },
        {
            x: 803.0,
            y: 650.6
        },
        {
            x: 803.0,
            y: 588.1
        },
    ], {
        fill: green,
        id: 'x2id199'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 803.0,
            y: 661.4
        },
        {
            x: 740.0,
            y: 661.4
        },
        {
            x: 740.0,
            y: 723.9
        },
        {
            x: 803.0,
            y: 723.9
        },
        {
            x: 803.0,
            y: 661.4
        },
    ], {
        fill: green,
        id: 'x2id200'
    }))
    canvas2.add(new fabric.Polygon([{
            x: 726.5,
            y: 724.1
        },
        {
            x: 370.0,
            y: 724.1
        },
        {
            x: 370.0,
            y: 367.5
        },
        {
            x: 726.5,
            y: 367.5
        },
        {
            x: 726.5,
            y: 724.1
        },
    ], {
        fill: green,
        id: 'x2id201'
    }))
</script>
