<script>
    canvas3.add(new fabric.Polygon([{
            x: 0.0,
            y: 0.0
        },
        {
            x: 0.0,
            y: 62.5
        },
        {
            x: 63.0,
            y: 62.5
        },
        {
            x: 63.0,
            y: 0.0
        },
    ], {
        fill: green,
        id: 'x3id1'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 137.0,
            y: 0.0
        },
        {
            x: 74.0,
            y: 0.0
        },
        {
            x: 74.0,
            y: 62.5
        },
        {
            x: 137.0,
            y: 62.5
        },
        {
            x: 137.0,
            y: 0.0
        },
    ], {
        fill: green,
        id: 'x3id2'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 211.0,
            y: 0.0
        },
        {
            x: 148.0,
            y: 0.0
        },
        {
            x: 148.0,
            y: 62.5
        },
        {
            x: 211.0,
            y: 62.5
        },
        {
            x: 211.0,
            y: 0.0
        },
    ], {
        fill: green,
        id: 'x3id3'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 285.0,
            y: 0.0
        },
        {
            x: 222.0,
            y: 0.0
        },
        {
            x: 222.0,
            y: 62.5
        },
        {
            x: 285.0,
            y: 62.5
        },
        {
            x: 285.0,
            y: 0.0
        },
    ], {
        fill: green,
        id: 'x3id4'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 359.0,
            y: 0.0
        },
        {
            x: 296.0,
            y: 0.0
        },
        {
            x: 296.0,
            y: 62.5
        },
        {
            x: 359.0,
            y: 62.5
        },
        {
            x: 359.0,
            y: 0.0
        },
    ], {
        fill: green,
        id: 'x3id5'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 433.0,
            y: 0.0
        },
        {
            x: 370.0,
            y: 0.0
        },
        {
            x: 370.0,
            y: 62.5
        },
        {
            x: 433.0,
            y: 62.5
        },
        {
            x: 433.0,
            y: 0.0
        },
    ], {
        fill: green,
        id: 'x3id6'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 507.0,
            y: 0.0
        },
        {
            x: 444.0,
            y: 0.0
        },
        {
            x: 444.0,
            y: 62.5
        },
        {
            x: 507.0,
            y: 62.5
        },
        {
            x: 507.0,
            y: 0.0
        },
    ], {
        fill: green,
        id: 'x3id7'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 581.0,
            y: 0.0
        },
        {
            x: 518.0,
            y: 0.0
        },
        {
            x: 518.0,
            y: 62.5
        },
        {
            x: 581.0,
            y: 62.5
        },
        {
            x: 581.0,
            y: 0.0
        },
    ], {
        fill: green,
        id: 'x3id8'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 655.0,
            y: 0.0
        },
        {
            x: 592.0,
            y: 0.0
        },
        {
            x: 592.0,
            y: 62.5
        },
        {
            x: 655.0,
            y: 62.5
        },
        {
            x: 655.0,
            y: 0.0
        },
    ], {
        fill: green,
        id: 'x3id9'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 729.0,
            y: 0.0
        },
        {
            x: 666.0,
            y: 0.0
        },
        {
            x: 666.0,
            y: 62.5
        },
        {
            x: 729.0,
            y: 62.5
        },
        {
            x: 729.0,
            y: 0.0
        },
    ], {
        fill: green,
        id: 'x3id10'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 803.0,
            y: 0.0
        },
        {
            x: 740.0,
            y: 0.0
        },
        {
            x: 740.0,
            y: 62.5
        },
        {
            x: 803.0,
            y: 62.5
        },
        {
            x: 803.0,
            y: 0.0
        },
    ], {
        fill: green,
        id: 'x3id11'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 877.0,
            y: 0.0
        },
        {
            x: 814.0,
            y: 0.0
        },
        {
            x: 814.0,
            y: 62.5
        },
        {
            x: 877.0,
            y: 62.5
        },
        {
            x: 877.0,
            y: 0.0
        },
    ], {
        fill: green,
        id: 'x3id12'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 951.0,
            y: 0.0
        },
        {
            x: 888.0,
            y: 0.0
        },
        {
            x: 888.0,
            y: 62.5
        },
        {
            x: 951.0,
            y: 62.5
        },
        {
            x: 951.0,
            y: 0.0
        },
    ], {
        fill: green,
        id: 'x3id13'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 1025.0,
            y: 0.0
        },
        {
            x: 962.0,
            y: 0.0
        },
        {
            x: 962.0,
            y: 62.5
        },
        {
            x: 1025.0,
            y: 62.5
        },
        {
            x: 1025.0,
            y: 0.0
        },
    ], {
        fill: green,
        id: 'x3id14'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 1099.0,
            y: 0.0
        },
        {
            x: 1036.0,
            y: 0.0
        },
        {
            x: 1036.0,
            y: 62.5
        },
        {
            x: 1099.0,
            y: 62.5
        },
        {
            x: 1099.0,
            y: 0.0
        },
    ], {
        fill: green,
        id: 'x3id15'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 63.0,
            y: 73.5
        },
        {
            x: 0.0,
            y: 73.5
        },
        {
            x: 0.0,
            y: 136.0
        },
        {
            x: 63.0,
            y: 136.0
        },
        {
            x: 63.0,
            y: 73.5
        },
    ], {
        fill: green,
        id: 'x3id16'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 137.0,
            y: 73.5
        },
        {
            x: 74.0,
            y: 73.5
        },
        {
            x: 74.0,
            y: 136.0
        },
        {
            x: 137.0,
            y: 136.0
        },
        {
            x: 137.0,
            y: 73.5
        },
    ], {
        fill: green,
        id: 'x3id17'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 211.0,
            y: 73.5
        },
        {
            x: 148.0,
            y: 73.5
        },
        {
            x: 148.0,
            y: 136.0
        },
        {
            x: 211.0,
            y: 136.0
        },
        {
            x: 211.0,
            y: 73.5
        },
    ], {
        fill: green,
        id: 'x3id18'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 285.0,
            y: 73.5
        },
        {
            x: 222.0,
            y: 73.5
        },
        {
            x: 222.0,
            y: 136.0
        },
        {
            x: 285.0,
            y: 136.0
        },
        {
            x: 285.0,
            y: 73.5
        },
    ], {
        fill: green,
        id: 'x3id19'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 359.0,
            y: 73.5
        },
        {
            x: 296.0,
            y: 73.5
        },
        {
            x: 296.0,
            y: 136.0
        },
        {
            x: 359.0,
            y: 136.0
        },
        {
            x: 359.0,
            y: 73.5
        },
    ], {
        fill: green,
        id: 'x3id20'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 433.0,
            y: 73.5
        },
        {
            x: 370.0,
            y: 73.5
        },
        {
            x: 370.0,
            y: 136.0
        },
        {
            x: 433.0,
            y: 136.0
        },
        {
            x: 433.0,
            y: 73.5
        },
    ], {
        fill: green,
        id: 'x3id21'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 507.0,
            y: 73.5
        },
        {
            x: 444.0,
            y: 73.5
        },
        {
            x: 444.0,
            y: 136.0
        },
        {
            x: 507.0,
            y: 136.0
        },
        {
            x: 507.0,
            y: 73.5
        },
    ], {
        fill: green,
        id: 'x3id22'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 581.0,
            y: 73.5
        },
        {
            x: 518.0,
            y: 73.5
        },
        {
            x: 518.0,
            y: 136.0
        },
        {
            x: 581.0,
            y: 136.0
        },
        {
            x: 581.0,
            y: 73.5
        },
    ], {
        fill: green,
        id: 'x3id23'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 655.0,
            y: 73.5
        },
        {
            x: 592.0,
            y: 73.5
        },
        {
            x: 592.0,
            y: 136.0
        },
        {
            x: 655.0,
            y: 136.0
        },
        {
            x: 655.0,
            y: 73.5
        },
    ], {
        fill: green,
        id: 'x3id24'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 729.0,
            y: 73.5
        },
        {
            x: 666.0,
            y: 73.5
        },
        {
            x: 666.0,
            y: 136.0
        },
        {
            x: 729.0,
            y: 136.0
        },
        {
            x: 729.0,
            y: 73.5
        },
    ], {
        fill: green,
        id: 'x3id25'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 803.0,
            y: 73.5
        },
        {
            x: 740.0,
            y: 73.5
        },
        {
            x: 740.0,
            y: 136.0
        },
        {
            x: 803.0,
            y: 136.0
        },
        {
            x: 803.0,
            y: 73.5
        },
    ], {
        fill: green,
        id: 'x3id26'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 877.0,
            y: 73.5
        },
        {
            x: 814.0,
            y: 73.5
        },
        {
            x: 814.0,
            y: 136.0
        },
        {
            x: 877.0,
            y: 136.0
        },
        {
            x: 877.0,
            y: 73.5
        },
    ], {
        fill: green,
        id: 'x3id27'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 951.0,
            y: 73.5
        },
        {
            x: 888.0,
            y: 73.5
        },
        {
            x: 888.0,
            y: 136.0
        },
        {
            x: 951.0,
            y: 136.0
        },
        {
            x: 951.0,
            y: 73.5
        },
    ], {
        fill: green,
        id: 'x3id28'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 1025.0,
            y: 73.5
        },
        {
            x: 962.0,
            y: 73.5
        },
        {
            x: 962.0,
            y: 136.0
        },
        {
            x: 1025.0,
            y: 136.0
        },
        {
            x: 1025.0,
            y: 73.5
        },
    ], {
        fill: green,
        id: 'x3id29'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 1099.0,
            y: 73.5
        },
        {
            x: 1036.0,
            y: 73.5
        },
        {
            x: 1036.0,
            y: 136.0
        },
        {
            x: 1099.0,
            y: 136.0
        },
        {
            x: 1099.0,
            y: 73.5
        },
    ], {
        fill: green,
        id: 'x3id30'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 63.0,
            y: 147.0
        },
        {
            x: 0.0,
            y: 147.0
        },
        {
            x: 0.0,
            y: 209.5
        },
        {
            x: 63.0,
            y: 209.5
        },
        {
            x: 63.0,
            y: 147.0
        },
    ], {
        fill: green,
        id: 'x3id31'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 137.0,
            y: 147.0
        },
        {
            x: 74.0,
            y: 147.0
        },
        {
            x: 74.0,
            y: 209.5
        },
        {
            x: 137.0,
            y: 209.5
        },
        {
            x: 137.0,
            y: 147.0
        },
    ], {
        fill: green,
        id: 'x3id32'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 211.0,
            y: 147.0
        },
        {
            x: 148.0,
            y: 147.0
        },
        {
            x: 148.0,
            y: 209.5
        },
        {
            x: 211.0,
            y: 209.5
        },
        {
            x: 211.0,
            y: 147.0
        },
    ], {
        fill: green,
        id: 'x3id33'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 285.0,
            y: 147.0
        },
        {
            x: 222.0,
            y: 147.0
        },
        {
            x: 222.0,
            y: 209.5
        },
        {
            x: 285.0,
            y: 209.5
        },
        {
            x: 285.0,
            y: 147.0
        },
    ], {
        fill: green,
        id: 'x3id34'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 359.0,
            y: 147.0
        },
        {
            x: 296.0,
            y: 147.0
        },
        {
            x: 296.0,
            y: 209.5
        },
        {
            x: 359.0,
            y: 209.5
        },
        {
            x: 359.0,
            y: 147.0
        },
    ], {
        fill: green,
        id: 'x3id35'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 433.0,
            y: 147.0
        },
        {
            x: 370.0,
            y: 147.0
        },
        {
            x: 370.0,
            y: 209.5
        },
        {
            x: 433.0,
            y: 209.5
        },
        {
            x: 433.0,
            y: 147.0
        },
    ], {
        fill: green,
        id: 'x3id36'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 507.0,
            y: 147.0
        },
        {
            x: 444.0,
            y: 147.0
        },
        {
            x: 444.0,
            y: 209.5
        },
        {
            x: 507.0,
            y: 209.5
        },
        {
            x: 507.0,
            y: 147.0
        },
    ], {
        fill: green,
        id: 'x3id37'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 581.0,
            y: 147.0
        },
        {
            x: 518.0,
            y: 147.0
        },
        {
            x: 518.0,
            y: 209.5
        },
        {
            x: 581.0,
            y: 209.5
        },
        {
            x: 581.0,
            y: 147.0
        },
    ], {
        fill: green,
        id: 'x3id38'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 655.0,
            y: 147.0
        },
        {
            x: 592.0,
            y: 147.0
        },
        {
            x: 592.0,
            y: 209.5
        },
        {
            x: 655.0,
            y: 209.5
        },
        {
            x: 655.0,
            y: 147.0
        },
    ], {
        fill: green,
        id: 'x3id39'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 729.0,
            y: 147.0
        },
        {
            x: 666.0,
            y: 147.0
        },
        {
            x: 666.0,
            y: 209.5
        },
        {
            x: 729.0,
            y: 209.5
        },
        {
            x: 729.0,
            y: 147.0
        },
    ], {
        fill: green,
        id: 'x3id40'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 803.0,
            y: 147.0
        },
        {
            x: 740.0,
            y: 147.0
        },
        {
            x: 740.0,
            y: 209.5
        },
        {
            x: 803.0,
            y: 209.5
        },
        {
            x: 803.0,
            y: 147.0
        },
    ], {
        fill: green,
        id: 'x3id41'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 877.0,
            y: 147.0
        },
        {
            x: 814.0,
            y: 147.0
        },
        {
            x: 814.0,
            y: 209.5
        },
        {
            x: 877.0,
            y: 209.5
        },
        {
            x: 877.0,
            y: 147.0
        },
    ], {
        fill: green,
        id: 'x3id42'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 951.0,
            y: 147.0
        },
        {
            x: 888.0,
            y: 147.0
        },
        {
            x: 888.0,
            y: 209.5
        },
        {
            x: 951.0,
            y: 209.5
        },
        {
            x: 951.0,
            y: 147.0
        },
    ], {
        fill: green,
        id: 'x3id43'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 1025.0,
            y: 147.0
        },
        {
            x: 962.0,
            y: 147.0
        },
        {
            x: 962.0,
            y: 209.5
        },
        {
            x: 1025.0,
            y: 209.5
        },
        {
            x: 1025.0,
            y: 147.0
        },
    ], {
        fill: green,
        id: 'x3id44'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 1099.0,
            y: 147.0
        },
        {
            x: 1036.0,
            y: 147.0
        },
        {
            x: 1036.0,
            y: 209.5
        },
        {
            x: 1099.0,
            y: 209.5
        },
        {
            x: 1099.0,
            y: 147.0
        },
    ], {
        fill: green,
        id: 'x3id45'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 63.0,
            y: 220.5
        },
        {
            x: 0.0,
            y: 220.5
        },
        {
            x: 0.0,
            y: 283.0
        },
        {
            x: 63.0,
            y: 283.0
        },
        {
            x: 63.0,
            y: 220.5
        },
    ], {
        fill: green,
        id: 'x3id46'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 137.0,
            y: 220.5
        },
        {
            x: 74.0,
            y: 220.5
        },
        {
            x: 74.0,
            y: 283.0
        },
        {
            x: 137.0,
            y: 283.0
        },
        {
            x: 137.0,
            y: 220.5
        },
    ], {
        fill: green,
        id: 'x3id47'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 211.0,
            y: 220.5
        },
        {
            x: 148.0,
            y: 220.5
        },
        {
            x: 148.0,
            y: 283.0
        },
        {
            x: 211.0,
            y: 283.0
        },
        {
            x: 211.0,
            y: 220.5
        },
    ], {
        fill: green,
        id: 'x3id48'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 285.0,
            y: 220.5
        },
        {
            x: 222.0,
            y: 220.5
        },
        {
            x: 222.0,
            y: 283.0
        },
        {
            x: 285.0,
            y: 283.0
        },
        {
            x: 285.0,
            y: 220.5
        },
    ], {
        fill: green,
        id: 'x3id49'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 359.0,
            y: 220.5
        },
        {
            x: 296.0,
            y: 220.5
        },
        {
            x: 296.0,
            y: 283.0
        },
        {
            x: 359.0,
            y: 283.0
        },
        {
            x: 359.0,
            y: 220.5
        },
    ], {
        fill: green,
        id: 'x3id50'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 433.0,
            y: 220.5
        },
        {
            x: 370.0,
            y: 220.5
        },
        {
            x: 370.0,
            y: 283.0
        },
        {
            x: 433.0,
            y: 283.0
        },
        {
            x: 433.0,
            y: 220.5
        },
    ], {
        fill: green,
        id: 'x3id51'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 507.0,
            y: 220.5
        },
        {
            x: 444.0,
            y: 220.5
        },
        {
            x: 444.0,
            y: 283.0
        },
        {
            x: 507.0,
            y: 283.0
        },
        {
            x: 507.0,
            y: 220.5
        },
    ], {
        fill: green,
        id: 'x3id52'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 581.0,
            y: 220.5
        },
        {
            x: 518.0,
            y: 220.5
        },
        {
            x: 518.0,
            y: 283.0
        },
        {
            x: 581.0,
            y: 283.0
        },
        {
            x: 581.0,
            y: 220.5
        },
    ], {
        fill: green,
        id: 'x3id53'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 655.0,
            y: 220.5
        },
        {
            x: 592.0,
            y: 220.5
        },
        {
            x: 592.0,
            y: 283.0
        },
        {
            x: 655.0,
            y: 283.0
        },
        {
            x: 655.0,
            y: 220.5
        },
    ], {
        fill: green,
        id: 'x3id54'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 729.0,
            y: 220.5
        },
        {
            x: 666.0,
            y: 220.5
        },
        {
            x: 666.0,
            y: 283.0
        },
        {
            x: 729.0,
            y: 283.0
        },
        {
            x: 729.0,
            y: 220.5
        },
    ], {
        fill: green,
        id: 'x3id55'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 803.0,
            y: 220.5
        },
        {
            x: 740.0,
            y: 220.5
        },
        {
            x: 740.0,
            y: 283.0
        },
        {
            x: 803.0,
            y: 283.0
        },
        {
            x: 803.0,
            y: 220.5
        },
    ], {
        fill: green,
        id: 'x3id56'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 877.0,
            y: 220.5
        },
        {
            x: 814.0,
            y: 220.5
        },
        {
            x: 814.0,
            y: 283.0
        },
        {
            x: 877.0,
            y: 283.0
        },
        {
            x: 877.0,
            y: 220.5
        },
    ], {
        fill: green,
        id: 'x3id57'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 951.0,
            y: 220.5
        },
        {
            x: 888.0,
            y: 220.5
        },
        {
            x: 888.0,
            y: 283.0
        },
        {
            x: 951.0,
            y: 283.0
        },
        {
            x: 951.0,
            y: 220.5
        },
    ], {
        fill: green,
        id: 'x3id58'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 1025.0,
            y: 220.5
        },
        {
            x: 962.0,
            y: 220.5
        },
        {
            x: 962.0,
            y: 283.0
        },
        {
            x: 1025.0,
            y: 283.0
        },
        {
            x: 1025.0,
            y: 220.5
        },
    ], {
        fill: green,
        id: 'x3id59'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 1099.0,
            y: 220.5
        },
        {
            x: 1036.0,
            y: 220.5
        },
        {
            x: 1036.0,
            y: 283.0
        },
        {
            x: 1099.0,
            y: 283.0
        },
        {
            x: 1099.0,
            y: 220.5
        },
    ], {
        fill: green,
        id: 'x3id60'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 63.0,
            y: 294.0
        },
        {
            x: 0.0,
            y: 294.0
        },
        {
            x: 0.0,
            y: 356.5
        },
        {
            x: 63.0,
            y: 356.5
        },
        {
            x: 63.0,
            y: 294.0
        },
    ], {
        fill: green,
        id: 'x3id61'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 137.0,
            y: 294.0
        },
        {
            x: 74.0,
            y: 294.0
        },
        {
            x: 74.0,
            y: 356.5
        },
        {
            x: 137.0,
            y: 356.5
        },
        {
            x: 137.0,
            y: 294.0
        },
    ], {
        fill: green,
        id: 'x3id62'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 211.0,
            y: 294.0
        },
        {
            x: 148.0,
            y: 294.0
        },
        {
            x: 148.0,
            y: 356.5
        },
        {
            x: 211.0,
            y: 356.5
        },
        {
            x: 211.0,
            y: 294.0
        },
    ], {
        fill: green,
        id: 'x3id63'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 285.0,
            y: 294.0
        },
        {
            x: 222.0,
            y: 294.0
        },
        {
            x: 222.0,
            y: 356.5
        },
        {
            x: 285.0,
            y: 356.5
        },
        {
            x: 285.0,
            y: 294.0
        },
    ], {
        fill: green,
        id: 'x3id64'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 359.0,
            y: 294.0
        },
        {
            x: 296.0,
            y: 294.0
        },
        {
            x: 296.0,
            y: 356.5
        },
        {
            x: 359.0,
            y: 356.5
        },
        {
            x: 359.0,
            y: 294.0
        },
    ], {
        fill: green,
        id: 'x3id65'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 433.0,
            y: 294.0
        },
        {
            x: 370.0,
            y: 294.0
        },
        {
            x: 370.0,
            y: 356.5
        },
        {
            x: 433.0,
            y: 356.5
        },
        {
            x: 433.0,
            y: 294.0
        },
    ], {
        fill: green,
        id: 'x3id66'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 507.0,
            y: 294.0
        },
        {
            x: 444.0,
            y: 294.0
        },
        {
            x: 444.0,
            y: 356.5
        },
        {
            x: 507.0,
            y: 356.5
        },
        {
            x: 507.0,
            y: 294.0
        },
    ], {
        fill: green,
        id: 'x3id67'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 581.0,
            y: 294.0
        },
        {
            x: 518.0,
            y: 294.0
        },
        {
            x: 518.0,
            y: 356.5
        },
        {
            x: 581.0,
            y: 356.5
        },
        {
            x: 581.0,
            y: 294.0
        },
    ], {
        fill: green,
        id: 'x3id68'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 655.0,
            y: 294.0
        },
        {
            x: 592.0,
            y: 294.0
        },
        {
            x: 592.0,
            y: 356.5
        },
        {
            x: 655.0,
            y: 356.5
        },
        {
            x: 655.0,
            y: 294.0
        },
    ], {
        fill: green,
        id: 'x3id69'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 729.0,
            y: 294.0
        },
        {
            x: 666.0,
            y: 294.0
        },
        {
            x: 666.0,
            y: 356.5
        },
        {
            x: 729.0,
            y: 356.5
        },
        {
            x: 729.0,
            y: 294.0
        },
    ], {
        fill: green,
        id: 'x3id70'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 803.0,
            y: 294.0
        },
        {
            x: 740.0,
            y: 294.0
        },
        {
            x: 740.0,
            y: 356.5
        },
        {
            x: 803.0,
            y: 356.5
        },
        {
            x: 803.0,
            y: 294.0
        },
    ], {
        fill: green,
        id: 'x3id71'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 877.0,
            y: 294.0
        },
        {
            x: 814.0,
            y: 294.0
        },
        {
            x: 814.0,
            y: 356.5
        },
        {
            x: 877.0,
            y: 356.5
        },
        {
            x: 877.0,
            y: 294.0
        },
    ], {
        fill: green,
        id: 'x3id72'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 951.0,
            y: 294.0
        },
        {
            x: 888.0,
            y: 294.0
        },
        {
            x: 888.0,
            y: 356.5
        },
        {
            x: 951.0,
            y: 356.5
        },
        {
            x: 951.0,
            y: 294.0
        },
    ], {
        fill: green,
        id: 'x3id73'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 1025.0,
            y: 294.0
        },
        {
            x: 962.0,
            y: 294.0
        },
        {
            x: 962.0,
            y: 356.5
        },
        {
            x: 1025.0,
            y: 356.5
        },
        {
            x: 1025.0,
            y: 294.0
        },
    ], {
        fill: green,
        id: 'x3id74'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 1099.0,
            y: 294.0
        },
        {
            x: 1036.0,
            y: 294.0
        },
        {
            x: 1036.0,
            y: 356.5
        },
        {
            x: 1099.0,
            y: 356.5
        },
        {
            x: 1099.0,
            y: 294.0
        },
    ], {
        fill: green,
        id: 'x3id75'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 63.0,
            y: 367.5
        },
        {
            x: 0.0,
            y: 367.5
        },
        {
            x: 0.0,
            y: 430.0
        },
        {
            x: 63.0,
            y: 430.0
        },
        {
            x: 63.0,
            y: 367.5
        },
    ], {
        fill: green,
        id: 'x3id76'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 137.0,
            y: 367.5
        },
        {
            x: 74.0,
            y: 367.5
        },
        {
            x: 74.0,
            y: 430.0
        },
        {
            x: 137.0,
            y: 430.0
        },
        {
            x: 137.0,
            y: 367.5
        },
    ], {
        fill: green,
        id: 'x3id77'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 211.0,
            y: 367.5
        },
        {
            x: 148.0,
            y: 367.5
        },
        {
            x: 148.0,
            y: 430.0
        },
        {
            x: 211.0,
            y: 430.0
        },
        {
            x: 211.0,
            y: 367.5
        },
    ], {
        fill: green,
        id: 'x3id78'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 285.0,
            y: 367.5
        },
        {
            x: 222.0,
            y: 367.5
        },
        {
            x: 222.0,
            y: 430.0
        },
        {
            x: 285.0,
            y: 430.0
        },
        {
            x: 285.0,
            y: 367.5
        },
    ], {
        fill: green,
        id: 'x3id79'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 359.0,
            y: 367.5
        },
        {
            x: 296.0,
            y: 367.5
        },
        {
            x: 296.0,
            y: 430.0
        },
        {
            x: 359.0,
            y: 430.0
        },
        {
            x: 359.0,
            y: 367.5
        },
    ], {
        fill: green,
        id: 'x3id80'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 877.0,
            y: 367.5
        },
        {
            x: 814.0,
            y: 367.5
        },
        {
            x: 814.0,
            y: 430.0
        },
        {
            x: 877.0,
            y: 430.0
        },
        {
            x: 877.0,
            y: 367.5
        },
    ], {
        fill: green,
        id: 'x3id81'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 951.0,
            y: 367.5
        },
        {
            x: 888.0,
            y: 367.5
        },
        {
            x: 888.0,
            y: 430.0
        },
        {
            x: 951.0,
            y: 430.0
        },
        {
            x: 951.0,
            y: 367.5
        },
    ], {
        fill: green,
        id: 'x3id82'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 1025.0,
            y: 367.5
        },
        {
            x: 962.0,
            y: 367.5
        },
        {
            x: 962.0,
            y: 430.0
        },
        {
            x: 1025.0,
            y: 430.0
        },
        {
            x: 1025.0,
            y: 367.5
        },
    ], {
        fill: green,
        id: 'x3id83'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 1099.0,
            y: 367.5
        },
        {
            x: 1036.0,
            y: 367.5
        },
        {
            x: 1036.0,
            y: 430.0
        },
        {
            x: 1099.0,
            y: 430.0
        },
        {
            x: 1099.0,
            y: 367.5
        },
    ], {
        fill: green,
        id: 'x3id84'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 63.0,
            y: 441.0
        },
        {
            x: 0.0,
            y: 441.0
        },
        {
            x: 0.0,
            y: 503.6
        },
        {
            x: 63.0,
            y: 503.6
        },
        {
            x: 63.0,
            y: 441.0
        },
    ], {
        fill: green,
        id: 'x3id85'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 137.0,
            y: 441.0
        },
        {
            x: 74.0,
            y: 441.0
        },
        {
            x: 74.0,
            y: 503.6
        },
        {
            x: 137.0,
            y: 503.6
        },
        {
            x: 137.0,
            y: 441.0
        },
    ], {
        fill: green,
        id: 'x3id86'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 211.0,
            y: 441.0
        },
        {
            x: 148.0,
            y: 441.0
        },
        {
            x: 148.0,
            y: 503.6
        },
        {
            x: 211.0,
            y: 503.6
        },
        {
            x: 211.0,
            y: 441.0
        },
    ], {
        fill: green,
        id: 'x3id87'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 285.0,
            y: 441.0
        },
        {
            x: 222.0,
            y: 441.0
        },
        {
            x: 222.0,
            y: 503.6
        },
        {
            x: 285.0,
            y: 503.6
        },
        {
            x: 285.0,
            y: 441.0
        },
    ], {
        fill: green,
        id: 'x3id88'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 359.0,
            y: 441.0
        },
        {
            x: 296.0,
            y: 441.0
        },
        {
            x: 296.0,
            y: 503.6
        },
        {
            x: 359.0,
            y: 503.6
        },
        {
            x: 359.0,
            y: 441.0
        },
    ], {
        fill: green,
        id: 'x3id89'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 877.0,
            y: 441.0
        },
        {
            x: 814.0,
            y: 441.0
        },
        {
            x: 814.0,
            y: 503.6
        },
        {
            x: 877.0,
            y: 503.6
        },
        {
            x: 877.0,
            y: 441.0
        },
    ], {
        fill: green,
        id: 'x3id90'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 951.0,
            y: 441.0
        },
        {
            x: 888.0,
            y: 441.0
        },
        {
            x: 888.0,
            y: 503.6
        },
        {
            x: 951.0,
            y: 503.6
        },
        {
            x: 951.0,
            y: 441.0
        },
    ], {
        fill: green,
        id: 'x3id91'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 1025.0,
            y: 441.0
        },
        {
            x: 962.0,
            y: 441.0
        },
        {
            x: 962.0,
            y: 503.6
        },
        {
            x: 1025.0,
            y: 503.6
        },
        {
            x: 1025.0,
            y: 441.0
        },
    ], {
        fill: green,
        id: 'x3id92'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 1099.0,
            y: 441.0
        },
        {
            x: 1036.0,
            y: 441.0
        },
        {
            x: 1036.0,
            y: 503.6
        },
        {
            x: 1099.0,
            y: 503.6
        },
        {
            x: 1099.0,
            y: 441.0
        },
    ], {
        fill: green,
        id: 'x3id93'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 63.0,
            y: 514.6
        },
        {
            x: 0.0,
            y: 514.6
        },
        {
            x: 0.0,
            y: 577.1
        },
        {
            x: 63.0,
            y: 577.1
        },
        {
            x: 63.0,
            y: 514.6
        },
    ], {
        fill: green,
        id: 'x3id94'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 137.0,
            y: 514.6
        },
        {
            x: 74.0,
            y: 514.6
        },
        {
            x: 74.0,
            y: 577.1
        },
        {
            x: 137.0,
            y: 577.1
        },
        {
            x: 137.0,
            y: 514.6
        },
    ], {
        fill: green,
        id: 'x3id95'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 211.0,
            y: 514.6
        },
        {
            x: 148.0,
            y: 514.6
        },
        {
            x: 148.0,
            y: 577.1
        },
        {
            x: 211.0,
            y: 577.1
        },
        {
            x: 211.0,
            y: 514.6
        },
    ], {
        fill: green,
        id: 'x3id96'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 285.0,
            y: 514.6
        },
        {
            x: 222.0,
            y: 514.6
        },
        {
            x: 222.0,
            y: 577.1
        },
        {
            x: 285.0,
            y: 577.1
        },
        {
            x: 285.0,
            y: 514.6
        },
    ], {
        fill: green,
        id: 'x3id97'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 359.0,
            y: 514.6
        },
        {
            x: 296.0,
            y: 514.6
        },
        {
            x: 296.0,
            y: 577.1
        },
        {
            x: 359.0,
            y: 577.1
        },
        {
            x: 359.0,
            y: 514.6
        },
    ], {
        fill: green,
        id: 'x3id98'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 877.0,
            y: 514.6
        },
        {
            x: 814.0,
            y: 514.6
        },
        {
            x: 814.0,
            y: 577.1
        },
        {
            x: 877.0,
            y: 577.1
        },
        {
            x: 877.0,
            y: 514.6
        },
    ], {
        fill: green,
        id: 'x3id99'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 951.0,
            y: 514.6
        },
        {
            x: 888.0,
            y: 514.6
        },
        {
            x: 888.0,
            y: 577.1
        },
        {
            x: 951.0,
            y: 577.1
        },
        {
            x: 951.0,
            y: 514.6
        },
    ], {
        fill: green,
        id: 'x3id100'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 1025.0,
            y: 514.6
        },
        {
            x: 962.0,
            y: 514.6
        },
        {
            x: 962.0,
            y: 577.1
        },
        {
            x: 1025.0,
            y: 577.1
        },
        {
            x: 1025.0,
            y: 514.6
        },
    ], {
        fill: green,
        id: 'x3id101'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 1099.0,
            y: 514.6
        },
        {
            x: 1036.0,
            y: 514.6
        },
        {
            x: 1036.0,
            y: 577.1
        },
        {
            x: 1099.0,
            y: 577.1
        },
        {
            x: 1099.0,
            y: 514.6
        },
    ], {
        fill: green,
        id: 'x3id102'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 63.0,
            y: 588.1
        },
        {
            x: 0.0,
            y: 588.1
        },
        {
            x: 0.0,
            y: 650.6
        },
        {
            x: 63.0,
            y: 650.6
        },
        {
            x: 63.0,
            y: 588.1
        },
    ], {
        fill: green,
        id: 'x3id103'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 137.0,
            y: 588.1
        },
        {
            x: 74.0,
            y: 588.1
        },
        {
            x: 74.0,
            y: 650.6
        },
        {
            x: 137.0,
            y: 650.6
        },
        {
            x: 137.0,
            y: 588.1
        },
    ], {
        fill: green,
        id: 'x3id104'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 211.0,
            y: 588.1
        },
        {
            x: 148.0,
            y: 588.1
        },
        {
            x: 148.0,
            y: 650.6
        },
        {
            x: 211.0,
            y: 650.6
        },
        {
            x: 211.0,
            y: 588.1
        },
    ], {
        fill: green,
        id: 'x3id105'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 285.0,
            y: 588.1
        },
        {
            x: 222.0,
            y: 588.1
        },
        {
            x: 222.0,
            y: 650.6
        },
        {
            x: 285.0,
            y: 650.6
        },
        {
            x: 285.0,
            y: 588.1
        },
    ], {
        fill: green,
        id: 'x3id106'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 359.0,
            y: 588.1
        },
        {
            x: 296.0,
            y: 588.1
        },
        {
            x: 296.0,
            y: 650.6
        },
        {
            x: 359.0,
            y: 650.6
        },
        {
            x: 359.0,
            y: 588.1
        },
    ], {
        fill: green,
        id: 'x3id107'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 877.0,
            y: 588.1
        },
        {
            x: 814.0,
            y: 588.1
        },
        {
            x: 814.0,
            y: 650.6
        },
        {
            x: 877.0,
            y: 650.6
        },
        {
            x: 877.0,
            y: 588.1
        },
    ], {
        fill: green,
        id: 'x3id108'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 951.0,
            y: 588.1
        },
        {
            x: 888.0,
            y: 588.1
        },
        {
            x: 888.0,
            y: 650.6
        },
        {
            x: 951.0,
            y: 650.6
        },
        {
            x: 951.0,
            y: 588.1
        },
    ], {
        fill: green,
        id: 'x3id109'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 1025.0,
            y: 588.1
        },
        {
            x: 962.0,
            y: 588.1
        },
        {
            x: 962.0,
            y: 650.6
        },
        {
            x: 1025.0,
            y: 650.6
        },
        {
            x: 1025.0,
            y: 588.1
        },
    ], {
        fill: green,
        id: 'x3id110'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 1099.0,
            y: 588.1
        },
        {
            x: 1036.0,
            y: 588.1
        },
        {
            x: 1036.0,
            y: 650.6
        },
        {
            x: 1099.0,
            y: 650.6
        },
        {
            x: 1099.0,
            y: 588.1
        },
    ], {
        fill: green,
        id: 'x3id111'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 63.0,
            y: 661.6
        },
        {
            x: 0.0,
            y: 661.6
        },
        {
            x: 0.0,
            y: 724.1
        },
        {
            x: 63.0,
            y: 724.1
        },
        {
            x: 63.0,
            y: 661.6
        },
    ], {
        fill: green,
        id: 'x3id112'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 137.0,
            y: 661.6
        },
        {
            x: 74.0,
            y: 661.6
        },
        {
            x: 74.0,
            y: 724.1
        },
        {
            x: 137.0,
            y: 724.1
        },
        {
            x: 137.0,
            y: 661.6
        },
    ], {
        fill: green,
        id: 'x3id113'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 211.0,
            y: 661.6
        },
        {
            x: 148.0,
            y: 661.6
        },
        {
            x: 148.0,
            y: 724.1
        },
        {
            x: 211.0,
            y: 724.1
        },
        {
            x: 211.0,
            y: 661.6
        },
    ], {
        fill: green,
        id: 'x3id114'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 285.0,
            y: 661.6
        },
        {
            x: 222.0,
            y: 661.6
        },
        {
            x: 222.0,
            y: 724.1
        },
        {
            x: 285.0,
            y: 724.1
        },
        {
            x: 285.0,
            y: 661.6
        },
    ], {
        fill: green,
        id: 'x3id115'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 359.0,
            y: 661.6
        },
        {
            x: 296.0,
            y: 661.6
        },
        {
            x: 296.0,
            y: 724.1
        },
        {
            x: 359.0,
            y: 724.1
        },
        {
            x: 359.0,
            y: 661.6
        },
    ], {
        fill: green,
        id: 'x3id116'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 877.0,
            y: 661.6
        },
        {
            x: 814.0,
            y: 661.6
        },
        {
            x: 814.0,
            y: 724.1
        },
        {
            x: 877.0,
            y: 724.1
        },
        {
            x: 877.0,
            y: 661.6
        },
    ], {
        fill: green,
        id: 'x3id117'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 951.0,
            y: 661.6
        },
        {
            x: 888.0,
            y: 661.6
        },
        {
            x: 888.0,
            y: 724.1
        },
        {
            x: 951.0,
            y: 724.1
        },
        {
            x: 951.0,
            y: 661.6
        },
    ], {
        fill: green,
        id: 'x3id118'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 1025.0,
            y: 661.6
        },
        {
            x: 962.0,
            y: 661.6
        },
        {
            x: 962.0,
            y: 724.1
        },
        {
            x: 1025.0,
            y: 724.1
        },
        {
            x: 1025.0,
            y: 661.6
        },
    ], {
        fill: green,
        id: 'x3id119'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 1099.0,
            y: 661.6
        },
        {
            x: 1036.0,
            y: 661.6
        },
        {
            x: 1036.0,
            y: 724.1
        },
        {
            x: 1099.0,
            y: 724.1
        },
        {
            x: 1099.0,
            y: 661.6
        },
    ], {
        fill: green,
        id: 'x3id120'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 63.0,
            y: 735.1
        },
        {
            x: 0.0,
            y: 735.1
        },
        {
            x: 0.0,
            y: 797.6
        },
        {
            x: 63.0,
            y: 797.6
        },
        {
            x: 63.0,
            y: 735.1
        },
    ], {
        fill: green,
        id: 'x3id121'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 137.0,
            y: 735.1
        },
        {
            x: 74.0,
            y: 735.1
        },
        {
            x: 74.0,
            y: 797.6
        },
        {
            x: 137.0,
            y: 797.6
        },
        {
            x: 137.0,
            y: 735.1
        },
    ], {
        fill: green,
        id: 'x3id122'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 211.0,
            y: 735.1
        },
        {
            x: 148.0,
            y: 735.1
        },
        {
            x: 148.0,
            y: 797.6
        },
        {
            x: 211.0,
            y: 797.6
        },
        {
            x: 211.0,
            y: 735.1
        },
    ], {
        fill: green,
        id: 'x3id123'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 285.0,
            y: 735.1
        },
        {
            x: 222.0,
            y: 735.1
        },
        {
            x: 222.0,
            y: 797.6
        },
        {
            x: 285.0,
            y: 797.6
        },
        {
            x: 285.0,
            y: 735.1
        },
    ], {
        fill: green,
        id: 'x3id124'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 359.0,
            y: 735.1
        },
        {
            x: 296.0,
            y: 735.1
        },
        {
            x: 296.0,
            y: 797.6
        },
        {
            x: 359.0,
            y: 797.6
        },
        {
            x: 359.0,
            y: 735.1
        },
    ], {
        fill: green,
        id: 'x3id125'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 433.0,
            y: 735.1
        },
        {
            x: 370.0,
            y: 735.1
        },
        {
            x: 370.0,
            y: 797.6
        },
        {
            x: 433.0,
            y: 797.6
        },
        {
            x: 433.0,
            y: 735.1
        },
    ], {
        fill: green,
        id: 'x3id126'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 507.0,
            y: 735.1
        },
        {
            x: 444.0,
            y: 735.1
        },
        {
            x: 444.0,
            y: 797.6
        },
        {
            x: 507.0,
            y: 797.6
        },
        {
            x: 507.0,
            y: 735.1
        },
    ], {
        fill: green,
        id: 'x3id127'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 581.0,
            y: 735.1
        },
        {
            x: 518.0,
            y: 735.1
        },
        {
            x: 518.0,
            y: 797.6
        },
        {
            x: 581.0,
            y: 797.6
        },
        {
            x: 581.0,
            y: 735.1
        },
    ], {
        fill: green,
        id: 'x3id128'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 655.0,
            y: 735.1
        },
        {
            x: 592.0,
            y: 735.1
        },
        {
            x: 592.0,
            y: 797.6
        },
        {
            x: 655.0,
            y: 797.6
        },
        {
            x: 655.0,
            y: 735.1
        },
    ], {
        fill: green,
        id: 'x3id129'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 729.0,
            y: 735.1
        },
        {
            x: 666.0,
            y: 735.1
        },
        {
            x: 666.0,
            y: 797.6
        },
        {
            x: 729.0,
            y: 797.6
        },
        {
            x: 729.0,
            y: 735.1
        },
    ], {
        fill: green,
        id: 'x3id130'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 803.0,
            y: 735.1
        },
        {
            x: 740.0,
            y: 735.1
        },
        {
            x: 740.0,
            y: 797.6
        },
        {
            x: 803.0,
            y: 797.6
        },
        {
            x: 803.0,
            y: 735.1
        },
    ], {
        fill: green,
        id: 'x3id131'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 877.0,
            y: 735.1
        },
        {
            x: 814.0,
            y: 735.1
        },
        {
            x: 814.0,
            y: 797.6
        },
        {
            x: 877.0,
            y: 797.6
        },
        {
            x: 877.0,
            y: 735.1
        },
    ], {
        fill: green,
        id: 'x3id132'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 951.0,
            y: 735.1
        },
        {
            x: 888.0,
            y: 735.1
        },
        {
            x: 888.0,
            y: 797.6
        },
        {
            x: 951.0,
            y: 797.6
        },
        {
            x: 951.0,
            y: 735.1
        },
    ], {
        fill: green,
        id: 'x3id133'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 1025.0,
            y: 735.1
        },
        {
            x: 962.0,
            y: 735.1
        },
        {
            x: 962.0,
            y: 797.6
        },
        {
            x: 1025.0,
            y: 797.6
        },
        {
            x: 1025.0,
            y: 735.1
        },
    ], {
        fill: green,
        id: 'x3id134'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 1099.0,
            y: 735.1
        },
        {
            x: 1036.0,
            y: 735.1
        },
        {
            x: 1036.0,
            y: 797.6
        },
        {
            x: 1099.0,
            y: 797.6
        },
        {
            x: 1099.0,
            y: 735.1
        },
    ], {
        fill: green,
        id: 'x3id135'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 63.0,
            y: 808.6
        },
        {
            x: 0.0,
            y: 808.6
        },
        {
            x: 0.0,
            y: 871.1
        },
        {
            x: 63.0,
            y: 871.1
        },
        {
            x: 63.0,
            y: 808.6
        },
    ], {
        fill: green,
        id: 'x3id136'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 137.0,
            y: 808.6
        },
        {
            x: 74.0,
            y: 808.6
        },
        {
            x: 74.0,
            y: 871.1
        },
        {
            x: 137.0,
            y: 871.1
        },
        {
            x: 137.0,
            y: 808.6
        },
    ], {
        fill: green,
        id: 'x3id137'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 211.0,
            y: 808.6
        },
        {
            x: 148.0,
            y: 808.6
        },
        {
            x: 148.0,
            y: 871.1
        },
        {
            x: 211.0,
            y: 871.1
        },
        {
            x: 211.0,
            y: 808.6
        },
    ], {
        fill: green,
        id: 'x3id138'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 285.0,
            y: 808.6
        },
        {
            x: 222.0,
            y: 808.6
        },
        {
            x: 222.0,
            y: 871.1
        },
        {
            x: 285.0,
            y: 871.1
        },
        {
            x: 285.0,
            y: 808.6
        },
    ], {
        fill: green,
        id: 'x3id139'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 359.0,
            y: 808.6
        },
        {
            x: 296.0,
            y: 808.6
        },
        {
            x: 296.0,
            y: 871.1
        },
        {
            x: 359.0,
            y: 871.1
        },
        {
            x: 359.0,
            y: 808.6
        },
    ], {
        fill: green,
        id: 'x3id140'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 433.0,
            y: 808.6
        },
        {
            x: 370.0,
            y: 808.6
        },
        {
            x: 370.0,
            y: 871.1
        },
        {
            x: 433.0,
            y: 871.1
        },
        {
            x: 433.0,
            y: 808.6
        },
    ], {
        fill: green,
        id: 'x3id141'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 507.0,
            y: 808.6
        },
        {
            x: 444.0,
            y: 808.6
        },
        {
            x: 444.0,
            y: 871.1
        },
        {
            x: 507.0,
            y: 871.1
        },
        {
            x: 507.0,
            y: 808.6
        },
    ], {
        fill: green,
        id: 'x3id142'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 581.0,
            y: 808.6
        },
        {
            x: 518.0,
            y: 808.6
        },
        {
            x: 518.0,
            y: 871.1
        },
        {
            x: 581.0,
            y: 871.1
        },
        {
            x: 581.0,
            y: 808.6
        },
    ], {
        fill: green,
        id: 'x3id143'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 655.0,
            y: 808.6
        },
        {
            x: 592.0,
            y: 808.6
        },
        {
            x: 592.0,
            y: 871.1
        },
        {
            x: 655.0,
            y: 871.1
        },
        {
            x: 655.0,
            y: 808.6
        },
    ], {
        fill: green,
        id: 'x3id144'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 729.0,
            y: 808.6
        },
        {
            x: 666.0,
            y: 808.6
        },
        {
            x: 666.0,
            y: 871.1
        },
        {
            x: 729.0,
            y: 871.1
        },
        {
            x: 729.0,
            y: 808.6
        },
    ], {
        fill: green,
        id: 'x3id145'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 803.0,
            y: 808.6
        },
        {
            x: 740.0,
            y: 808.6
        },
        {
            x: 740.0,
            y: 871.1
        },
        {
            x: 803.0,
            y: 871.1
        },
        {
            x: 803.0,
            y: 808.6
        },
    ], {
        fill: green,
        id: 'x3id146'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 877.0,
            y: 808.6
        },
        {
            x: 814.0,
            y: 808.6
        },
        {
            x: 814.0,
            y: 871.1
        },
        {
            x: 877.0,
            y: 871.1
        },
        {
            x: 877.0,
            y: 808.6
        },
    ], {
        fill: green,
        id: 'x3id147'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 951.0,
            y: 808.6
        },
        {
            x: 888.0,
            y: 808.6
        },
        {
            x: 888.0,
            y: 871.1
        },
        {
            x: 951.0,
            y: 871.1
        },
        {
            x: 951.0,
            y: 808.6
        },
    ], {
        fill: green,
        id: 'x3id148'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 1025.0,
            y: 808.6
        },
        {
            x: 962.0,
            y: 808.6
        },
        {
            x: 962.0,
            y: 871.1
        },
        {
            x: 1025.0,
            y: 871.1
        },
        {
            x: 1025.0,
            y: 808.6
        },
    ], {
        fill: green,
        id: 'x3id149'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 1099.0,
            y: 808.6
        },
        {
            x: 1036.0,
            y: 808.6
        },
        {
            x: 1036.0,
            y: 871.1
        },
        {
            x: 1099.0,
            y: 871.1
        },
        {
            x: 1099.0,
            y: 808.6
        },
    ], {
        fill: green,
        id: 'x3id150'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 63.0,
            y: 882.1
        },
        {
            x: 0.0,
            y: 882.1
        },
        {
            x: 0.0,
            y: 944.6
        },
        {
            x: 63.0,
            y: 944.6
        },
        {
            x: 63.0,
            y: 882.1
        },
    ], {
        fill: green,
        id: 'x3id151'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 137.0,
            y: 882.1
        },
        {
            x: 74.0,
            y: 882.1
        },
        {
            x: 74.0,
            y: 944.6
        },
        {
            x: 137.0,
            y: 944.6
        },
        {
            x: 137.0,
            y: 882.1
        },
    ], {
        fill: green,
        id: 'x3id152'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 211.0,
            y: 882.1
        },
        {
            x: 148.0,
            y: 882.1
        },
        {
            x: 148.0,
            y: 944.6
        },
        {
            x: 211.0,
            y: 944.6
        },
        {
            x: 211.0,
            y: 882.1
        },
    ], {
        fill: green,
        id: 'x3id153'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 285.0,
            y: 882.1
        },
        {
            x: 222.0,
            y: 882.1
        },
        {
            x: 222.0,
            y: 944.6
        },
        {
            x: 285.0,
            y: 944.6
        },
        {
            x: 285.0,
            y: 882.1
        },
    ], {
        fill: green,
        id: 'x3id154'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 359.0,
            y: 882.1
        },
        {
            x: 296.0,
            y: 882.1
        },
        {
            x: 296.0,
            y: 944.6
        },
        {
            x: 359.0,
            y: 944.6
        },
        {
            x: 359.0,
            y: 882.1
        },
    ], {
        fill: green,
        id: 'x3id155'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 433.0,
            y: 882.1
        },
        {
            x: 370.0,
            y: 882.1
        },
        {
            x: 370.0,
            y: 944.6
        },
        {
            x: 433.0,
            y: 944.6
        },
        {
            x: 433.0,
            y: 882.1
        },
    ], {
        fill: green,
        id: 'x3id156'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 507.0,
            y: 882.1
        },
        {
            x: 444.0,
            y: 882.1
        },
        {
            x: 444.0,
            y: 944.6
        },
        {
            x: 507.0,
            y: 944.6
        },
        {
            x: 507.0,
            y: 882.1
        },
    ], {
        fill: green,
        id: 'x3id157'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 581.0,
            y: 882.1
        },
        {
            x: 518.0,
            y: 882.1
        },
        {
            x: 518.0,
            y: 944.6
        },
        {
            x: 581.0,
            y: 944.6
        },
        {
            x: 581.0,
            y: 882.1
        },
    ], {
        fill: green,
        id: 'x3id158'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 655.0,
            y: 882.1
        },
        {
            x: 592.0,
            y: 882.1
        },
        {
            x: 592.0,
            y: 944.6
        },
        {
            x: 655.0,
            y: 944.6
        },
        {
            x: 655.0,
            y: 882.1
        },
    ], {
        fill: green,
        id: 'x3id159'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 729.0,
            y: 882.1
        },
        {
            x: 666.0,
            y: 882.1
        },
        {
            x: 666.0,
            y: 944.6
        },
        {
            x: 729.0,
            y: 944.6
        },
        {
            x: 729.0,
            y: 882.1
        },
    ], {
        fill: green,
        id: 'x3id160'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 803.0,
            y: 882.1
        },
        {
            x: 740.0,
            y: 882.1
        },
        {
            x: 740.0,
            y: 944.6
        },
        {
            x: 803.0,
            y: 944.6
        },
        {
            x: 803.0,
            y: 882.1
        },
    ], {
        fill: green,
        id: 'x3id161'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 877.0,
            y: 882.1
        },
        {
            x: 814.0,
            y: 882.1
        },
        {
            x: 814.0,
            y: 944.6
        },
        {
            x: 877.0,
            y: 944.6
        },
        {
            x: 877.0,
            y: 882.1
        },
    ], {
        fill: green,
        id: 'x3id162'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 951.0,
            y: 882.1
        },
        {
            x: 888.0,
            y: 882.1
        },
        {
            x: 888.0,
            y: 944.6
        },
        {
            x: 951.0,
            y: 944.6
        },
        {
            x: 951.0,
            y: 882.1
        },
    ], {
        fill: green,
        id: 'x3id163'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 1025.0,
            y: 882.1
        },
        {
            x: 962.0,
            y: 882.1
        },
        {
            x: 962.0,
            y: 944.6
        },
        {
            x: 1025.0,
            y: 944.6
        },
        {
            x: 1025.0,
            y: 882.1
        },
    ], {
        fill: green,
        id: 'x3id164'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 1099.0,
            y: 882.1
        },
        {
            x: 1036.0,
            y: 882.1
        },
        {
            x: 1036.0,
            y: 944.6
        },
        {
            x: 1099.0,
            y: 944.6
        },
        {
            x: 1099.0,
            y: 882.1
        },
    ], {
        fill: green,
        id: 'x3id165'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 63.0,
            y: 955.6
        },
        {
            x: 0.0,
            y: 955.6
        },
        {
            x: 0.0,
            y: 1018.1
        },
        {
            x: 63.0,
            y: 1018.1
        },
        {
            x: 63.0,
            y: 955.6
        },
    ], {
        fill: green,
        id: 'x3id166'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 137.0,
            y: 955.6
        },
        {
            x: 74.0,
            y: 955.6
        },
        {
            x: 74.0,
            y: 1018.1
        },
        {
            x: 137.0,
            y: 1018.1
        },
        {
            x: 137.0,
            y: 955.6
        },
    ], {
        fill: green,
        id: 'x3id167'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 211.0,
            y: 955.6
        },
        {
            x: 148.0,
            y: 955.6
        },
        {
            x: 148.0,
            y: 1018.1
        },
        {
            x: 211.0,
            y: 1018.1
        },
        {
            x: 211.0,
            y: 955.6
        },
    ], {
        fill: green,
        id: 'x3id168'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 285.0,
            y: 955.6
        },
        {
            x: 222.0,
            y: 955.6
        },
        {
            x: 222.0,
            y: 1018.1
        },
        {
            x: 285.0,
            y: 1018.1
        },
        {
            x: 285.0,
            y: 955.6
        },
    ], {
        fill: green,
        id: 'x3id169'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 359.0,
            y: 955.6
        },
        {
            x: 296.0,
            y: 955.6
        },
        {
            x: 296.0,
            y: 1018.1
        },
        {
            x: 359.0,
            y: 1018.1
        },
        {
            x: 359.0,
            y: 955.6
        },
    ], {
        fill: green,
        id: 'x3id170'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 433.0,
            y: 955.6
        },
        {
            x: 370.0,
            y: 955.6
        },
        {
            x: 370.0,
            y: 1018.1
        },
        {
            x: 433.0,
            y: 1018.1
        },
        {
            x: 433.0,
            y: 955.6
        },
    ], {
        fill: green,
        id: 'x3id171'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 507.0,
            y: 955.6
        },
        {
            x: 444.0,
            y: 955.6
        },
        {
            x: 444.0,
            y: 1018.1
        },
        {
            x: 507.0,
            y: 1018.1
        },
        {
            x: 507.0,
            y: 955.6
        },
    ], {
        fill: green,
        id: 'x3id172'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 581.0,
            y: 955.6
        },
        {
            x: 518.0,
            y: 955.6
        },
        {
            x: 518.0,
            y: 1018.1
        },
        {
            x: 581.0,
            y: 1018.1
        },
        {
            x: 581.0,
            y: 955.6
        },
    ], {
        fill: green,
        id: 'x3id173'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 655.0,
            y: 955.6
        },
        {
            x: 592.0,
            y: 955.6
        },
        {
            x: 592.0,
            y: 1018.1
        },
        {
            x: 655.0,
            y: 1018.1
        },
        {
            x: 655.0,
            y: 955.6
        },
    ], {
        fill: green,
        id: 'x3id174'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 729.0,
            y: 955.6
        },
        {
            x: 666.0,
            y: 955.6
        },
        {
            x: 666.0,
            y: 1018.1
        },
        {
            x: 729.0,
            y: 1018.1
        },
        {
            x: 729.0,
            y: 955.6
        },
    ], {
        fill: green,
        id: 'x3id175'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 803.0,
            y: 955.6
        },
        {
            x: 740.0,
            y: 955.6
        },
        {
            x: 740.0,
            y: 1018.1
        },
        {
            x: 803.0,
            y: 1018.1
        },
        {
            x: 803.0,
            y: 955.6
        },
    ], {
        fill: green,
        id: 'x3id176'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 877.0,
            y: 955.6
        },
        {
            x: 814.0,
            y: 955.6
        },
        {
            x: 814.0,
            y: 1018.1
        },
        {
            x: 877.0,
            y: 1018.1
        },
        {
            x: 877.0,
            y: 955.6
        },
    ], {
        fill: green,
        id: 'x3id177'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 951.0,
            y: 955.6
        },
        {
            x: 888.0,
            y: 955.6
        },
        {
            x: 888.0,
            y: 1018.1
        },
        {
            x: 951.0,
            y: 1018.1
        },
        {
            x: 951.0,
            y: 955.6
        },
    ], {
        fill: green,
        id: 'x3id178'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 1025.0,
            y: 955.6
        },
        {
            x: 962.0,
            y: 955.6
        },
        {
            x: 962.0,
            y: 1018.1
        },
        {
            x: 1025.0,
            y: 1018.1
        },
        {
            x: 1025.0,
            y: 955.6
        },
    ], {
        fill: green,
        id: 'x3id179'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 1099.0,
            y: 955.6
        },
        {
            x: 1036.0,
            y: 955.6
        },
        {
            x: 1036.0,
            y: 1018.1
        },
        {
            x: 1099.0,
            y: 1018.1
        },
        {
            x: 1099.0,
            y: 955.6
        },
    ], {
        fill: green,
        id: 'x3id180'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 63.0,
            y: 1029.1
        },
        {
            x: 0.0,
            y: 1029.1
        },
        {
            x: 0.0,
            y: 1091.6
        },
        {
            x: 63.0,
            y: 1091.6
        },
        {
            x: 63.0,
            y: 1029.1
        },
    ], {
        fill: green,
        id: 'x3id181'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 137.0,
            y: 1029.1
        },
        {
            x: 74.0,
            y: 1029.1
        },
        {
            x: 74.0,
            y: 1091.6
        },
        {
            x: 137.0,
            y: 1091.6
        },
        {
            x: 137.0,
            y: 1029.1
        },
    ], {
        fill: green,
        id: 'x3id182'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 211.0,
            y: 1029.1
        },
        {
            x: 148.0,
            y: 1029.1
        },
        {
            x: 148.0,
            y: 1091.6
        },
        {
            x: 211.0,
            y: 1091.6
        },
        {
            x: 211.0,
            y: 1029.1
        },
    ], {
        fill: green,
        id: 'x3id183'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 285.0,
            y: 1029.1
        },
        {
            x: 222.0,
            y: 1029.1
        },
        {
            x: 222.0,
            y: 1091.6
        },
        {
            x: 285.0,
            y: 1091.6
        },
        {
            x: 285.0,
            y: 1029.1
        },
    ], {
        fill: green,
        id: 'x3id184'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 359.0,
            y: 1029.1
        },
        {
            x: 296.0,
            y: 1029.1
        },
        {
            x: 296.0,
            y: 1091.6
        },
        {
            x: 359.0,
            y: 1091.6
        },
        {
            x: 359.0,
            y: 1029.1
        },
    ], {
        fill: green,
        id: 'x3id185'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 433.0,
            y: 1029.1
        },
        {
            x: 370.0,
            y: 1029.1
        },
        {
            x: 370.0,
            y: 1091.6
        },
        {
            x: 433.0,
            y: 1091.6
        },
        {
            x: 433.0,
            y: 1029.1
        },
    ], {
        fill: green,
        id: 'x3id186'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 507.0,
            y: 1029.1
        },
        {
            x: 444.0,
            y: 1029.1
        },
        {
            x: 444.0,
            y: 1091.6
        },
        {
            x: 507.0,
            y: 1091.6
        },
        {
            x: 507.0,
            y: 1029.1
        },
    ], {
        fill: green,
        id: 'x3id187'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 581.0,
            y: 1029.1
        },
        {
            x: 518.0,
            y: 1029.1
        },
        {
            x: 518.0,
            y: 1091.6
        },
        {
            x: 581.0,
            y: 1091.6
        },
        {
            x: 581.0,
            y: 1029.1
        },
    ], {
        fill: green,
        id: 'x3id188'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 655.0,
            y: 1029.1
        },
        {
            x: 592.0,
            y: 1029.1
        },
        {
            x: 592.0,
            y: 1091.6
        },
        {
            x: 655.0,
            y: 1091.6
        },
        {
            x: 655.0,
            y: 1029.1
        },
    ], {
        fill: green,
        id: 'x3id189'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 729.0,
            y: 1029.1
        },
        {
            x: 666.0,
            y: 1029.1
        },
        {
            x: 666.0,
            y: 1091.6
        },
        {
            x: 729.0,
            y: 1091.6
        },
        {
            x: 729.0,
            y: 1029.1
        },
    ], {
        fill: green,
        id: 'x3id190'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 803.0,
            y: 1029.1
        },
        {
            x: 740.0,
            y: 1029.1
        },
        {
            x: 740.0,
            y: 1091.6
        },
        {
            x: 803.0,
            y: 1091.6
        },
        {
            x: 803.0,
            y: 1029.1
        },
    ], {
        fill: green,
        id: 'x3id191'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 877.0,
            y: 1029.1
        },
        {
            x: 814.0,
            y: 1029.1
        },
        {
            x: 814.0,
            y: 1091.6
        },
        {
            x: 877.0,
            y: 1091.6
        },
        {
            x: 877.0,
            y: 1029.1
        },
    ], {
        fill: green,
        id: 'x3id192'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 951.0,
            y: 1029.1
        },
        {
            x: 888.0,
            y: 1029.1
        },
        {
            x: 888.0,
            y: 1091.6
        },
        {
            x: 951.0,
            y: 1091.6
        },
        {
            x: 951.0,
            y: 1029.1
        },
    ], {
        fill: green,
        id: 'x3id193'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 1025.0,
            y: 1029.1
        },
        {
            x: 962.0,
            y: 1029.1
        },
        {
            x: 962.0,
            y: 1091.6
        },
        {
            x: 1025.0,
            y: 1091.6
        },
        {
            x: 1025.0,
            y: 1029.1
        },
    ], {
        fill: green,
        id: 'x3id194'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 1099.0,
            y: 1029.1
        },
        {
            x: 1036.0,
            y: 1029.1
        },
        {
            x: 1036.0,
            y: 1091.6
        },
        {
            x: 1099.0,
            y: 1091.6
        },
        {
            x: 1099.0,
            y: 1029.1
        },
    ], {
        fill: green,
        id: 'x3id195'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 803.0,
            y: 367.5
        },
        {
            x: 740.0,
            y: 367.5
        },
        {
            x: 740.0,
            y: 430.0
        },
        {
            x: 803.0,
            y: 430.0
        },
        {
            x: 803.0,
            y: 367.5
        },
    ], {
        fill: green,
        id: 'x3id196'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 803.0,
            y: 441.0
        },
        {
            x: 740.0,
            y: 441.0
        },
        {
            x: 740.0,
            y: 503.6
        },
        {
            x: 803.0,
            y: 503.6
        },
        {
            x: 803.0,
            y: 441.0
        },
    ], {
        fill: green,
        id: 'x3id197'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 803.0,
            y: 514.6
        },
        {
            x: 740.0,
            y: 514.6
        },
        {
            x: 740.0,
            y: 577.1
        },
        {
            x: 803.0,
            y: 577.1
        },
        {
            x: 803.0,
            y: 514.6
        },
    ], {
        fill: green,
        id: 'x3id198'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 803.0,
            y: 588.1
        },
        {
            x: 740.0,
            y: 588.1
        },
        {
            x: 740.0,
            y: 650.6
        },
        {
            x: 803.0,
            y: 650.6
        },
        {
            x: 803.0,
            y: 588.1
        },
    ], {
        fill: green,
        id: 'x3id199'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 803.0,
            y: 661.4
        },
        {
            x: 740.0,
            y: 661.4
        },
        {
            x: 740.0,
            y: 723.9
        },
        {
            x: 803.0,
            y: 723.9
        },
        {
            x: 803.0,
            y: 661.4
        },
    ], {
        fill: green,
        id: 'x3id200'
    }))
    canvas3.add(new fabric.Polygon([{
            x: 726.5,
            y: 724.1
        },
        {
            x: 370.0,
            y: 724.1
        },
        {
            x: 370.0,
            y: 367.5
        },
        {
            x: 726.5,
            y: 367.5
        },
        {
            x: 726.5,
            y: 724.1
        },
    ], {
        fill: green,
        id: 'x3id201'
    }))
</script>
