<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layouts.app','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <style>
        body {
            background: linear-gradient(180deg, #002B49 0%, rgba(0, 2, 11, 1) 100%);
            background-repeat: no-repeat;
            min-height: 100vh;
            font-family: "Futura";
        }
    </style>
    <main class="pb-8 min-h-screen px-[24px] relative">

        <background class="h-full w-full  absolute -z-10 top-0 right-0">
            <img src="img/bg.svg" class="w-full h-[100%]">
        </background>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layouts.header','data' => ['navClass' => '!px-0']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['navClass' => '!px-0']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        <flex class="flex text-white   mt-8 mb-1 justify-between items-center">
            <subject class="block font-semibold">Select your lands</subject>
            <counter class="block">1/10</counter>
        </flex>
        <map class="mx-auto items-center justify-center h-[340]  relative flex">
            <canvas id="canvas"></canvas>
        </map>
        <controller>
            <flex class="flex items-center mt-2 justify-between">
                <left>
                    <flex class="flex text-white    items-center justify-between gap-1">
                        <button
                            class="rounded  bg-[#009bdc] text-[18px] h-[32px] gap-1 flex items-center justify-center w-[94px]">
                            <span><img src="<?php echo e(asset('img/plus.svg')); ?>"></span>
                            <span>Select</span>
                        </button>
                        <button
                            class="rounded  bg-[#009bdc] text-[18px] h-[32px] gap-1 flex items-center justify-center w-[94px]">
                            <span><img src="<?php echo e(asset('img/trash.svg')); ?>"></span>
                            <span>Clear</span>
                        </button>
                    </flex>
                </left>
                <right>

                    <flex class="flex text-white    items-center justify-between gap-1">
                        <button
                            class="rounded  bg-[#009bdc] text-[18px] h-[32px] gap-1 flex items-center justify-center w-[32px]">
                            <span><img src="<?php echo e(asset('img/left.svg')); ?>"></span>
                        </button>
                        <button
                            class="rounded  bg-[#009bdc] text-[18px] h-[32px] gap-1 flex items-center justify-center w-[32px]">
                            <span><img src="<?php echo e(asset('img/right.svg')); ?>"></span>
                        </button>

                    </flex>
                </right>
            </flex>
        </controller>
        <mini_card>
            <flex class="justify-between text-white flex items-center mt-4">
                <left>
                    <text class="block">You selected <number>43</number> lands</text>
                    <text class="block">Total Price : $<number>43</number></text>
                </left>
                <right>
                    <a href="<?php echo e(route('.page_2')); ?>"
                        class="bg-gradient-to-b block from-[#00A1D3] to-[#003867] text-center text-white font-semibold leading-[42px] h-[42px] w-[100px] rounded">
                        Submit</a>
                </right>
            </flex>
        </mini_card>
    </main>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.map','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('map'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Dante\OneDrive\Desktop\partners\resources\views/page_1.blade.php ENDPATH**/ ?>