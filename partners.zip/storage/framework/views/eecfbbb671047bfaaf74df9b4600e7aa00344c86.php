<script>
    canvas1.add(new fabric.Polygon([{
            x: 0.0,
            y: 0.0
        },
        {
            x: 0.0,
            y: 62.5
        },
        {
            x: 63.0,
            y: 62.5
        },
        {
            x: 63.0,
            y: 0.0
        },
    ], {
        fill: green,
        id: 'x1id1'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 137.0,
            y: 0.0
        },
        {
            x: 74.0,
            y: 0.0
        },
        {
            x: 74.0,
            y: 62.5
        },
        {
            x: 137.0,
            y: 62.5
        },
        {
            x: 137.0,
            y: 0.0
        },
    ], {
        fill: green,
        id: 'x1id2'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 211.0,
            y: 0.0
        },
        {
            x: 148.0,
            y: 0.0
        },
        {
            x: 148.0,
            y: 62.5
        },
        {
            x: 211.0,
            y: 62.5
        },
        {
            x: 211.0,
            y: 0.0
        },
    ], {
        fill: green,
        id: 'x1id3'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 285.0,
            y: 0.0
        },
        {
            x: 222.0,
            y: 0.0
        },
        {
            x: 222.0,
            y: 62.5
        },
        {
            x: 285.0,
            y: 62.5
        },
        {
            x: 285.0,
            y: 0.0
        },
    ], {
        fill: green,
        id: 'x1id4'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 359.0,
            y: 0.0
        },
        {
            x: 296.0,
            y: 0.0
        },
        {
            x: 296.0,
            y: 62.5
        },
        {
            x: 359.0,
            y: 62.5
        },
        {
            x: 359.0,
            y: 0.0
        },
    ], {
        fill: green,
        id: 'x1id5'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 433.0,
            y: 0.0
        },
        {
            x: 370.0,
            y: 0.0
        },
        {
            x: 370.0,
            y: 62.5
        },
        {
            x: 433.0,
            y: 62.5
        },
        {
            x: 433.0,
            y: 0.0
        },
    ], {
        fill: green,
        id: 'x1id6'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 507.0,
            y: 0.0
        },
        {
            x: 444.0,
            y: 0.0
        },
        {
            x: 444.0,
            y: 62.5
        },
        {
            x: 507.0,
            y: 62.5
        },
        {
            x: 507.0,
            y: 0.0
        },
    ], {
        fill: green,
        id: 'x1id7'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 581.0,
            y: 0.0
        },
        {
            x: 518.0,
            y: 0.0
        },
        {
            x: 518.0,
            y: 62.5
        },
        {
            x: 581.0,
            y: 62.5
        },
        {
            x: 581.0,
            y: 0.0
        },
    ], {
        fill: green,
        id: 'x1id8'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 655.0,
            y: 0.0
        },
        {
            x: 592.0,
            y: 0.0
        },
        {
            x: 592.0,
            y: 62.5
        },
        {
            x: 655.0,
            y: 62.5
        },
        {
            x: 655.0,
            y: 0.0
        },
    ], {
        fill: green,
        id: 'x1id9'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 729.0,
            y: 0.0
        },
        {
            x: 666.0,
            y: 0.0
        },
        {
            x: 666.0,
            y: 62.5
        },
        {
            x: 729.0,
            y: 62.5
        },
        {
            x: 729.0,
            y: 0.0
        },
    ], {
        fill: green,
        id: 'x1id10'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 803.0,
            y: 0.0
        },
        {
            x: 740.0,
            y: 0.0
        },
        {
            x: 740.0,
            y: 62.5
        },
        {
            x: 803.0,
            y: 62.5
        },
        {
            x: 803.0,
            y: 0.0
        },
    ], {
        fill: green,
        id: 'x1id11'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 877.0,
            y: 0.0
        },
        {
            x: 814.0,
            y: 0.0
        },
        {
            x: 814.0,
            y: 62.5
        },
        {
            x: 877.0,
            y: 62.5
        },
        {
            x: 877.0,
            y: 0.0
        },
    ], {
        fill: green,
        id: 'x1id12'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 951.0,
            y: 0.0
        },
        {
            x: 888.0,
            y: 0.0
        },
        {
            x: 888.0,
            y: 62.5
        },
        {
            x: 951.0,
            y: 62.5
        },
        {
            x: 951.0,
            y: 0.0
        },
    ], {
        fill: green,
        id: 'x1id13'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 1025.0,
            y: 0.0
        },
        {
            x: 962.0,
            y: 0.0
        },
        {
            x: 962.0,
            y: 62.5
        },
        {
            x: 1025.0,
            y: 62.5
        },
        {
            x: 1025.0,
            y: 0.0
        },
    ], {
        fill: green,
        id: 'x1id14'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 1099.0,
            y: 0.0
        },
        {
            x: 1036.0,
            y: 0.0
        },
        {
            x: 1036.0,
            y: 62.5
        },
        {
            x: 1099.0,
            y: 62.5
        },
        {
            x: 1099.0,
            y: 0.0
        },
    ], {
        fill: green,
        id: 'x1id15'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 63.0,
            y: 73.5
        },
        {
            x: 0.0,
            y: 73.5
        },
        {
            x: 0.0,
            y: 136.0
        },
        {
            x: 63.0,
            y: 136.0
        },
        {
            x: 63.0,
            y: 73.5
        },
    ], {
        fill: green,
        id: 'x1id16'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 137.0,
            y: 73.5
        },
        {
            x: 74.0,
            y: 73.5
        },
        {
            x: 74.0,
            y: 136.0
        },
        {
            x: 137.0,
            y: 136.0
        },
        {
            x: 137.0,
            y: 73.5
        },
    ], {
        fill: green,
        id: 'x1id17'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 211.0,
            y: 73.5
        },
        {
            x: 148.0,
            y: 73.5
        },
        {
            x: 148.0,
            y: 136.0
        },
        {
            x: 211.0,
            y: 136.0
        },
        {
            x: 211.0,
            y: 73.5
        },
    ], {
        fill: green,
        id: 'x1id18'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 285.0,
            y: 73.5
        },
        {
            x: 222.0,
            y: 73.5
        },
        {
            x: 222.0,
            y: 136.0
        },
        {
            x: 285.0,
            y: 136.0
        },
        {
            x: 285.0,
            y: 73.5
        },
    ], {
        fill: green,
        id: 'x1id19'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 359.0,
            y: 73.5
        },
        {
            x: 296.0,
            y: 73.5
        },
        {
            x: 296.0,
            y: 136.0
        },
        {
            x: 359.0,
            y: 136.0
        },
        {
            x: 359.0,
            y: 73.5
        },
    ], {
        fill: green,
        id: 'x1id20'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 433.0,
            y: 73.5
        },
        {
            x: 370.0,
            y: 73.5
        },
        {
            x: 370.0,
            y: 136.0
        },
        {
            x: 433.0,
            y: 136.0
        },
        {
            x: 433.0,
            y: 73.5
        },
    ], {
        fill: green,
        id: 'x1id21'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 507.0,
            y: 73.5
        },
        {
            x: 444.0,
            y: 73.5
        },
        {
            x: 444.0,
            y: 136.0
        },
        {
            x: 507.0,
            y: 136.0
        },
        {
            x: 507.0,
            y: 73.5
        },
    ], {
        fill: green,
        id: 'x1id22'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 581.0,
            y: 73.5
        },
        {
            x: 518.0,
            y: 73.5
        },
        {
            x: 518.0,
            y: 136.0
        },
        {
            x: 581.0,
            y: 136.0
        },
        {
            x: 581.0,
            y: 73.5
        },
    ], {
        fill: green,
        id: 'x1id23'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 655.0,
            y: 73.5
        },
        {
            x: 592.0,
            y: 73.5
        },
        {
            x: 592.0,
            y: 136.0
        },
        {
            x: 655.0,
            y: 136.0
        },
        {
            x: 655.0,
            y: 73.5
        },
    ], {
        fill: green,
        id: 'x1id24'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 729.0,
            y: 73.5
        },
        {
            x: 666.0,
            y: 73.5
        },
        {
            x: 666.0,
            y: 136.0
        },
        {
            x: 729.0,
            y: 136.0
        },
        {
            x: 729.0,
            y: 73.5
        },
    ], {
        fill: green,
        id: 'x1id25'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 803.0,
            y: 73.5
        },
        {
            x: 740.0,
            y: 73.5
        },
        {
            x: 740.0,
            y: 136.0
        },
        {
            x: 803.0,
            y: 136.0
        },
        {
            x: 803.0,
            y: 73.5
        },
    ], {
        fill: green,
        id: 'x1id26'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 877.0,
            y: 73.5
        },
        {
            x: 814.0,
            y: 73.5
        },
        {
            x: 814.0,
            y: 136.0
        },
        {
            x: 877.0,
            y: 136.0
        },
        {
            x: 877.0,
            y: 73.5
        },
    ], {
        fill: green,
        id: 'x1id27'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 951.0,
            y: 73.5
        },
        {
            x: 888.0,
            y: 73.5
        },
        {
            x: 888.0,
            y: 136.0
        },
        {
            x: 951.0,
            y: 136.0
        },
        {
            x: 951.0,
            y: 73.5
        },
    ], {
        fill: green,
        id: 'x1id28'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 1025.0,
            y: 73.5
        },
        {
            x: 962.0,
            y: 73.5
        },
        {
            x: 962.0,
            y: 136.0
        },
        {
            x: 1025.0,
            y: 136.0
        },
        {
            x: 1025.0,
            y: 73.5
        },
    ], {
        fill: green,
        id: 'x1id29'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 1099.0,
            y: 73.5
        },
        {
            x: 1036.0,
            y: 73.5
        },
        {
            x: 1036.0,
            y: 136.0
        },
        {
            x: 1099.0,
            y: 136.0
        },
        {
            x: 1099.0,
            y: 73.5
        },
    ], {
        fill: green,
        id: 'x1id30'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 63.0,
            y: 147.0
        },
        {
            x: 0.0,
            y: 147.0
        },
        {
            x: 0.0,
            y: 209.5
        },
        {
            x: 63.0,
            y: 209.5
        },
        {
            x: 63.0,
            y: 147.0
        },
    ], {
        fill: green,
        id: 'x1id31'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 137.0,
            y: 147.0
        },
        {
            x: 74.0,
            y: 147.0
        },
        {
            x: 74.0,
            y: 209.5
        },
        {
            x: 137.0,
            y: 209.5
        },
        {
            x: 137.0,
            y: 147.0
        },
    ], {
        fill: green,
        id: 'x1id32'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 211.0,
            y: 147.0
        },
        {
            x: 148.0,
            y: 147.0
        },
        {
            x: 148.0,
            y: 209.5
        },
        {
            x: 211.0,
            y: 209.5
        },
        {
            x: 211.0,
            y: 147.0
        },
    ], {
        fill: green,
        id: 'x1id33'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 285.0,
            y: 147.0
        },
        {
            x: 222.0,
            y: 147.0
        },
        {
            x: 222.0,
            y: 209.5
        },
        {
            x: 285.0,
            y: 209.5
        },
        {
            x: 285.0,
            y: 147.0
        },
    ], {
        fill: green,
        id: 'x1id34'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 359.0,
            y: 147.0
        },
        {
            x: 296.0,
            y: 147.0
        },
        {
            x: 296.0,
            y: 209.5
        },
        {
            x: 359.0,
            y: 209.5
        },
        {
            x: 359.0,
            y: 147.0
        },
    ], {
        fill: green,
        id: 'x1id35'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 433.0,
            y: 147.0
        },
        {
            x: 370.0,
            y: 147.0
        },
        {
            x: 370.0,
            y: 209.5
        },
        {
            x: 433.0,
            y: 209.5
        },
        {
            x: 433.0,
            y: 147.0
        },
    ], {
        fill: green,
        id: 'x1id36'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 507.0,
            y: 147.0
        },
        {
            x: 444.0,
            y: 147.0
        },
        {
            x: 444.0,
            y: 209.5
        },
        {
            x: 507.0,
            y: 209.5
        },
        {
            x: 507.0,
            y: 147.0
        },
    ], {
        fill: green,
        id: 'x1id37'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 581.0,
            y: 147.0
        },
        {
            x: 518.0,
            y: 147.0
        },
        {
            x: 518.0,
            y: 209.5
        },
        {
            x: 581.0,
            y: 209.5
        },
        {
            x: 581.0,
            y: 147.0
        },
    ], {
        fill: green,
        id: 'x1id38'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 655.0,
            y: 147.0
        },
        {
            x: 592.0,
            y: 147.0
        },
        {
            x: 592.0,
            y: 209.5
        },
        {
            x: 655.0,
            y: 209.5
        },
        {
            x: 655.0,
            y: 147.0
        },
    ], {
        fill: green,
        id: 'x1id39'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 729.0,
            y: 147.0
        },
        {
            x: 666.0,
            y: 147.0
        },
        {
            x: 666.0,
            y: 209.5
        },
        {
            x: 729.0,
            y: 209.5
        },
        {
            x: 729.0,
            y: 147.0
        },
    ], {
        fill: green,
        id: 'x1id40'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 803.0,
            y: 147.0
        },
        {
            x: 740.0,
            y: 147.0
        },
        {
            x: 740.0,
            y: 209.5
        },
        {
            x: 803.0,
            y: 209.5
        },
        {
            x: 803.0,
            y: 147.0
        },
    ], {
        fill: green,
        id: 'x1id41'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 877.0,
            y: 147.0
        },
        {
            x: 814.0,
            y: 147.0
        },
        {
            x: 814.0,
            y: 209.5
        },
        {
            x: 877.0,
            y: 209.5
        },
        {
            x: 877.0,
            y: 147.0
        },
    ], {
        fill: green,
        id: 'x1id42'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 951.0,
            y: 147.0
        },
        {
            x: 888.0,
            y: 147.0
        },
        {
            x: 888.0,
            y: 209.5
        },
        {
            x: 951.0,
            y: 209.5
        },
        {
            x: 951.0,
            y: 147.0
        },
    ], {
        fill: green,
        id: 'x1id43'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 1025.0,
            y: 147.0
        },
        {
            x: 962.0,
            y: 147.0
        },
        {
            x: 962.0,
            y: 209.5
        },
        {
            x: 1025.0,
            y: 209.5
        },
        {
            x: 1025.0,
            y: 147.0
        },
    ], {
        fill: green,
        id: 'x1id44'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 1099.0,
            y: 147.0
        },
        {
            x: 1036.0,
            y: 147.0
        },
        {
            x: 1036.0,
            y: 209.5
        },
        {
            x: 1099.0,
            y: 209.5
        },
        {
            x: 1099.0,
            y: 147.0
        },
    ], {
        fill: green,
        id: 'x1id45'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 63.0,
            y: 220.5
        },
        {
            x: 0.0,
            y: 220.5
        },
        {
            x: 0.0,
            y: 283.0
        },
        {
            x: 63.0,
            y: 283.0
        },
        {
            x: 63.0,
            y: 220.5
        },
    ], {
        fill: green,
        id: 'x1id46'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 137.0,
            y: 220.5
        },
        {
            x: 74.0,
            y: 220.5
        },
        {
            x: 74.0,
            y: 283.0
        },
        {
            x: 137.0,
            y: 283.0
        },
        {
            x: 137.0,
            y: 220.5
        },
    ], {
        fill: green,
        id: 'x1id47'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 211.0,
            y: 220.5
        },
        {
            x: 148.0,
            y: 220.5
        },
        {
            x: 148.0,
            y: 283.0
        },
        {
            x: 211.0,
            y: 283.0
        },
        {
            x: 211.0,
            y: 220.5
        },
    ], {
        fill: green,
        id: 'x1id48'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 285.0,
            y: 220.5
        },
        {
            x: 222.0,
            y: 220.5
        },
        {
            x: 222.0,
            y: 283.0
        },
        {
            x: 285.0,
            y: 283.0
        },
        {
            x: 285.0,
            y: 220.5
        },
    ], {
        fill: green,
        id: 'x1id49'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 359.0,
            y: 220.5
        },
        {
            x: 296.0,
            y: 220.5
        },
        {
            x: 296.0,
            y: 283.0
        },
        {
            x: 359.0,
            y: 283.0
        },
        {
            x: 359.0,
            y: 220.5
        },
    ], {
        fill: green,
        id: 'x1id50'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 433.0,
            y: 220.5
        },
        {
            x: 370.0,
            y: 220.5
        },
        {
            x: 370.0,
            y: 283.0
        },
        {
            x: 433.0,
            y: 283.0
        },
        {
            x: 433.0,
            y: 220.5
        },
    ], {
        fill: green,
        id: 'x1id51'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 507.0,
            y: 220.5
        },
        {
            x: 444.0,
            y: 220.5
        },
        {
            x: 444.0,
            y: 283.0
        },
        {
            x: 507.0,
            y: 283.0
        },
        {
            x: 507.0,
            y: 220.5
        },
    ], {
        fill: green,
        id: 'x1id52'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 581.0,
            y: 220.5
        },
        {
            x: 518.0,
            y: 220.5
        },
        {
            x: 518.0,
            y: 283.0
        },
        {
            x: 581.0,
            y: 283.0
        },
        {
            x: 581.0,
            y: 220.5
        },
    ], {
        fill: green,
        id: 'x1id53'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 655.0,
            y: 220.5
        },
        {
            x: 592.0,
            y: 220.5
        },
        {
            x: 592.0,
            y: 283.0
        },
        {
            x: 655.0,
            y: 283.0
        },
        {
            x: 655.0,
            y: 220.5
        },
    ], {
        fill: green,
        id: 'x1id54'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 729.0,
            y: 220.5
        },
        {
            x: 666.0,
            y: 220.5
        },
        {
            x: 666.0,
            y: 283.0
        },
        {
            x: 729.0,
            y: 283.0
        },
        {
            x: 729.0,
            y: 220.5
        },
    ], {
        fill: green,
        id: 'x1id55'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 803.0,
            y: 220.5
        },
        {
            x: 740.0,
            y: 220.5
        },
        {
            x: 740.0,
            y: 283.0
        },
        {
            x: 803.0,
            y: 283.0
        },
        {
            x: 803.0,
            y: 220.5
        },
    ], {
        fill: green,
        id: 'x1id56'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 877.0,
            y: 220.5
        },
        {
            x: 814.0,
            y: 220.5
        },
        {
            x: 814.0,
            y: 283.0
        },
        {
            x: 877.0,
            y: 283.0
        },
        {
            x: 877.0,
            y: 220.5
        },
    ], {
        fill: green,
        id: 'x1id57'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 951.0,
            y: 220.5
        },
        {
            x: 888.0,
            y: 220.5
        },
        {
            x: 888.0,
            y: 283.0
        },
        {
            x: 951.0,
            y: 283.0
        },
        {
            x: 951.0,
            y: 220.5
        },
    ], {
        fill: green,
        id: 'x1id58'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 1025.0,
            y: 220.5
        },
        {
            x: 962.0,
            y: 220.5
        },
        {
            x: 962.0,
            y: 283.0
        },
        {
            x: 1025.0,
            y: 283.0
        },
        {
            x: 1025.0,
            y: 220.5
        },
    ], {
        fill: green,
        id: 'x1id59'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 1099.0,
            y: 220.5
        },
        {
            x: 1036.0,
            y: 220.5
        },
        {
            x: 1036.0,
            y: 283.0
        },
        {
            x: 1099.0,
            y: 283.0
        },
        {
            x: 1099.0,
            y: 220.5
        },
    ], {
        fill: green,
        id: 'x1id60'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 63.0,
            y: 294.0
        },
        {
            x: 0.0,
            y: 294.0
        },
        {
            x: 0.0,
            y: 356.5
        },
        {
            x: 63.0,
            y: 356.5
        },
        {
            x: 63.0,
            y: 294.0
        },
    ], {
        fill: green,
        id: 'x1id61'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 137.0,
            y: 294.0
        },
        {
            x: 74.0,
            y: 294.0
        },
        {
            x: 74.0,
            y: 356.5
        },
        {
            x: 137.0,
            y: 356.5
        },
        {
            x: 137.0,
            y: 294.0
        },
    ], {
        fill: green,
        id: 'x1id62'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 211.0,
            y: 294.0
        },
        {
            x: 148.0,
            y: 294.0
        },
        {
            x: 148.0,
            y: 356.5
        },
        {
            x: 211.0,
            y: 356.5
        },
        {
            x: 211.0,
            y: 294.0
        },
    ], {
        fill: green,
        id: 'x1id63'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 285.0,
            y: 294.0
        },
        {
            x: 222.0,
            y: 294.0
        },
        {
            x: 222.0,
            y: 356.5
        },
        {
            x: 285.0,
            y: 356.5
        },
        {
            x: 285.0,
            y: 294.0
        },
    ], {
        fill: green,
        id: 'x1id64'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 359.0,
            y: 294.0
        },
        {
            x: 296.0,
            y: 294.0
        },
        {
            x: 296.0,
            y: 356.5
        },
        {
            x: 359.0,
            y: 356.5
        },
        {
            x: 359.0,
            y: 294.0
        },
    ], {
        fill: green,
        id: 'x1id65'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 433.0,
            y: 294.0
        },
        {
            x: 370.0,
            y: 294.0
        },
        {
            x: 370.0,
            y: 356.5
        },
        {
            x: 433.0,
            y: 356.5
        },
        {
            x: 433.0,
            y: 294.0
        },
    ], {
        fill: green,
        id: 'x1id66'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 507.0,
            y: 294.0
        },
        {
            x: 444.0,
            y: 294.0
        },
        {
            x: 444.0,
            y: 356.5
        },
        {
            x: 507.0,
            y: 356.5
        },
        {
            x: 507.0,
            y: 294.0
        },
    ], {
        fill: green,
        id: 'x1id67'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 581.0,
            y: 294.0
        },
        {
            x: 518.0,
            y: 294.0
        },
        {
            x: 518.0,
            y: 356.5
        },
        {
            x: 581.0,
            y: 356.5
        },
        {
            x: 581.0,
            y: 294.0
        },
    ], {
        fill: green,
        id: 'x1id68'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 655.0,
            y: 294.0
        },
        {
            x: 592.0,
            y: 294.0
        },
        {
            x: 592.0,
            y: 356.5
        },
        {
            x: 655.0,
            y: 356.5
        },
        {
            x: 655.0,
            y: 294.0
        },
    ], {
        fill: green,
        id: 'x1id69'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 729.0,
            y: 294.0
        },
        {
            x: 666.0,
            y: 294.0
        },
        {
            x: 666.0,
            y: 356.5
        },
        {
            x: 729.0,
            y: 356.5
        },
        {
            x: 729.0,
            y: 294.0
        },
    ], {
        fill: green,
        id: 'x1id70'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 803.0,
            y: 294.0
        },
        {
            x: 740.0,
            y: 294.0
        },
        {
            x: 740.0,
            y: 356.5
        },
        {
            x: 803.0,
            y: 356.5
        },
        {
            x: 803.0,
            y: 294.0
        },
    ], {
        fill: green,
        id: 'x1id71'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 877.0,
            y: 294.0
        },
        {
            x: 814.0,
            y: 294.0
        },
        {
            x: 814.0,
            y: 356.5
        },
        {
            x: 877.0,
            y: 356.5
        },
        {
            x: 877.0,
            y: 294.0
        },
    ], {
        fill: green,
        id: 'x1id72'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 951.0,
            y: 294.0
        },
        {
            x: 888.0,
            y: 294.0
        },
        {
            x: 888.0,
            y: 356.5
        },
        {
            x: 951.0,
            y: 356.5
        },
        {
            x: 951.0,
            y: 294.0
        },
    ], {
        fill: green,
        id: 'x1id73'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 1025.0,
            y: 294.0
        },
        {
            x: 962.0,
            y: 294.0
        },
        {
            x: 962.0,
            y: 356.5
        },
        {
            x: 1025.0,
            y: 356.5
        },
        {
            x: 1025.0,
            y: 294.0
        },
    ], {
        fill: green,
        id: 'x1id74'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 1099.0,
            y: 294.0
        },
        {
            x: 1036.0,
            y: 294.0
        },
        {
            x: 1036.0,
            y: 356.5
        },
        {
            x: 1099.0,
            y: 356.5
        },
        {
            x: 1099.0,
            y: 294.0
        },
    ], {
        fill: green,
        id: 'x1id75'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 63.0,
            y: 367.5
        },
        {
            x: 0.0,
            y: 367.5
        },
        {
            x: 0.0,
            y: 430.0
        },
        {
            x: 63.0,
            y: 430.0
        },
        {
            x: 63.0,
            y: 367.5
        },
    ], {
        fill: green,
        id: 'x1id76'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 137.0,
            y: 367.5
        },
        {
            x: 74.0,
            y: 367.5
        },
        {
            x: 74.0,
            y: 430.0
        },
        {
            x: 137.0,
            y: 430.0
        },
        {
            x: 137.0,
            y: 367.5
        },
    ], {
        fill: green,
        id: 'x1id77'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 211.0,
            y: 367.5
        },
        {
            x: 148.0,
            y: 367.5
        },
        {
            x: 148.0,
            y: 430.0
        },
        {
            x: 211.0,
            y: 430.0
        },
        {
            x: 211.0,
            y: 367.5
        },
    ], {
        fill: green,
        id: 'x1id78'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 285.0,
            y: 367.5
        },
        {
            x: 222.0,
            y: 367.5
        },
        {
            x: 222.0,
            y: 430.0
        },
        {
            x: 285.0,
            y: 430.0
        },
        {
            x: 285.0,
            y: 367.5
        },
    ], {
        fill: green,
        id: 'x1id79'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 359.0,
            y: 367.5
        },
        {
            x: 296.0,
            y: 367.5
        },
        {
            x: 296.0,
            y: 430.0
        },
        {
            x: 359.0,
            y: 430.0
        },
        {
            x: 359.0,
            y: 367.5
        },
    ], {
        fill: green,
        id: 'x1id80'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 877.0,
            y: 367.5
        },
        {
            x: 814.0,
            y: 367.5
        },
        {
            x: 814.0,
            y: 430.0
        },
        {
            x: 877.0,
            y: 430.0
        },
        {
            x: 877.0,
            y: 367.5
        },
    ], {
        fill: green,
        id: 'x1id81'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 951.0,
            y: 367.5
        },
        {
            x: 888.0,
            y: 367.5
        },
        {
            x: 888.0,
            y: 430.0
        },
        {
            x: 951.0,
            y: 430.0
        },
        {
            x: 951.0,
            y: 367.5
        },
    ], {
        fill: green,
        id: 'x1id82'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 1025.0,
            y: 367.5
        },
        {
            x: 962.0,
            y: 367.5
        },
        {
            x: 962.0,
            y: 430.0
        },
        {
            x: 1025.0,
            y: 430.0
        },
        {
            x: 1025.0,
            y: 367.5
        },
    ], {
        fill: green,
        id: 'x1id83'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 1099.0,
            y: 367.5
        },
        {
            x: 1036.0,
            y: 367.5
        },
        {
            x: 1036.0,
            y: 430.0
        },
        {
            x: 1099.0,
            y: 430.0
        },
        {
            x: 1099.0,
            y: 367.5
        },
    ], {
        fill: green,
        id: 'x1id84'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 63.0,
            y: 441.0
        },
        {
            x: 0.0,
            y: 441.0
        },
        {
            x: 0.0,
            y: 503.6
        },
        {
            x: 63.0,
            y: 503.6
        },
        {
            x: 63.0,
            y: 441.0
        },
    ], {
        fill: green,
        id: 'x1id85'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 137.0,
            y: 441.0
        },
        {
            x: 74.0,
            y: 441.0
        },
        {
            x: 74.0,
            y: 503.6
        },
        {
            x: 137.0,
            y: 503.6
        },
        {
            x: 137.0,
            y: 441.0
        },
    ], {
        fill: green,
        id: 'x1id86'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 211.0,
            y: 441.0
        },
        {
            x: 148.0,
            y: 441.0
        },
        {
            x: 148.0,
            y: 503.6
        },
        {
            x: 211.0,
            y: 503.6
        },
        {
            x: 211.0,
            y: 441.0
        },
    ], {
        fill: green,
        id: 'x1id87'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 285.0,
            y: 441.0
        },
        {
            x: 222.0,
            y: 441.0
        },
        {
            x: 222.0,
            y: 503.6
        },
        {
            x: 285.0,
            y: 503.6
        },
        {
            x: 285.0,
            y: 441.0
        },
    ], {
        fill: green,
        id: 'x1id88'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 359.0,
            y: 441.0
        },
        {
            x: 296.0,
            y: 441.0
        },
        {
            x: 296.0,
            y: 503.6
        },
        {
            x: 359.0,
            y: 503.6
        },
        {
            x: 359.0,
            y: 441.0
        },
    ], {
        fill: green,
        id: 'x1id89'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 877.0,
            y: 441.0
        },
        {
            x: 814.0,
            y: 441.0
        },
        {
            x: 814.0,
            y: 503.6
        },
        {
            x: 877.0,
            y: 503.6
        },
        {
            x: 877.0,
            y: 441.0
        },
    ], {
        fill: green,
        id: 'x1id90'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 951.0,
            y: 441.0
        },
        {
            x: 888.0,
            y: 441.0
        },
        {
            x: 888.0,
            y: 503.6
        },
        {
            x: 951.0,
            y: 503.6
        },
        {
            x: 951.0,
            y: 441.0
        },
    ], {
        fill: green,
        id: 'x1id91'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 1025.0,
            y: 441.0
        },
        {
            x: 962.0,
            y: 441.0
        },
        {
            x: 962.0,
            y: 503.6
        },
        {
            x: 1025.0,
            y: 503.6
        },
        {
            x: 1025.0,
            y: 441.0
        },
    ], {
        fill: green,
        id: 'x1id92'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 1099.0,
            y: 441.0
        },
        {
            x: 1036.0,
            y: 441.0
        },
        {
            x: 1036.0,
            y: 503.6
        },
        {
            x: 1099.0,
            y: 503.6
        },
        {
            x: 1099.0,
            y: 441.0
        },
    ], {
        fill: green,
        id: 'x1id93'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 63.0,
            y: 514.6
        },
        {
            x: 0.0,
            y: 514.6
        },
        {
            x: 0.0,
            y: 577.1
        },
        {
            x: 63.0,
            y: 577.1
        },
        {
            x: 63.0,
            y: 514.6
        },
    ], {
        fill: green,
        id: 'x1id94'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 137.0,
            y: 514.6
        },
        {
            x: 74.0,
            y: 514.6
        },
        {
            x: 74.0,
            y: 577.1
        },
        {
            x: 137.0,
            y: 577.1
        },
        {
            x: 137.0,
            y: 514.6
        },
    ], {
        fill: green,
        id: 'x1id95'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 211.0,
            y: 514.6
        },
        {
            x: 148.0,
            y: 514.6
        },
        {
            x: 148.0,
            y: 577.1
        },
        {
            x: 211.0,
            y: 577.1
        },
        {
            x: 211.0,
            y: 514.6
        },
    ], {
        fill: green,
        id: 'x1id96'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 285.0,
            y: 514.6
        },
        {
            x: 222.0,
            y: 514.6
        },
        {
            x: 222.0,
            y: 577.1
        },
        {
            x: 285.0,
            y: 577.1
        },
        {
            x: 285.0,
            y: 514.6
        },
    ], {
        fill: green,
        id: 'x1id97'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 359.0,
            y: 514.6
        },
        {
            x: 296.0,
            y: 514.6
        },
        {
            x: 296.0,
            y: 577.1
        },
        {
            x: 359.0,
            y: 577.1
        },
        {
            x: 359.0,
            y: 514.6
        },
    ], {
        fill: green,
        id: 'x1id98'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 877.0,
            y: 514.6
        },
        {
            x: 814.0,
            y: 514.6
        },
        {
            x: 814.0,
            y: 577.1
        },
        {
            x: 877.0,
            y: 577.1
        },
        {
            x: 877.0,
            y: 514.6
        },
    ], {
        fill: green,
        id: 'x1id99'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 951.0,
            y: 514.6
        },
        {
            x: 888.0,
            y: 514.6
        },
        {
            x: 888.0,
            y: 577.1
        },
        {
            x: 951.0,
            y: 577.1
        },
        {
            x: 951.0,
            y: 514.6
        },
    ], {
        fill: green,
        id: 'x1id100'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 1025.0,
            y: 514.6
        },
        {
            x: 962.0,
            y: 514.6
        },
        {
            x: 962.0,
            y: 577.1
        },
        {
            x: 1025.0,
            y: 577.1
        },
        {
            x: 1025.0,
            y: 514.6
        },
    ], {
        fill: green,
        id: 'x1id101'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 1099.0,
            y: 514.6
        },
        {
            x: 1036.0,
            y: 514.6
        },
        {
            x: 1036.0,
            y: 577.1
        },
        {
            x: 1099.0,
            y: 577.1
        },
        {
            x: 1099.0,
            y: 514.6
        },
    ], {
        fill: green,
        id: 'x1id102'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 63.0,
            y: 588.1
        },
        {
            x: 0.0,
            y: 588.1
        },
        {
            x: 0.0,
            y: 650.6
        },
        {
            x: 63.0,
            y: 650.6
        },
        {
            x: 63.0,
            y: 588.1
        },
    ], {
        fill: green,
        id: 'x1id103'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 137.0,
            y: 588.1
        },
        {
            x: 74.0,
            y: 588.1
        },
        {
            x: 74.0,
            y: 650.6
        },
        {
            x: 137.0,
            y: 650.6
        },
        {
            x: 137.0,
            y: 588.1
        },
    ], {
        fill: green,
        id: 'x1id104'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 211.0,
            y: 588.1
        },
        {
            x: 148.0,
            y: 588.1
        },
        {
            x: 148.0,
            y: 650.6
        },
        {
            x: 211.0,
            y: 650.6
        },
        {
            x: 211.0,
            y: 588.1
        },
    ], {
        fill: green,
        id: 'x1id105'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 285.0,
            y: 588.1
        },
        {
            x: 222.0,
            y: 588.1
        },
        {
            x: 222.0,
            y: 650.6
        },
        {
            x: 285.0,
            y: 650.6
        },
        {
            x: 285.0,
            y: 588.1
        },
    ], {
        fill: green,
        id: 'x1id106'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 359.0,
            y: 588.1
        },
        {
            x: 296.0,
            y: 588.1
        },
        {
            x: 296.0,
            y: 650.6
        },
        {
            x: 359.0,
            y: 650.6
        },
        {
            x: 359.0,
            y: 588.1
        },
    ], {
        fill: green,
        id: 'x1id107'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 877.0,
            y: 588.1
        },
        {
            x: 814.0,
            y: 588.1
        },
        {
            x: 814.0,
            y: 650.6
        },
        {
            x: 877.0,
            y: 650.6
        },
        {
            x: 877.0,
            y: 588.1
        },
    ], {
        fill: green,
        id: 'x1id108'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 951.0,
            y: 588.1
        },
        {
            x: 888.0,
            y: 588.1
        },
        {
            x: 888.0,
            y: 650.6
        },
        {
            x: 951.0,
            y: 650.6
        },
        {
            x: 951.0,
            y: 588.1
        },
    ], {
        fill: green,
        id: 'x1id109'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 1025.0,
            y: 588.1
        },
        {
            x: 962.0,
            y: 588.1
        },
        {
            x: 962.0,
            y: 650.6
        },
        {
            x: 1025.0,
            y: 650.6
        },
        {
            x: 1025.0,
            y: 588.1
        },
    ], {
        fill: green,
        id: 'x1id110'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 1099.0,
            y: 588.1
        },
        {
            x: 1036.0,
            y: 588.1
        },
        {
            x: 1036.0,
            y: 650.6
        },
        {
            x: 1099.0,
            y: 650.6
        },
        {
            x: 1099.0,
            y: 588.1
        },
    ], {
        fill: green,
        id: 'x1id111'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 63.0,
            y: 661.6
        },
        {
            x: 0.0,
            y: 661.6
        },
        {
            x: 0.0,
            y: 724.1
        },
        {
            x: 63.0,
            y: 724.1
        },
        {
            x: 63.0,
            y: 661.6
        },
    ], {
        fill: green,
        id: 'x1id112'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 137.0,
            y: 661.6
        },
        {
            x: 74.0,
            y: 661.6
        },
        {
            x: 74.0,
            y: 724.1
        },
        {
            x: 137.0,
            y: 724.1
        },
        {
            x: 137.0,
            y: 661.6
        },
    ], {
        fill: green,
        id: 'x1id113'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 211.0,
            y: 661.6
        },
        {
            x: 148.0,
            y: 661.6
        },
        {
            x: 148.0,
            y: 724.1
        },
        {
            x: 211.0,
            y: 724.1
        },
        {
            x: 211.0,
            y: 661.6
        },
    ], {
        fill: green,
        id: 'x1id114'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 285.0,
            y: 661.6
        },
        {
            x: 222.0,
            y: 661.6
        },
        {
            x: 222.0,
            y: 724.1
        },
        {
            x: 285.0,
            y: 724.1
        },
        {
            x: 285.0,
            y: 661.6
        },
    ], {
        fill: green,
        id: 'x1id115'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 359.0,
            y: 661.6
        },
        {
            x: 296.0,
            y: 661.6
        },
        {
            x: 296.0,
            y: 724.1
        },
        {
            x: 359.0,
            y: 724.1
        },
        {
            x: 359.0,
            y: 661.6
        },
    ], {
        fill: green,
        id: 'x1id116'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 877.0,
            y: 661.6
        },
        {
            x: 814.0,
            y: 661.6
        },
        {
            x: 814.0,
            y: 724.1
        },
        {
            x: 877.0,
            y: 724.1
        },
        {
            x: 877.0,
            y: 661.6
        },
    ], {
        fill: green,
        id: 'x1id117'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 951.0,
            y: 661.6
        },
        {
            x: 888.0,
            y: 661.6
        },
        {
            x: 888.0,
            y: 724.1
        },
        {
            x: 951.0,
            y: 724.1
        },
        {
            x: 951.0,
            y: 661.6
        },
    ], {
        fill: green,
        id: 'x1id118'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 1025.0,
            y: 661.6
        },
        {
            x: 962.0,
            y: 661.6
        },
        {
            x: 962.0,
            y: 724.1
        },
        {
            x: 1025.0,
            y: 724.1
        },
        {
            x: 1025.0,
            y: 661.6
        },
    ], {
        fill: green,
        id: 'x1id119'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 1099.0,
            y: 661.6
        },
        {
            x: 1036.0,
            y: 661.6
        },
        {
            x: 1036.0,
            y: 724.1
        },
        {
            x: 1099.0,
            y: 724.1
        },
        {
            x: 1099.0,
            y: 661.6
        },
    ], {
        fill: green,
        id: 'x1id120'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 63.0,
            y: 735.1
        },
        {
            x: 0.0,
            y: 735.1
        },
        {
            x: 0.0,
            y: 797.6
        },
        {
            x: 63.0,
            y: 797.6
        },
        {
            x: 63.0,
            y: 735.1
        },
    ], {
        fill: green,
        id: 'x1id121'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 137.0,
            y: 735.1
        },
        {
            x: 74.0,
            y: 735.1
        },
        {
            x: 74.0,
            y: 797.6
        },
        {
            x: 137.0,
            y: 797.6
        },
        {
            x: 137.0,
            y: 735.1
        },
    ], {
        fill: green,
        id: 'x1id122'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 211.0,
            y: 735.1
        },
        {
            x: 148.0,
            y: 735.1
        },
        {
            x: 148.0,
            y: 797.6
        },
        {
            x: 211.0,
            y: 797.6
        },
        {
            x: 211.0,
            y: 735.1
        },
    ], {
        fill: green,
        id: 'x1id123'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 285.0,
            y: 735.1
        },
        {
            x: 222.0,
            y: 735.1
        },
        {
            x: 222.0,
            y: 797.6
        },
        {
            x: 285.0,
            y: 797.6
        },
        {
            x: 285.0,
            y: 735.1
        },
    ], {
        fill: green,
        id: 'x1id124'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 359.0,
            y: 735.1
        },
        {
            x: 296.0,
            y: 735.1
        },
        {
            x: 296.0,
            y: 797.6
        },
        {
            x: 359.0,
            y: 797.6
        },
        {
            x: 359.0,
            y: 735.1
        },
    ], {
        fill: green,
        id: 'x1id125'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 433.0,
            y: 735.1
        },
        {
            x: 370.0,
            y: 735.1
        },
        {
            x: 370.0,
            y: 797.6
        },
        {
            x: 433.0,
            y: 797.6
        },
        {
            x: 433.0,
            y: 735.1
        },
    ], {
        fill: green,
        id: 'x1id126'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 507.0,
            y: 735.1
        },
        {
            x: 444.0,
            y: 735.1
        },
        {
            x: 444.0,
            y: 797.6
        },
        {
            x: 507.0,
            y: 797.6
        },
        {
            x: 507.0,
            y: 735.1
        },
    ], {
        fill: green,
        id: 'x1id127'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 581.0,
            y: 735.1
        },
        {
            x: 518.0,
            y: 735.1
        },
        {
            x: 518.0,
            y: 797.6
        },
        {
            x: 581.0,
            y: 797.6
        },
        {
            x: 581.0,
            y: 735.1
        },
    ], {
        fill: green,
        id: 'x1id128'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 655.0,
            y: 735.1
        },
        {
            x: 592.0,
            y: 735.1
        },
        {
            x: 592.0,
            y: 797.6
        },
        {
            x: 655.0,
            y: 797.6
        },
        {
            x: 655.0,
            y: 735.1
        },
    ], {
        fill: green,
        id: 'x1id129'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 729.0,
            y: 735.1
        },
        {
            x: 666.0,
            y: 735.1
        },
        {
            x: 666.0,
            y: 797.6
        },
        {
            x: 729.0,
            y: 797.6
        },
        {
            x: 729.0,
            y: 735.1
        },
    ], {
        fill: green,
        id: 'x1id130'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 803.0,
            y: 735.1
        },
        {
            x: 740.0,
            y: 735.1
        },
        {
            x: 740.0,
            y: 797.6
        },
        {
            x: 803.0,
            y: 797.6
        },
        {
            x: 803.0,
            y: 735.1
        },
    ], {
        fill: green,
        id: 'x1id131'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 877.0,
            y: 735.1
        },
        {
            x: 814.0,
            y: 735.1
        },
        {
            x: 814.0,
            y: 797.6
        },
        {
            x: 877.0,
            y: 797.6
        },
        {
            x: 877.0,
            y: 735.1
        },
    ], {
        fill: green,
        id: 'x1id132'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 951.0,
            y: 735.1
        },
        {
            x: 888.0,
            y: 735.1
        },
        {
            x: 888.0,
            y: 797.6
        },
        {
            x: 951.0,
            y: 797.6
        },
        {
            x: 951.0,
            y: 735.1
        },
    ], {
        fill: green,
        id: 'x1id133'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 1025.0,
            y: 735.1
        },
        {
            x: 962.0,
            y: 735.1
        },
        {
            x: 962.0,
            y: 797.6
        },
        {
            x: 1025.0,
            y: 797.6
        },
        {
            x: 1025.0,
            y: 735.1
        },
    ], {
        fill: green,
        id: 'x1id134'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 1099.0,
            y: 735.1
        },
        {
            x: 1036.0,
            y: 735.1
        },
        {
            x: 1036.0,
            y: 797.6
        },
        {
            x: 1099.0,
            y: 797.6
        },
        {
            x: 1099.0,
            y: 735.1
        },
    ], {
        fill: green,
        id: 'x1id135'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 63.0,
            y: 808.6
        },
        {
            x: 0.0,
            y: 808.6
        },
        {
            x: 0.0,
            y: 871.1
        },
        {
            x: 63.0,
            y: 871.1
        },
        {
            x: 63.0,
            y: 808.6
        },
    ], {
        fill: green,
        id: 'x1id136'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 137.0,
            y: 808.6
        },
        {
            x: 74.0,
            y: 808.6
        },
        {
            x: 74.0,
            y: 871.1
        },
        {
            x: 137.0,
            y: 871.1
        },
        {
            x: 137.0,
            y: 808.6
        },
    ], {
        fill: green,
        id: 'x1id137'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 211.0,
            y: 808.6
        },
        {
            x: 148.0,
            y: 808.6
        },
        {
            x: 148.0,
            y: 871.1
        },
        {
            x: 211.0,
            y: 871.1
        },
        {
            x: 211.0,
            y: 808.6
        },
    ], {
        fill: green,
        id: 'x1id138'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 285.0,
            y: 808.6
        },
        {
            x: 222.0,
            y: 808.6
        },
        {
            x: 222.0,
            y: 871.1
        },
        {
            x: 285.0,
            y: 871.1
        },
        {
            x: 285.0,
            y: 808.6
        },
    ], {
        fill: green,
        id: 'x1id139'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 359.0,
            y: 808.6
        },
        {
            x: 296.0,
            y: 808.6
        },
        {
            x: 296.0,
            y: 871.1
        },
        {
            x: 359.0,
            y: 871.1
        },
        {
            x: 359.0,
            y: 808.6
        },
    ], {
        fill: green,
        id: 'x1id140'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 433.0,
            y: 808.6
        },
        {
            x: 370.0,
            y: 808.6
        },
        {
            x: 370.0,
            y: 871.1
        },
        {
            x: 433.0,
            y: 871.1
        },
        {
            x: 433.0,
            y: 808.6
        },
    ], {
        fill: green,
        id: 'x1id141'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 507.0,
            y: 808.6
        },
        {
            x: 444.0,
            y: 808.6
        },
        {
            x: 444.0,
            y: 871.1
        },
        {
            x: 507.0,
            y: 871.1
        },
        {
            x: 507.0,
            y: 808.6
        },
    ], {
        fill: green,
        id: 'x1id142'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 581.0,
            y: 808.6
        },
        {
            x: 518.0,
            y: 808.6
        },
        {
            x: 518.0,
            y: 871.1
        },
        {
            x: 581.0,
            y: 871.1
        },
        {
            x: 581.0,
            y: 808.6
        },
    ], {
        fill: green,
        id: 'x1id143'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 655.0,
            y: 808.6
        },
        {
            x: 592.0,
            y: 808.6
        },
        {
            x: 592.0,
            y: 871.1
        },
        {
            x: 655.0,
            y: 871.1
        },
        {
            x: 655.0,
            y: 808.6
        },
    ], {
        fill: green,
        id: 'x1id144'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 729.0,
            y: 808.6
        },
        {
            x: 666.0,
            y: 808.6
        },
        {
            x: 666.0,
            y: 871.1
        },
        {
            x: 729.0,
            y: 871.1
        },
        {
            x: 729.0,
            y: 808.6
        },
    ], {
        fill: green,
        id: 'x1id145'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 803.0,
            y: 808.6
        },
        {
            x: 740.0,
            y: 808.6
        },
        {
            x: 740.0,
            y: 871.1
        },
        {
            x: 803.0,
            y: 871.1
        },
        {
            x: 803.0,
            y: 808.6
        },
    ], {
        fill: green,
        id: 'x1id146'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 877.0,
            y: 808.6
        },
        {
            x: 814.0,
            y: 808.6
        },
        {
            x: 814.0,
            y: 871.1
        },
        {
            x: 877.0,
            y: 871.1
        },
        {
            x: 877.0,
            y: 808.6
        },
    ], {
        fill: green,
        id: 'x1id147'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 951.0,
            y: 808.6
        },
        {
            x: 888.0,
            y: 808.6
        },
        {
            x: 888.0,
            y: 871.1
        },
        {
            x: 951.0,
            y: 871.1
        },
        {
            x: 951.0,
            y: 808.6
        },
    ], {
        fill: green,
        id: 'x1id148'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 1025.0,
            y: 808.6
        },
        {
            x: 962.0,
            y: 808.6
        },
        {
            x: 962.0,
            y: 871.1
        },
        {
            x: 1025.0,
            y: 871.1
        },
        {
            x: 1025.0,
            y: 808.6
        },
    ], {
        fill: green,
        id: 'x1id149'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 1099.0,
            y: 808.6
        },
        {
            x: 1036.0,
            y: 808.6
        },
        {
            x: 1036.0,
            y: 871.1
        },
        {
            x: 1099.0,
            y: 871.1
        },
        {
            x: 1099.0,
            y: 808.6
        },
    ], {
        fill: green,
        id: 'x1id150'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 63.0,
            y: 882.1
        },
        {
            x: 0.0,
            y: 882.1
        },
        {
            x: 0.0,
            y: 944.6
        },
        {
            x: 63.0,
            y: 944.6
        },
        {
            x: 63.0,
            y: 882.1
        },
    ], {
        fill: green,
        id: 'x1id151'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 137.0,
            y: 882.1
        },
        {
            x: 74.0,
            y: 882.1
        },
        {
            x: 74.0,
            y: 944.6
        },
        {
            x: 137.0,
            y: 944.6
        },
        {
            x: 137.0,
            y: 882.1
        },
    ], {
        fill: green,
        id: 'x1id152'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 211.0,
            y: 882.1
        },
        {
            x: 148.0,
            y: 882.1
        },
        {
            x: 148.0,
            y: 944.6
        },
        {
            x: 211.0,
            y: 944.6
        },
        {
            x: 211.0,
            y: 882.1
        },
    ], {
        fill: green,
        id: 'x1id153'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 285.0,
            y: 882.1
        },
        {
            x: 222.0,
            y: 882.1
        },
        {
            x: 222.0,
            y: 944.6
        },
        {
            x: 285.0,
            y: 944.6
        },
        {
            x: 285.0,
            y: 882.1
        },
    ], {
        fill: green,
        id: 'x1id154'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 359.0,
            y: 882.1
        },
        {
            x: 296.0,
            y: 882.1
        },
        {
            x: 296.0,
            y: 944.6
        },
        {
            x: 359.0,
            y: 944.6
        },
        {
            x: 359.0,
            y: 882.1
        },
    ], {
        fill: green,
        id: 'x1id155'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 433.0,
            y: 882.1
        },
        {
            x: 370.0,
            y: 882.1
        },
        {
            x: 370.0,
            y: 944.6
        },
        {
            x: 433.0,
            y: 944.6
        },
        {
            x: 433.0,
            y: 882.1
        },
    ], {
        fill: green,
        id: 'x1id156'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 507.0,
            y: 882.1
        },
        {
            x: 444.0,
            y: 882.1
        },
        {
            x: 444.0,
            y: 944.6
        },
        {
            x: 507.0,
            y: 944.6
        },
        {
            x: 507.0,
            y: 882.1
        },
    ], {
        fill: green,
        id: 'x1id157'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 581.0,
            y: 882.1
        },
        {
            x: 518.0,
            y: 882.1
        },
        {
            x: 518.0,
            y: 944.6
        },
        {
            x: 581.0,
            y: 944.6
        },
        {
            x: 581.0,
            y: 882.1
        },
    ], {
        fill: green,
        id: 'x1id158'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 655.0,
            y: 882.1
        },
        {
            x: 592.0,
            y: 882.1
        },
        {
            x: 592.0,
            y: 944.6
        },
        {
            x: 655.0,
            y: 944.6
        },
        {
            x: 655.0,
            y: 882.1
        },
    ], {
        fill: green,
        id: 'x1id159'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 729.0,
            y: 882.1
        },
        {
            x: 666.0,
            y: 882.1
        },
        {
            x: 666.0,
            y: 944.6
        },
        {
            x: 729.0,
            y: 944.6
        },
        {
            x: 729.0,
            y: 882.1
        },
    ], {
        fill: green,
        id: 'x1id160'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 803.0,
            y: 882.1
        },
        {
            x: 740.0,
            y: 882.1
        },
        {
            x: 740.0,
            y: 944.6
        },
        {
            x: 803.0,
            y: 944.6
        },
        {
            x: 803.0,
            y: 882.1
        },
    ], {
        fill: green,
        id: 'x1id161'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 877.0,
            y: 882.1
        },
        {
            x: 814.0,
            y: 882.1
        },
        {
            x: 814.0,
            y: 944.6
        },
        {
            x: 877.0,
            y: 944.6
        },
        {
            x: 877.0,
            y: 882.1
        },
    ], {
        fill: green,
        id: 'x1id162'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 951.0,
            y: 882.1
        },
        {
            x: 888.0,
            y: 882.1
        },
        {
            x: 888.0,
            y: 944.6
        },
        {
            x: 951.0,
            y: 944.6
        },
        {
            x: 951.0,
            y: 882.1
        },
    ], {
        fill: green,
        id: 'x1id163'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 1025.0,
            y: 882.1
        },
        {
            x: 962.0,
            y: 882.1
        },
        {
            x: 962.0,
            y: 944.6
        },
        {
            x: 1025.0,
            y: 944.6
        },
        {
            x: 1025.0,
            y: 882.1
        },
    ], {
        fill: green,
        id: 'x1id164'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 1099.0,
            y: 882.1
        },
        {
            x: 1036.0,
            y: 882.1
        },
        {
            x: 1036.0,
            y: 944.6
        },
        {
            x: 1099.0,
            y: 944.6
        },
        {
            x: 1099.0,
            y: 882.1
        },
    ], {
        fill: green,
        id: 'x1id165'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 63.0,
            y: 955.6
        },
        {
            x: 0.0,
            y: 955.6
        },
        {
            x: 0.0,
            y: 1018.1
        },
        {
            x: 63.0,
            y: 1018.1
        },
        {
            x: 63.0,
            y: 955.6
        },
    ], {
        fill: green,
        id: 'x1id166'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 137.0,
            y: 955.6
        },
        {
            x: 74.0,
            y: 955.6
        },
        {
            x: 74.0,
            y: 1018.1
        },
        {
            x: 137.0,
            y: 1018.1
        },
        {
            x: 137.0,
            y: 955.6
        },
    ], {
        fill: green,
        id: 'x1id167'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 211.0,
            y: 955.6
        },
        {
            x: 148.0,
            y: 955.6
        },
        {
            x: 148.0,
            y: 1018.1
        },
        {
            x: 211.0,
            y: 1018.1
        },
        {
            x: 211.0,
            y: 955.6
        },
    ], {
        fill: green,
        id: 'x1id168'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 285.0,
            y: 955.6
        },
        {
            x: 222.0,
            y: 955.6
        },
        {
            x: 222.0,
            y: 1018.1
        },
        {
            x: 285.0,
            y: 1018.1
        },
        {
            x: 285.0,
            y: 955.6
        },
    ], {
        fill: green,
        id: 'x1id169'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 359.0,
            y: 955.6
        },
        {
            x: 296.0,
            y: 955.6
        },
        {
            x: 296.0,
            y: 1018.1
        },
        {
            x: 359.0,
            y: 1018.1
        },
        {
            x: 359.0,
            y: 955.6
        },
    ], {
        fill: green,
        id: 'x1id170'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 433.0,
            y: 955.6
        },
        {
            x: 370.0,
            y: 955.6
        },
        {
            x: 370.0,
            y: 1018.1
        },
        {
            x: 433.0,
            y: 1018.1
        },
        {
            x: 433.0,
            y: 955.6
        },
    ], {
        fill: green,
        id: 'x1id171'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 507.0,
            y: 955.6
        },
        {
            x: 444.0,
            y: 955.6
        },
        {
            x: 444.0,
            y: 1018.1
        },
        {
            x: 507.0,
            y: 1018.1
        },
        {
            x: 507.0,
            y: 955.6
        },
    ], {
        fill: green,
        id: 'x1id172'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 581.0,
            y: 955.6
        },
        {
            x: 518.0,
            y: 955.6
        },
        {
            x: 518.0,
            y: 1018.1
        },
        {
            x: 581.0,
            y: 1018.1
        },
        {
            x: 581.0,
            y: 955.6
        },
    ], {
        fill: green,
        id: 'x1id173'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 655.0,
            y: 955.6
        },
        {
            x: 592.0,
            y: 955.6
        },
        {
            x: 592.0,
            y: 1018.1
        },
        {
            x: 655.0,
            y: 1018.1
        },
        {
            x: 655.0,
            y: 955.6
        },
    ], {
        fill: green,
        id: 'x1id174'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 729.0,
            y: 955.6
        },
        {
            x: 666.0,
            y: 955.6
        },
        {
            x: 666.0,
            y: 1018.1
        },
        {
            x: 729.0,
            y: 1018.1
        },
        {
            x: 729.0,
            y: 955.6
        },
    ], {
        fill: green,
        id: 'x1id175'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 803.0,
            y: 955.6
        },
        {
            x: 740.0,
            y: 955.6
        },
        {
            x: 740.0,
            y: 1018.1
        },
        {
            x: 803.0,
            y: 1018.1
        },
        {
            x: 803.0,
            y: 955.6
        },
    ], {
        fill: green,
        id: 'x1id176'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 877.0,
            y: 955.6
        },
        {
            x: 814.0,
            y: 955.6
        },
        {
            x: 814.0,
            y: 1018.1
        },
        {
            x: 877.0,
            y: 1018.1
        },
        {
            x: 877.0,
            y: 955.6
        },
    ], {
        fill: green,
        id: 'x1id177'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 951.0,
            y: 955.6
        },
        {
            x: 888.0,
            y: 955.6
        },
        {
            x: 888.0,
            y: 1018.1
        },
        {
            x: 951.0,
            y: 1018.1
        },
        {
            x: 951.0,
            y: 955.6
        },
    ], {
        fill: green,
        id: 'x1id178'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 1025.0,
            y: 955.6
        },
        {
            x: 962.0,
            y: 955.6
        },
        {
            x: 962.0,
            y: 1018.1
        },
        {
            x: 1025.0,
            y: 1018.1
        },
        {
            x: 1025.0,
            y: 955.6
        },
    ], {
        fill: green,
        id: 'x1id179'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 1099.0,
            y: 955.6
        },
        {
            x: 1036.0,
            y: 955.6
        },
        {
            x: 1036.0,
            y: 1018.1
        },
        {
            x: 1099.0,
            y: 1018.1
        },
        {
            x: 1099.0,
            y: 955.6
        },
    ], {
        fill: green,
        id: 'x1id180'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 63.0,
            y: 1029.1
        },
        {
            x: 0.0,
            y: 1029.1
        },
        {
            x: 0.0,
            y: 1091.6
        },
        {
            x: 63.0,
            y: 1091.6
        },
        {
            x: 63.0,
            y: 1029.1
        },
    ], {
        fill: green,
        id: 'x1id181'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 137.0,
            y: 1029.1
        },
        {
            x: 74.0,
            y: 1029.1
        },
        {
            x: 74.0,
            y: 1091.6
        },
        {
            x: 137.0,
            y: 1091.6
        },
        {
            x: 137.0,
            y: 1029.1
        },
    ], {
        fill: green,
        id: 'x1id182'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 211.0,
            y: 1029.1
        },
        {
            x: 148.0,
            y: 1029.1
        },
        {
            x: 148.0,
            y: 1091.6
        },
        {
            x: 211.0,
            y: 1091.6
        },
        {
            x: 211.0,
            y: 1029.1
        },
    ], {
        fill: green,
        id: 'x1id183'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 285.0,
            y: 1029.1
        },
        {
            x: 222.0,
            y: 1029.1
        },
        {
            x: 222.0,
            y: 1091.6
        },
        {
            x: 285.0,
            y: 1091.6
        },
        {
            x: 285.0,
            y: 1029.1
        },
    ], {
        fill: green,
        id: 'x1id184'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 359.0,
            y: 1029.1
        },
        {
            x: 296.0,
            y: 1029.1
        },
        {
            x: 296.0,
            y: 1091.6
        },
        {
            x: 359.0,
            y: 1091.6
        },
        {
            x: 359.0,
            y: 1029.1
        },
    ], {
        fill: green,
        id: 'x1id185'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 433.0,
            y: 1029.1
        },
        {
            x: 370.0,
            y: 1029.1
        },
        {
            x: 370.0,
            y: 1091.6
        },
        {
            x: 433.0,
            y: 1091.6
        },
        {
            x: 433.0,
            y: 1029.1
        },
    ], {
        fill: green,
        id: 'x1id186'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 507.0,
            y: 1029.1
        },
        {
            x: 444.0,
            y: 1029.1
        },
        {
            x: 444.0,
            y: 1091.6
        },
        {
            x: 507.0,
            y: 1091.6
        },
        {
            x: 507.0,
            y: 1029.1
        },
    ], {
        fill: green,
        id: 'x1id187'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 581.0,
            y: 1029.1
        },
        {
            x: 518.0,
            y: 1029.1
        },
        {
            x: 518.0,
            y: 1091.6
        },
        {
            x: 581.0,
            y: 1091.6
        },
        {
            x: 581.0,
            y: 1029.1
        },
    ], {
        fill: green,
        id: 'x1id188'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 655.0,
            y: 1029.1
        },
        {
            x: 592.0,
            y: 1029.1
        },
        {
            x: 592.0,
            y: 1091.6
        },
        {
            x: 655.0,
            y: 1091.6
        },
        {
            x: 655.0,
            y: 1029.1
        },
    ], {
        fill: green,
        id: 'x1id189'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 729.0,
            y: 1029.1
        },
        {
            x: 666.0,
            y: 1029.1
        },
        {
            x: 666.0,
            y: 1091.6
        },
        {
            x: 729.0,
            y: 1091.6
        },
        {
            x: 729.0,
            y: 1029.1
        },
    ], {
        fill: green,
        id: 'x1id190'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 803.0,
            y: 1029.1
        },
        {
            x: 740.0,
            y: 1029.1
        },
        {
            x: 740.0,
            y: 1091.6
        },
        {
            x: 803.0,
            y: 1091.6
        },
        {
            x: 803.0,
            y: 1029.1
        },
    ], {
        fill: green,
        id: 'x1id191'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 877.0,
            y: 1029.1
        },
        {
            x: 814.0,
            y: 1029.1
        },
        {
            x: 814.0,
            y: 1091.6
        },
        {
            x: 877.0,
            y: 1091.6
        },
        {
            x: 877.0,
            y: 1029.1
        },
    ], {
        fill: green,
        id: 'x1id192'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 951.0,
            y: 1029.1
        },
        {
            x: 888.0,
            y: 1029.1
        },
        {
            x: 888.0,
            y: 1091.6
        },
        {
            x: 951.0,
            y: 1091.6
        },
        {
            x: 951.0,
            y: 1029.1
        },
    ], {
        fill: green,
        id: 'x1id193'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 1025.0,
            y: 1029.1
        },
        {
            x: 962.0,
            y: 1029.1
        },
        {
            x: 962.0,
            y: 1091.6
        },
        {
            x: 1025.0,
            y: 1091.6
        },
        {
            x: 1025.0,
            y: 1029.1
        },
    ], {
        fill: green,
        id: 'x1id194'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 1099.0,
            y: 1029.1
        },
        {
            x: 1036.0,
            y: 1029.1
        },
        {
            x: 1036.0,
            y: 1091.6
        },
        {
            x: 1099.0,
            y: 1091.6
        },
        {
            x: 1099.0,
            y: 1029.1
        },
    ], {
        fill: green,
        id: 'x1id195'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 803.0,
            y: 367.5
        },
        {
            x: 740.0,
            y: 367.5
        },
        {
            x: 740.0,
            y: 430.0
        },
        {
            x: 803.0,
            y: 430.0
        },
        {
            x: 803.0,
            y: 367.5
        },
    ], {
        fill: green,
        id: 'x1id196'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 803.0,
            y: 441.0
        },
        {
            x: 740.0,
            y: 441.0
        },
        {
            x: 740.0,
            y: 503.6
        },
        {
            x: 803.0,
            y: 503.6
        },
        {
            x: 803.0,
            y: 441.0
        },
    ], {
        fill: green,
        id: 'x1id197'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 803.0,
            y: 514.6
        },
        {
            x: 740.0,
            y: 514.6
        },
        {
            x: 740.0,
            y: 577.1
        },
        {
            x: 803.0,
            y: 577.1
        },
        {
            x: 803.0,
            y: 514.6
        },
    ], {
        fill: green,
        id: 'x1id198'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 803.0,
            y: 588.1
        },
        {
            x: 740.0,
            y: 588.1
        },
        {
            x: 740.0,
            y: 650.6
        },
        {
            x: 803.0,
            y: 650.6
        },
        {
            x: 803.0,
            y: 588.1
        },
    ], {
        fill: green,
        id: 'x1id199'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 803.0,
            y: 661.4
        },
        {
            x: 740.0,
            y: 661.4
        },
        {
            x: 740.0,
            y: 723.9
        },
        {
            x: 803.0,
            y: 723.9
        },
        {
            x: 803.0,
            y: 661.4
        },
    ], {
        fill: green,
        id: 'x1id200'
    }))
    canvas1.add(new fabric.Polygon([{
            x: 726.5,
            y: 724.1
        },
        {
            x: 370.0,
            y: 724.1
        },
        {
            x: 370.0,
            y: 367.5
        },
        {
            x: 726.5,
            y: 367.5
        },
        {
            x: 726.5,
            y: 724.1
        },
    ], {
        fill: green,
        id: 'x1id201'
    }))
</script>
<?php /**PATH C:\Users\Dante\OneDrive\Desktop\Folders\partners\resources\views/components/map_1.blade.php ENDPATH**/ ?>