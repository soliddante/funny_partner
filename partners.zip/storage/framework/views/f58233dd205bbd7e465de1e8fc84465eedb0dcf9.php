<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layouts.app','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <style>
        body {
            background: linear-gradient(180deg, #002B49 0%, rgba(0, 2, 11, 1) 100%);
            background-repeat: no-repeat;
            min-height: 100vh;
            font-family: "Futura";
        }
    </style>
    <main class="pb-8 min-h-screen px-[24px] relative">

        <background class="h-full w-full  absolute -z-10 top-0 right-0">
            <img src="img/bg.svg" class="w-full h-[100%]">
        </background>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layouts.header','data' => ['navClass' => '!px-0']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['navClass' => '!px-0']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        <title class="block text-white mt-2 font-medium">Card:</title>
        <subtitle class="block text-white ">You signed <span>43</span> lands for <span>$300</span> dollars</subtitle>
        <lands class="flex  flex-wrap   gap-1">
        </lands>
        <script>
            for (i = 0; i <= 43; i++) {
                document.querySelector('lands').insertAdjacentHTML("beforeend",
                    `<rect class="bg-[#009120] w-[14px] h-[14px]"></rect>`)
            }
        </script>
        <title class="block mt-2 text-white font-medium"> Enter your information : </title>
        <grid class="grid grid-cols-2 gap-2">
            <column class="col-span-1">
                <label class="block">
                    <span class="text-white text-sm">Firstname</span>
                    <input type="text" class="h-[35px] leading-[35px] block w-full border-0 rounded">
                </label>
            </column>
            <column class="col-span-1">
                <label class="block">
                    <span class="text-white text-sm">Lastname</span>
                    <input type="text" class="h-[35px] leading-[35px] block w-full border-0 rounded">
                </label>
            </column>
            <column class="col-span-2">
                <label class="block relative">
                    <image src="img/mail.svg" class="absolute top-[32px] w-[20px] h-[20px]  left-2"></image>
                    </image>
                    <span class="text-white text-sm">Email</span>
                    <input type="text" class="h-[35px] leading-[35px] pl-10 block  w-full  border-0 rounded"
                        placeholder="email@example.com">
                </label>
            </column>
            <column class="col-span-2">
                <label class="block relative">
                    <image src="img/key.svg" class="absolute top-[32px] w-[20px] h-[20px]  left-2"></image>
                    </image>
                    <span class="text-white text-sm">Password</span>
                    <input type="text" class="h-[35px] leading-[35px] pl-10 block w-full  border-0 rounded"
                        placeholder="********">
                </label>
            </column>
            </column>
            <column class="col-span-2">
                <label class="block relative">
                    <image src="img/key.svg" class="absolute top-[32px] w-[20px] h-[20px]  left-2"></image>
                    </image>
                    <span class="text-white text-sm">Password Confrimation</span>
                    <input type="text" class="h-[35px] leading-[35px] pl-10 block  w-full  border-0 rounded"
                        placeholder="********">
                </label>
            </column>

            <column class="col-span-2">
                <label class="block relative">
                    <span class="text-white text-sm">Phone</span>
                    <input name="phone" type="text" id="phone" />
                </label>
            </column>
            <column class="col-span-2">
                <label class=" relative flex items-start">
                    <input type="checkbox" name="checkbox" class="mt-1 rounded mr-1 block">
                    <span class="text-white text-sm"> You understand and agree Privacy Policy, Terms of Service, and
                        Acceptable Use Policy.</span>
                </label>
            </column>
            <column class="col-span-2">
                <right>
                    <a href="<?php echo e(route('.page_2')); ?>"
                        class="bg-gradient-to-b block from-[#00A1D3] to-[#003867] text-center text-white font-semibold leading-[42px] h-[42px] w-full rounded">
                        Payment</a>
                </right>
            </column>

        </grid>
    </main>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.18/js/intlTelInput.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.18/css/intlTelInput.css">
    <script>
        var input = document.querySelector("#phone");
        window.intlTelInput(input, {
            separateDialCode: true
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Dante\OneDrive\Desktop\partners\resources\views/page_2.blade.php ENDPATH**/ ?>