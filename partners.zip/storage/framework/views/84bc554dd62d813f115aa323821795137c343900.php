<script src="<?php echo e(asset('js/fabric.min.js')); ?>"></script>
<script>
    var background = "#172524";
    var green = "#2ac161";
    var cyan = "#00b0ff";
    var purple = "#ff33e7";
    var canvas = new fabric.Canvas("canvas", {
        lockScalingX: true,
        lockScalingY: true,
        defaultCursor: 'default',
        backgroundColor: background,
        hoverCursor: 'default',
        moveCursor: 'default',

    });


    canvas.on('selection:created', function(ev) {
        ev.selected.forEach(element => {
            element.set({
                fill: purple,
                selectable: false,
            })
        });
    })

    canvas.on('mouse:down', function(ev) {


    })
    canvas.on('mouse:up', function(ev) {
        canvas.discardActiveObject();
    })

    canvas.add(new fabric.Polygon([{
            x: 0.0,
            y: 0.0
        },
        {
            x: 0.0,
            y: 62.5
        },
        {
            x: 63.0,
            y: 62.5
        },
        {
            x: 63.0,
            y: 0.0
        },
    ], {
        fill: green
    }))




    canvas.add(new fabric.Polygon([{
            x: 137.0,
            y: 0.0
        },
        {
            x: 74.0,
            y: 0.0
        },
        {
            x: 74.0,
            y: 62.5
        },
        {
            x: 137.0,
            y: 62.5
        },
        {
            x: 137.0,
            y: 0.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 211.0,
            y: 0.0
        },
        {
            x: 148.0,
            y: 0.0
        },
        {
            x: 148.0,
            y: 62.5
        },
        {
            x: 211.0,
            y: 62.5
        },
        {
            x: 211.0,
            y: 0.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 285.0,
            y: 0.0
        },
        {
            x: 222.0,
            y: 0.0
        },
        {
            x: 222.0,
            y: 62.5
        },
        {
            x: 285.0,
            y: 62.5
        },
        {
            x: 285.0,
            y: 0.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 359.0,
            y: 0.0
        },
        {
            x: 296.0,
            y: 0.0
        },
        {
            x: 296.0,
            y: 62.5
        },
        {
            x: 359.0,
            y: 62.5
        },
        {
            x: 359.0,
            y: 0.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 433.0,
            y: 0.0
        },
        {
            x: 370.0,
            y: 0.0
        },
        {
            x: 370.0,
            y: 62.5
        },
        {
            x: 433.0,
            y: 62.5
        },
        {
            x: 433.0,
            y: 0.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 507.0,
            y: 0.0
        },
        {
            x: 444.0,
            y: 0.0
        },
        {
            x: 444.0,
            y: 62.5
        },
        {
            x: 507.0,
            y: 62.5
        },
        {
            x: 507.0,
            y: 0.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 581.0,
            y: 0.0
        },
        {
            x: 518.0,
            y: 0.0
        },
        {
            x: 518.0,
            y: 62.5
        },
        {
            x: 581.0,
            y: 62.5
        },
        {
            x: 581.0,
            y: 0.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 655.0,
            y: 0.0
        },
        {
            x: 592.0,
            y: 0.0
        },
        {
            x: 592.0,
            y: 62.5
        },
        {
            x: 655.0,
            y: 62.5
        },
        {
            x: 655.0,
            y: 0.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 729.0,
            y: 0.0
        },
        {
            x: 666.0,
            y: 0.0
        },
        {
            x: 666.0,
            y: 62.5
        },
        {
            x: 729.0,
            y: 62.5
        },
        {
            x: 729.0,
            y: 0.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 803.0,
            y: 0.0
        },
        {
            x: 740.0,
            y: 0.0
        },
        {
            x: 740.0,
            y: 62.5
        },
        {
            x: 803.0,
            y: 62.5
        },
        {
            x: 803.0,
            y: 0.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 877.0,
            y: 0.0
        },
        {
            x: 814.0,
            y: 0.0
        },
        {
            x: 814.0,
            y: 62.5
        },
        {
            x: 877.0,
            y: 62.5
        },
        {
            x: 877.0,
            y: 0.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 951.0,
            y: 0.0
        },
        {
            x: 888.0,
            y: 0.0
        },
        {
            x: 888.0,
            y: 62.5
        },
        {
            x: 951.0,
            y: 62.5
        },
        {
            x: 951.0,
            y: 0.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 1025.0,
            y: 0.0
        },
        {
            x: 962.0,
            y: 0.0
        },
        {
            x: 962.0,
            y: 62.5
        },
        {
            x: 1025.0,
            y: 62.5
        },
        {
            x: 1025.0,
            y: 0.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 1099.0,
            y: 0.0
        },
        {
            x: 1036.0,
            y: 0.0
        },
        {
            x: 1036.0,
            y: 62.5
        },
        {
            x: 1099.0,
            y: 62.5
        },
        {
            x: 1099.0,
            y: 0.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 63.0,
            y: 73.5
        },
        {
            x: 0.0,
            y: 73.5
        },
        {
            x: 0.0,
            y: 136.0
        },
        {
            x: 63.0,
            y: 136.0
        },
        {
            x: 63.0,
            y: 73.5
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 137.0,
            y: 73.5
        },
        {
            x: 74.0,
            y: 73.5
        },
        {
            x: 74.0,
            y: 136.0
        },
        {
            x: 137.0,
            y: 136.0
        },
        {
            x: 137.0,
            y: 73.5
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 211.0,
            y: 73.5
        },
        {
            x: 148.0,
            y: 73.5
        },
        {
            x: 148.0,
            y: 136.0
        },
        {
            x: 211.0,
            y: 136.0
        },
        {
            x: 211.0,
            y: 73.5
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 285.0,
            y: 73.5
        },
        {
            x: 222.0,
            y: 73.5
        },
        {
            x: 222.0,
            y: 136.0
        },
        {
            x: 285.0,
            y: 136.0
        },
        {
            x: 285.0,
            y: 73.5
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 359.0,
            y: 73.5
        },
        {
            x: 296.0,
            y: 73.5
        },
        {
            x: 296.0,
            y: 136.0
        },
        {
            x: 359.0,
            y: 136.0
        },
        {
            x: 359.0,
            y: 73.5
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 433.0,
            y: 73.5
        },
        {
            x: 370.0,
            y: 73.5
        },
        {
            x: 370.0,
            y: 136.0
        },
        {
            x: 433.0,
            y: 136.0
        },
        {
            x: 433.0,
            y: 73.5
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 507.0,
            y: 73.5
        },
        {
            x: 444.0,
            y: 73.5
        },
        {
            x: 444.0,
            y: 136.0
        },
        {
            x: 507.0,
            y: 136.0
        },
        {
            x: 507.0,
            y: 73.5
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 581.0,
            y: 73.5
        },
        {
            x: 518.0,
            y: 73.5
        },
        {
            x: 518.0,
            y: 136.0
        },
        {
            x: 581.0,
            y: 136.0
        },
        {
            x: 581.0,
            y: 73.5
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 655.0,
            y: 73.5
        },
        {
            x: 592.0,
            y: 73.5
        },
        {
            x: 592.0,
            y: 136.0
        },
        {
            x: 655.0,
            y: 136.0
        },
        {
            x: 655.0,
            y: 73.5
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 729.0,
            y: 73.5
        },
        {
            x: 666.0,
            y: 73.5
        },
        {
            x: 666.0,
            y: 136.0
        },
        {
            x: 729.0,
            y: 136.0
        },
        {
            x: 729.0,
            y: 73.5
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 803.0,
            y: 73.5
        },
        {
            x: 740.0,
            y: 73.5
        },
        {
            x: 740.0,
            y: 136.0
        },
        {
            x: 803.0,
            y: 136.0
        },
        {
            x: 803.0,
            y: 73.5
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 877.0,
            y: 73.5
        },
        {
            x: 814.0,
            y: 73.5
        },
        {
            x: 814.0,
            y: 136.0
        },
        {
            x: 877.0,
            y: 136.0
        },
        {
            x: 877.0,
            y: 73.5
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 951.0,
            y: 73.5
        },
        {
            x: 888.0,
            y: 73.5
        },
        {
            x: 888.0,
            y: 136.0
        },
        {
            x: 951.0,
            y: 136.0
        },
        {
            x: 951.0,
            y: 73.5
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 1025.0,
            y: 73.5
        },
        {
            x: 962.0,
            y: 73.5
        },
        {
            x: 962.0,
            y: 136.0
        },
        {
            x: 1025.0,
            y: 136.0
        },
        {
            x: 1025.0,
            y: 73.5
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 1099.0,
            y: 73.5
        },
        {
            x: 1036.0,
            y: 73.5
        },
        {
            x: 1036.0,
            y: 136.0
        },
        {
            x: 1099.0,
            y: 136.0
        },
        {
            x: 1099.0,
            y: 73.5
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 63.0,
            y: 147.0
        },
        {
            x: 0.0,
            y: 147.0
        },
        {
            x: 0.0,
            y: 209.5
        },
        {
            x: 63.0,
            y: 209.5
        },
        {
            x: 63.0,
            y: 147.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 137.0,
            y: 147.0
        },
        {
            x: 74.0,
            y: 147.0
        },
        {
            x: 74.0,
            y: 209.5
        },
        {
            x: 137.0,
            y: 209.5
        },
        {
            x: 137.0,
            y: 147.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 211.0,
            y: 147.0
        },
        {
            x: 148.0,
            y: 147.0
        },
        {
            x: 148.0,
            y: 209.5
        },
        {
            x: 211.0,
            y: 209.5
        },
        {
            x: 211.0,
            y: 147.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 285.0,
            y: 147.0
        },
        {
            x: 222.0,
            y: 147.0
        },
        {
            x: 222.0,
            y: 209.5
        },
        {
            x: 285.0,
            y: 209.5
        },
        {
            x: 285.0,
            y: 147.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 359.0,
            y: 147.0
        },
        {
            x: 296.0,
            y: 147.0
        },
        {
            x: 296.0,
            y: 209.5
        },
        {
            x: 359.0,
            y: 209.5
        },
        {
            x: 359.0,
            y: 147.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 433.0,
            y: 147.0
        },
        {
            x: 370.0,
            y: 147.0
        },
        {
            x: 370.0,
            y: 209.5
        },
        {
            x: 433.0,
            y: 209.5
        },
        {
            x: 433.0,
            y: 147.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 507.0,
            y: 147.0
        },
        {
            x: 444.0,
            y: 147.0
        },
        {
            x: 444.0,
            y: 209.5
        },
        {
            x: 507.0,
            y: 209.5
        },
        {
            x: 507.0,
            y: 147.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 581.0,
            y: 147.0
        },
        {
            x: 518.0,
            y: 147.0
        },
        {
            x: 518.0,
            y: 209.5
        },
        {
            x: 581.0,
            y: 209.5
        },
        {
            x: 581.0,
            y: 147.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 655.0,
            y: 147.0
        },
        {
            x: 592.0,
            y: 147.0
        },
        {
            x: 592.0,
            y: 209.5
        },
        {
            x: 655.0,
            y: 209.5
        },
        {
            x: 655.0,
            y: 147.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 729.0,
            y: 147.0
        },
        {
            x: 666.0,
            y: 147.0
        },
        {
            x: 666.0,
            y: 209.5
        },
        {
            x: 729.0,
            y: 209.5
        },
        {
            x: 729.0,
            y: 147.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 803.0,
            y: 147.0
        },
        {
            x: 740.0,
            y: 147.0
        },
        {
            x: 740.0,
            y: 209.5
        },
        {
            x: 803.0,
            y: 209.5
        },
        {
            x: 803.0,
            y: 147.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 877.0,
            y: 147.0
        },
        {
            x: 814.0,
            y: 147.0
        },
        {
            x: 814.0,
            y: 209.5
        },
        {
            x: 877.0,
            y: 209.5
        },
        {
            x: 877.0,
            y: 147.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 951.0,
            y: 147.0
        },
        {
            x: 888.0,
            y: 147.0
        },
        {
            x: 888.0,
            y: 209.5
        },
        {
            x: 951.0,
            y: 209.5
        },
        {
            x: 951.0,
            y: 147.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 1025.0,
            y: 147.0
        },
        {
            x: 962.0,
            y: 147.0
        },
        {
            x: 962.0,
            y: 209.5
        },
        {
            x: 1025.0,
            y: 209.5
        },
        {
            x: 1025.0,
            y: 147.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 1099.0,
            y: 147.0
        },
        {
            x: 1036.0,
            y: 147.0
        },
        {
            x: 1036.0,
            y: 209.5
        },
        {
            x: 1099.0,
            y: 209.5
        },
        {
            x: 1099.0,
            y: 147.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 63.0,
            y: 220.5
        },
        {
            x: 0.0,
            y: 220.5
        },
        {
            x: 0.0,
            y: 283.0
        },
        {
            x: 63.0,
            y: 283.0
        },
        {
            x: 63.0,
            y: 220.5
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 137.0,
            y: 220.5
        },
        {
            x: 74.0,
            y: 220.5
        },
        {
            x: 74.0,
            y: 283.0
        },
        {
            x: 137.0,
            y: 283.0
        },
        {
            x: 137.0,
            y: 220.5
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 211.0,
            y: 220.5
        },
        {
            x: 148.0,
            y: 220.5
        },
        {
            x: 148.0,
            y: 283.0
        },
        {
            x: 211.0,
            y: 283.0
        },
        {
            x: 211.0,
            y: 220.5
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 285.0,
            y: 220.5
        },
        {
            x: 222.0,
            y: 220.5
        },
        {
            x: 222.0,
            y: 283.0
        },
        {
            x: 285.0,
            y: 283.0
        },
        {
            x: 285.0,
            y: 220.5
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 359.0,
            y: 220.5
        },
        {
            x: 296.0,
            y: 220.5
        },
        {
            x: 296.0,
            y: 283.0
        },
        {
            x: 359.0,
            y: 283.0
        },
        {
            x: 359.0,
            y: 220.5
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 433.0,
            y: 220.5
        },
        {
            x: 370.0,
            y: 220.5
        },
        {
            x: 370.0,
            y: 283.0
        },
        {
            x: 433.0,
            y: 283.0
        },
        {
            x: 433.0,
            y: 220.5
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 507.0,
            y: 220.5
        },
        {
            x: 444.0,
            y: 220.5
        },
        {
            x: 444.0,
            y: 283.0
        },
        {
            x: 507.0,
            y: 283.0
        },
        {
            x: 507.0,
            y: 220.5
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 581.0,
            y: 220.5
        },
        {
            x: 518.0,
            y: 220.5
        },
        {
            x: 518.0,
            y: 283.0
        },
        {
            x: 581.0,
            y: 283.0
        },
        {
            x: 581.0,
            y: 220.5
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 655.0,
            y: 220.5
        },
        {
            x: 592.0,
            y: 220.5
        },
        {
            x: 592.0,
            y: 283.0
        },
        {
            x: 655.0,
            y: 283.0
        },
        {
            x: 655.0,
            y: 220.5
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 729.0,
            y: 220.5
        },
        {
            x: 666.0,
            y: 220.5
        },
        {
            x: 666.0,
            y: 283.0
        },
        {
            x: 729.0,
            y: 283.0
        },
        {
            x: 729.0,
            y: 220.5
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 803.0,
            y: 220.5
        },
        {
            x: 740.0,
            y: 220.5
        },
        {
            x: 740.0,
            y: 283.0
        },
        {
            x: 803.0,
            y: 283.0
        },
        {
            x: 803.0,
            y: 220.5
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 877.0,
            y: 220.5
        },
        {
            x: 814.0,
            y: 220.5
        },
        {
            x: 814.0,
            y: 283.0
        },
        {
            x: 877.0,
            y: 283.0
        },
        {
            x: 877.0,
            y: 220.5
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 951.0,
            y: 220.5
        },
        {
            x: 888.0,
            y: 220.5
        },
        {
            x: 888.0,
            y: 283.0
        },
        {
            x: 951.0,
            y: 283.0
        },
        {
            x: 951.0,
            y: 220.5
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 1025.0,
            y: 220.5
        },
        {
            x: 962.0,
            y: 220.5
        },
        {
            x: 962.0,
            y: 283.0
        },
        {
            x: 1025.0,
            y: 283.0
        },
        {
            x: 1025.0,
            y: 220.5
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 1099.0,
            y: 220.5
        },
        {
            x: 1036.0,
            y: 220.5
        },
        {
            x: 1036.0,
            y: 283.0
        },
        {
            x: 1099.0,
            y: 283.0
        },
        {
            x: 1099.0,
            y: 220.5
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 63.0,
            y: 294.0
        },
        {
            x: 0.0,
            y: 294.0
        },
        {
            x: 0.0,
            y: 356.5
        },
        {
            x: 63.0,
            y: 356.5
        },
        {
            x: 63.0,
            y: 294.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 137.0,
            y: 294.0
        },
        {
            x: 74.0,
            y: 294.0
        },
        {
            x: 74.0,
            y: 356.5
        },
        {
            x: 137.0,
            y: 356.5
        },
        {
            x: 137.0,
            y: 294.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 211.0,
            y: 294.0
        },
        {
            x: 148.0,
            y: 294.0
        },
        {
            x: 148.0,
            y: 356.5
        },
        {
            x: 211.0,
            y: 356.5
        },
        {
            x: 211.0,
            y: 294.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 285.0,
            y: 294.0
        },
        {
            x: 222.0,
            y: 294.0
        },
        {
            x: 222.0,
            y: 356.5
        },
        {
            x: 285.0,
            y: 356.5
        },
        {
            x: 285.0,
            y: 294.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 359.0,
            y: 294.0
        },
        {
            x: 296.0,
            y: 294.0
        },
        {
            x: 296.0,
            y: 356.5
        },
        {
            x: 359.0,
            y: 356.5
        },
        {
            x: 359.0,
            y: 294.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 433.0,
            y: 294.0
        },
        {
            x: 370.0,
            y: 294.0
        },
        {
            x: 370.0,
            y: 356.5
        },
        {
            x: 433.0,
            y: 356.5
        },
        {
            x: 433.0,
            y: 294.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 507.0,
            y: 294.0
        },
        {
            x: 444.0,
            y: 294.0
        },
        {
            x: 444.0,
            y: 356.5
        },
        {
            x: 507.0,
            y: 356.5
        },
        {
            x: 507.0,
            y: 294.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 581.0,
            y: 294.0
        },
        {
            x: 518.0,
            y: 294.0
        },
        {
            x: 518.0,
            y: 356.5
        },
        {
            x: 581.0,
            y: 356.5
        },
        {
            x: 581.0,
            y: 294.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 655.0,
            y: 294.0
        },
        {
            x: 592.0,
            y: 294.0
        },
        {
            x: 592.0,
            y: 356.5
        },
        {
            x: 655.0,
            y: 356.5
        },
        {
            x: 655.0,
            y: 294.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 729.0,
            y: 294.0
        },
        {
            x: 666.0,
            y: 294.0
        },
        {
            x: 666.0,
            y: 356.5
        },
        {
            x: 729.0,
            y: 356.5
        },
        {
            x: 729.0,
            y: 294.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 803.0,
            y: 294.0
        },
        {
            x: 740.0,
            y: 294.0
        },
        {
            x: 740.0,
            y: 356.5
        },
        {
            x: 803.0,
            y: 356.5
        },
        {
            x: 803.0,
            y: 294.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 877.0,
            y: 294.0
        },
        {
            x: 814.0,
            y: 294.0
        },
        {
            x: 814.0,
            y: 356.5
        },
        {
            x: 877.0,
            y: 356.5
        },
        {
            x: 877.0,
            y: 294.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 951.0,
            y: 294.0
        },
        {
            x: 888.0,
            y: 294.0
        },
        {
            x: 888.0,
            y: 356.5
        },
        {
            x: 951.0,
            y: 356.5
        },
        {
            x: 951.0,
            y: 294.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 1025.0,
            y: 294.0
        },
        {
            x: 962.0,
            y: 294.0
        },
        {
            x: 962.0,
            y: 356.5
        },
        {
            x: 1025.0,
            y: 356.5
        },
        {
            x: 1025.0,
            y: 294.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 1099.0,
            y: 294.0
        },
        {
            x: 1036.0,
            y: 294.0
        },
        {
            x: 1036.0,
            y: 356.5
        },
        {
            x: 1099.0,
            y: 356.5
        },
        {
            x: 1099.0,
            y: 294.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 63.0,
            y: 367.5
        },
        {
            x: 0.0,
            y: 367.5
        },
        {
            x: 0.0,
            y: 430.0
        },
        {
            x: 63.0,
            y: 430.0
        },
        {
            x: 63.0,
            y: 367.5
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 137.0,
            y: 367.5
        },
        {
            x: 74.0,
            y: 367.5
        },
        {
            x: 74.0,
            y: 430.0
        },
        {
            x: 137.0,
            y: 430.0
        },
        {
            x: 137.0,
            y: 367.5
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 211.0,
            y: 367.5
        },
        {
            x: 148.0,
            y: 367.5
        },
        {
            x: 148.0,
            y: 430.0
        },
        {
            x: 211.0,
            y: 430.0
        },
        {
            x: 211.0,
            y: 367.5
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 285.0,
            y: 367.5
        },
        {
            x: 222.0,
            y: 367.5
        },
        {
            x: 222.0,
            y: 430.0
        },
        {
            x: 285.0,
            y: 430.0
        },
        {
            x: 285.0,
            y: 367.5
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 359.0,
            y: 367.5
        },
        {
            x: 296.0,
            y: 367.5
        },
        {
            x: 296.0,
            y: 430.0
        },
        {
            x: 359.0,
            y: 430.0
        },
        {
            x: 359.0,
            y: 367.5
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 877.0,
            y: 367.5
        },
        {
            x: 814.0,
            y: 367.5
        },
        {
            x: 814.0,
            y: 430.0
        },
        {
            x: 877.0,
            y: 430.0
        },
        {
            x: 877.0,
            y: 367.5
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 951.0,
            y: 367.5
        },
        {
            x: 888.0,
            y: 367.5
        },
        {
            x: 888.0,
            y: 430.0
        },
        {
            x: 951.0,
            y: 430.0
        },
        {
            x: 951.0,
            y: 367.5
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 1025.0,
            y: 367.5
        },
        {
            x: 962.0,
            y: 367.5
        },
        {
            x: 962.0,
            y: 430.0
        },
        {
            x: 1025.0,
            y: 430.0
        },
        {
            x: 1025.0,
            y: 367.5
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 1099.0,
            y: 367.5
        },
        {
            x: 1036.0,
            y: 367.5
        },
        {
            x: 1036.0,
            y: 430.0
        },
        {
            x: 1099.0,
            y: 430.0
        },
        {
            x: 1099.0,
            y: 367.5
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 63.0,
            y: 441.0
        },
        {
            x: 0.0,
            y: 441.0
        },
        {
            x: 0.0,
            y: 503.6
        },
        {
            x: 63.0,
            y: 503.6
        },
        {
            x: 63.0,
            y: 441.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 137.0,
            y: 441.0
        },
        {
            x: 74.0,
            y: 441.0
        },
        {
            x: 74.0,
            y: 503.6
        },
        {
            x: 137.0,
            y: 503.6
        },
        {
            x: 137.0,
            y: 441.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 211.0,
            y: 441.0
        },
        {
            x: 148.0,
            y: 441.0
        },
        {
            x: 148.0,
            y: 503.6
        },
        {
            x: 211.0,
            y: 503.6
        },
        {
            x: 211.0,
            y: 441.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 285.0,
            y: 441.0
        },
        {
            x: 222.0,
            y: 441.0
        },
        {
            x: 222.0,
            y: 503.6
        },
        {
            x: 285.0,
            y: 503.6
        },
        {
            x: 285.0,
            y: 441.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 359.0,
            y: 441.0
        },
        {
            x: 296.0,
            y: 441.0
        },
        {
            x: 296.0,
            y: 503.6
        },
        {
            x: 359.0,
            y: 503.6
        },
        {
            x: 359.0,
            y: 441.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 877.0,
            y: 441.0
        },
        {
            x: 814.0,
            y: 441.0
        },
        {
            x: 814.0,
            y: 503.6
        },
        {
            x: 877.0,
            y: 503.6
        },
        {
            x: 877.0,
            y: 441.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 951.0,
            y: 441.0
        },
        {
            x: 888.0,
            y: 441.0
        },
        {
            x: 888.0,
            y: 503.6
        },
        {
            x: 951.0,
            y: 503.6
        },
        {
            x: 951.0,
            y: 441.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 1025.0,
            y: 441.0
        },
        {
            x: 962.0,
            y: 441.0
        },
        {
            x: 962.0,
            y: 503.6
        },
        {
            x: 1025.0,
            y: 503.6
        },
        {
            x: 1025.0,
            y: 441.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 1099.0,
            y: 441.0
        },
        {
            x: 1036.0,
            y: 441.0
        },
        {
            x: 1036.0,
            y: 503.6
        },
        {
            x: 1099.0,
            y: 503.6
        },
        {
            x: 1099.0,
            y: 441.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 63.0,
            y: 514.6
        },
        {
            x: 0.0,
            y: 514.6
        },
        {
            x: 0.0,
            y: 577.1
        },
        {
            x: 63.0,
            y: 577.1
        },
        {
            x: 63.0,
            y: 514.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 137.0,
            y: 514.6
        },
        {
            x: 74.0,
            y: 514.6
        },
        {
            x: 74.0,
            y: 577.1
        },
        {
            x: 137.0,
            y: 577.1
        },
        {
            x: 137.0,
            y: 514.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 211.0,
            y: 514.6
        },
        {
            x: 148.0,
            y: 514.6
        },
        {
            x: 148.0,
            y: 577.1
        },
        {
            x: 211.0,
            y: 577.1
        },
        {
            x: 211.0,
            y: 514.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 285.0,
            y: 514.6
        },
        {
            x: 222.0,
            y: 514.6
        },
        {
            x: 222.0,
            y: 577.1
        },
        {
            x: 285.0,
            y: 577.1
        },
        {
            x: 285.0,
            y: 514.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 359.0,
            y: 514.6
        },
        {
            x: 296.0,
            y: 514.6
        },
        {
            x: 296.0,
            y: 577.1
        },
        {
            x: 359.0,
            y: 577.1
        },
        {
            x: 359.0,
            y: 514.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 877.0,
            y: 514.6
        },
        {
            x: 814.0,
            y: 514.6
        },
        {
            x: 814.0,
            y: 577.1
        },
        {
            x: 877.0,
            y: 577.1
        },
        {
            x: 877.0,
            y: 514.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 951.0,
            y: 514.6
        },
        {
            x: 888.0,
            y: 514.6
        },
        {
            x: 888.0,
            y: 577.1
        },
        {
            x: 951.0,
            y: 577.1
        },
        {
            x: 951.0,
            y: 514.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 1025.0,
            y: 514.6
        },
        {
            x: 962.0,
            y: 514.6
        },
        {
            x: 962.0,
            y: 577.1
        },
        {
            x: 1025.0,
            y: 577.1
        },
        {
            x: 1025.0,
            y: 514.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 1099.0,
            y: 514.6
        },
        {
            x: 1036.0,
            y: 514.6
        },
        {
            x: 1036.0,
            y: 577.1
        },
        {
            x: 1099.0,
            y: 577.1
        },
        {
            x: 1099.0,
            y: 514.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 63.0,
            y: 588.1
        },
        {
            x: 0.0,
            y: 588.1
        },
        {
            x: 0.0,
            y: 650.6
        },
        {
            x: 63.0,
            y: 650.6
        },
        {
            x: 63.0,
            y: 588.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 137.0,
            y: 588.1
        },
        {
            x: 74.0,
            y: 588.1
        },
        {
            x: 74.0,
            y: 650.6
        },
        {
            x: 137.0,
            y: 650.6
        },
        {
            x: 137.0,
            y: 588.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 211.0,
            y: 588.1
        },
        {
            x: 148.0,
            y: 588.1
        },
        {
            x: 148.0,
            y: 650.6
        },
        {
            x: 211.0,
            y: 650.6
        },
        {
            x: 211.0,
            y: 588.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 285.0,
            y: 588.1
        },
        {
            x: 222.0,
            y: 588.1
        },
        {
            x: 222.0,
            y: 650.6
        },
        {
            x: 285.0,
            y: 650.6
        },
        {
            x: 285.0,
            y: 588.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 359.0,
            y: 588.1
        },
        {
            x: 296.0,
            y: 588.1
        },
        {
            x: 296.0,
            y: 650.6
        },
        {
            x: 359.0,
            y: 650.6
        },
        {
            x: 359.0,
            y: 588.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 877.0,
            y: 588.1
        },
        {
            x: 814.0,
            y: 588.1
        },
        {
            x: 814.0,
            y: 650.6
        },
        {
            x: 877.0,
            y: 650.6
        },
        {
            x: 877.0,
            y: 588.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 951.0,
            y: 588.1
        },
        {
            x: 888.0,
            y: 588.1
        },
        {
            x: 888.0,
            y: 650.6
        },
        {
            x: 951.0,
            y: 650.6
        },
        {
            x: 951.0,
            y: 588.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 1025.0,
            y: 588.1
        },
        {
            x: 962.0,
            y: 588.1
        },
        {
            x: 962.0,
            y: 650.6
        },
        {
            x: 1025.0,
            y: 650.6
        },
        {
            x: 1025.0,
            y: 588.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 1099.0,
            y: 588.1
        },
        {
            x: 1036.0,
            y: 588.1
        },
        {
            x: 1036.0,
            y: 650.6
        },
        {
            x: 1099.0,
            y: 650.6
        },
        {
            x: 1099.0,
            y: 588.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 63.0,
            y: 661.6
        },
        {
            x: 0.0,
            y: 661.6
        },
        {
            x: 0.0,
            y: 724.1
        },
        {
            x: 63.0,
            y: 724.1
        },
        {
            x: 63.0,
            y: 661.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 137.0,
            y: 661.6
        },
        {
            x: 74.0,
            y: 661.6
        },
        {
            x: 74.0,
            y: 724.1
        },
        {
            x: 137.0,
            y: 724.1
        },
        {
            x: 137.0,
            y: 661.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 211.0,
            y: 661.6
        },
        {
            x: 148.0,
            y: 661.6
        },
        {
            x: 148.0,
            y: 724.1
        },
        {
            x: 211.0,
            y: 724.1
        },
        {
            x: 211.0,
            y: 661.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 285.0,
            y: 661.6
        },
        {
            x: 222.0,
            y: 661.6
        },
        {
            x: 222.0,
            y: 724.1
        },
        {
            x: 285.0,
            y: 724.1
        },
        {
            x: 285.0,
            y: 661.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 359.0,
            y: 661.6
        },
        {
            x: 296.0,
            y: 661.6
        },
        {
            x: 296.0,
            y: 724.1
        },
        {
            x: 359.0,
            y: 724.1
        },
        {
            x: 359.0,
            y: 661.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 877.0,
            y: 661.6
        },
        {
            x: 814.0,
            y: 661.6
        },
        {
            x: 814.0,
            y: 724.1
        },
        {
            x: 877.0,
            y: 724.1
        },
        {
            x: 877.0,
            y: 661.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 951.0,
            y: 661.6
        },
        {
            x: 888.0,
            y: 661.6
        },
        {
            x: 888.0,
            y: 724.1
        },
        {
            x: 951.0,
            y: 724.1
        },
        {
            x: 951.0,
            y: 661.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 1025.0,
            y: 661.6
        },
        {
            x: 962.0,
            y: 661.6
        },
        {
            x: 962.0,
            y: 724.1
        },
        {
            x: 1025.0,
            y: 724.1
        },
        {
            x: 1025.0,
            y: 661.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 1099.0,
            y: 661.6
        },
        {
            x: 1036.0,
            y: 661.6
        },
        {
            x: 1036.0,
            y: 724.1
        },
        {
            x: 1099.0,
            y: 724.1
        },
        {
            x: 1099.0,
            y: 661.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 63.0,
            y: 735.1
        },
        {
            x: 0.0,
            y: 735.1
        },
        {
            x: 0.0,
            y: 797.6
        },
        {
            x: 63.0,
            y: 797.6
        },
        {
            x: 63.0,
            y: 735.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 137.0,
            y: 735.1
        },
        {
            x: 74.0,
            y: 735.1
        },
        {
            x: 74.0,
            y: 797.6
        },
        {
            x: 137.0,
            y: 797.6
        },
        {
            x: 137.0,
            y: 735.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 211.0,
            y: 735.1
        },
        {
            x: 148.0,
            y: 735.1
        },
        {
            x: 148.0,
            y: 797.6
        },
        {
            x: 211.0,
            y: 797.6
        },
        {
            x: 211.0,
            y: 735.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 285.0,
            y: 735.1
        },
        {
            x: 222.0,
            y: 735.1
        },
        {
            x: 222.0,
            y: 797.6
        },
        {
            x: 285.0,
            y: 797.6
        },
        {
            x: 285.0,
            y: 735.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 359.0,
            y: 735.1
        },
        {
            x: 296.0,
            y: 735.1
        },
        {
            x: 296.0,
            y: 797.6
        },
        {
            x: 359.0,
            y: 797.6
        },
        {
            x: 359.0,
            y: 735.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 433.0,
            y: 735.1
        },
        {
            x: 370.0,
            y: 735.1
        },
        {
            x: 370.0,
            y: 797.6
        },
        {
            x: 433.0,
            y: 797.6
        },
        {
            x: 433.0,
            y: 735.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 507.0,
            y: 735.1
        },
        {
            x: 444.0,
            y: 735.1
        },
        {
            x: 444.0,
            y: 797.6
        },
        {
            x: 507.0,
            y: 797.6
        },
        {
            x: 507.0,
            y: 735.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 581.0,
            y: 735.1
        },
        {
            x: 518.0,
            y: 735.1
        },
        {
            x: 518.0,
            y: 797.6
        },
        {
            x: 581.0,
            y: 797.6
        },
        {
            x: 581.0,
            y: 735.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 655.0,
            y: 735.1
        },
        {
            x: 592.0,
            y: 735.1
        },
        {
            x: 592.0,
            y: 797.6
        },
        {
            x: 655.0,
            y: 797.6
        },
        {
            x: 655.0,
            y: 735.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 729.0,
            y: 735.1
        },
        {
            x: 666.0,
            y: 735.1
        },
        {
            x: 666.0,
            y: 797.6
        },
        {
            x: 729.0,
            y: 797.6
        },
        {
            x: 729.0,
            y: 735.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 803.0,
            y: 735.1
        },
        {
            x: 740.0,
            y: 735.1
        },
        {
            x: 740.0,
            y: 797.6
        },
        {
            x: 803.0,
            y: 797.6
        },
        {
            x: 803.0,
            y: 735.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 877.0,
            y: 735.1
        },
        {
            x: 814.0,
            y: 735.1
        },
        {
            x: 814.0,
            y: 797.6
        },
        {
            x: 877.0,
            y: 797.6
        },
        {
            x: 877.0,
            y: 735.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 951.0,
            y: 735.1
        },
        {
            x: 888.0,
            y: 735.1
        },
        {
            x: 888.0,
            y: 797.6
        },
        {
            x: 951.0,
            y: 797.6
        },
        {
            x: 951.0,
            y: 735.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 1025.0,
            y: 735.1
        },
        {
            x: 962.0,
            y: 735.1
        },
        {
            x: 962.0,
            y: 797.6
        },
        {
            x: 1025.0,
            y: 797.6
        },
        {
            x: 1025.0,
            y: 735.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 1099.0,
            y: 735.1
        },
        {
            x: 1036.0,
            y: 735.1
        },
        {
            x: 1036.0,
            y: 797.6
        },
        {
            x: 1099.0,
            y: 797.6
        },
        {
            x: 1099.0,
            y: 735.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 63.0,
            y: 808.6
        },
        {
            x: 0.0,
            y: 808.6
        },
        {
            x: 0.0,
            y: 871.1
        },
        {
            x: 63.0,
            y: 871.1
        },
        {
            x: 63.0,
            y: 808.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 137.0,
            y: 808.6
        },
        {
            x: 74.0,
            y: 808.6
        },
        {
            x: 74.0,
            y: 871.1
        },
        {
            x: 137.0,
            y: 871.1
        },
        {
            x: 137.0,
            y: 808.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 211.0,
            y: 808.6
        },
        {
            x: 148.0,
            y: 808.6
        },
        {
            x: 148.0,
            y: 871.1
        },
        {
            x: 211.0,
            y: 871.1
        },
        {
            x: 211.0,
            y: 808.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 285.0,
            y: 808.6
        },
        {
            x: 222.0,
            y: 808.6
        },
        {
            x: 222.0,
            y: 871.1
        },
        {
            x: 285.0,
            y: 871.1
        },
        {
            x: 285.0,
            y: 808.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 359.0,
            y: 808.6
        },
        {
            x: 296.0,
            y: 808.6
        },
        {
            x: 296.0,
            y: 871.1
        },
        {
            x: 359.0,
            y: 871.1
        },
        {
            x: 359.0,
            y: 808.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 433.0,
            y: 808.6
        },
        {
            x: 370.0,
            y: 808.6
        },
        {
            x: 370.0,
            y: 871.1
        },
        {
            x: 433.0,
            y: 871.1
        },
        {
            x: 433.0,
            y: 808.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 507.0,
            y: 808.6
        },
        {
            x: 444.0,
            y: 808.6
        },
        {
            x: 444.0,
            y: 871.1
        },
        {
            x: 507.0,
            y: 871.1
        },
        {
            x: 507.0,
            y: 808.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 581.0,
            y: 808.6
        },
        {
            x: 518.0,
            y: 808.6
        },
        {
            x: 518.0,
            y: 871.1
        },
        {
            x: 581.0,
            y: 871.1
        },
        {
            x: 581.0,
            y: 808.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 655.0,
            y: 808.6
        },
        {
            x: 592.0,
            y: 808.6
        },
        {
            x: 592.0,
            y: 871.1
        },
        {
            x: 655.0,
            y: 871.1
        },
        {
            x: 655.0,
            y: 808.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 729.0,
            y: 808.6
        },
        {
            x: 666.0,
            y: 808.6
        },
        {
            x: 666.0,
            y: 871.1
        },
        {
            x: 729.0,
            y: 871.1
        },
        {
            x: 729.0,
            y: 808.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 803.0,
            y: 808.6
        },
        {
            x: 740.0,
            y: 808.6
        },
        {
            x: 740.0,
            y: 871.1
        },
        {
            x: 803.0,
            y: 871.1
        },
        {
            x: 803.0,
            y: 808.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 877.0,
            y: 808.6
        },
        {
            x: 814.0,
            y: 808.6
        },
        {
            x: 814.0,
            y: 871.1
        },
        {
            x: 877.0,
            y: 871.1
        },
        {
            x: 877.0,
            y: 808.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 951.0,
            y: 808.6
        },
        {
            x: 888.0,
            y: 808.6
        },
        {
            x: 888.0,
            y: 871.1
        },
        {
            x: 951.0,
            y: 871.1
        },
        {
            x: 951.0,
            y: 808.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 1025.0,
            y: 808.6
        },
        {
            x: 962.0,
            y: 808.6
        },
        {
            x: 962.0,
            y: 871.1
        },
        {
            x: 1025.0,
            y: 871.1
        },
        {
            x: 1025.0,
            y: 808.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 1099.0,
            y: 808.6
        },
        {
            x: 1036.0,
            y: 808.6
        },
        {
            x: 1036.0,
            y: 871.1
        },
        {
            x: 1099.0,
            y: 871.1
        },
        {
            x: 1099.0,
            y: 808.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 63.0,
            y: 882.1
        },
        {
            x: 0.0,
            y: 882.1
        },
        {
            x: 0.0,
            y: 944.6
        },
        {
            x: 63.0,
            y: 944.6
        },
        {
            x: 63.0,
            y: 882.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 137.0,
            y: 882.1
        },
        {
            x: 74.0,
            y: 882.1
        },
        {
            x: 74.0,
            y: 944.6
        },
        {
            x: 137.0,
            y: 944.6
        },
        {
            x: 137.0,
            y: 882.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 211.0,
            y: 882.1
        },
        {
            x: 148.0,
            y: 882.1
        },
        {
            x: 148.0,
            y: 944.6
        },
        {
            x: 211.0,
            y: 944.6
        },
        {
            x: 211.0,
            y: 882.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 285.0,
            y: 882.1
        },
        {
            x: 222.0,
            y: 882.1
        },
        {
            x: 222.0,
            y: 944.6
        },
        {
            x: 285.0,
            y: 944.6
        },
        {
            x: 285.0,
            y: 882.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 359.0,
            y: 882.1
        },
        {
            x: 296.0,
            y: 882.1
        },
        {
            x: 296.0,
            y: 944.6
        },
        {
            x: 359.0,
            y: 944.6
        },
        {
            x: 359.0,
            y: 882.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 433.0,
            y: 882.1
        },
        {
            x: 370.0,
            y: 882.1
        },
        {
            x: 370.0,
            y: 944.6
        },
        {
            x: 433.0,
            y: 944.6
        },
        {
            x: 433.0,
            y: 882.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 507.0,
            y: 882.1
        },
        {
            x: 444.0,
            y: 882.1
        },
        {
            x: 444.0,
            y: 944.6
        },
        {
            x: 507.0,
            y: 944.6
        },
        {
            x: 507.0,
            y: 882.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 581.0,
            y: 882.1
        },
        {
            x: 518.0,
            y: 882.1
        },
        {
            x: 518.0,
            y: 944.6
        },
        {
            x: 581.0,
            y: 944.6
        },
        {
            x: 581.0,
            y: 882.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 655.0,
            y: 882.1
        },
        {
            x: 592.0,
            y: 882.1
        },
        {
            x: 592.0,
            y: 944.6
        },
        {
            x: 655.0,
            y: 944.6
        },
        {
            x: 655.0,
            y: 882.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 729.0,
            y: 882.1
        },
        {
            x: 666.0,
            y: 882.1
        },
        {
            x: 666.0,
            y: 944.6
        },
        {
            x: 729.0,
            y: 944.6
        },
        {
            x: 729.0,
            y: 882.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 803.0,
            y: 882.1
        },
        {
            x: 740.0,
            y: 882.1
        },
        {
            x: 740.0,
            y: 944.6
        },
        {
            x: 803.0,
            y: 944.6
        },
        {
            x: 803.0,
            y: 882.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 877.0,
            y: 882.1
        },
        {
            x: 814.0,
            y: 882.1
        },
        {
            x: 814.0,
            y: 944.6
        },
        {
            x: 877.0,
            y: 944.6
        },
        {
            x: 877.0,
            y: 882.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 951.0,
            y: 882.1
        },
        {
            x: 888.0,
            y: 882.1
        },
        {
            x: 888.0,
            y: 944.6
        },
        {
            x: 951.0,
            y: 944.6
        },
        {
            x: 951.0,
            y: 882.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 1025.0,
            y: 882.1
        },
        {
            x: 962.0,
            y: 882.1
        },
        {
            x: 962.0,
            y: 944.6
        },
        {
            x: 1025.0,
            y: 944.6
        },
        {
            x: 1025.0,
            y: 882.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 1099.0,
            y: 882.1
        },
        {
            x: 1036.0,
            y: 882.1
        },
        {
            x: 1036.0,
            y: 944.6
        },
        {
            x: 1099.0,
            y: 944.6
        },
        {
            x: 1099.0,
            y: 882.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 63.0,
            y: 955.6
        },
        {
            x: 0.0,
            y: 955.6
        },
        {
            x: 0.0,
            y: 1018.1
        },
        {
            x: 63.0,
            y: 1018.1
        },
        {
            x: 63.0,
            y: 955.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 137.0,
            y: 955.6
        },
        {
            x: 74.0,
            y: 955.6
        },
        {
            x: 74.0,
            y: 1018.1
        },
        {
            x: 137.0,
            y: 1018.1
        },
        {
            x: 137.0,
            y: 955.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 211.0,
            y: 955.6
        },
        {
            x: 148.0,
            y: 955.6
        },
        {
            x: 148.0,
            y: 1018.1
        },
        {
            x: 211.0,
            y: 1018.1
        },
        {
            x: 211.0,
            y: 955.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 285.0,
            y: 955.6
        },
        {
            x: 222.0,
            y: 955.6
        },
        {
            x: 222.0,
            y: 1018.1
        },
        {
            x: 285.0,
            y: 1018.1
        },
        {
            x: 285.0,
            y: 955.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 359.0,
            y: 955.6
        },
        {
            x: 296.0,
            y: 955.6
        },
        {
            x: 296.0,
            y: 1018.1
        },
        {
            x: 359.0,
            y: 1018.1
        },
        {
            x: 359.0,
            y: 955.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 433.0,
            y: 955.6
        },
        {
            x: 370.0,
            y: 955.6
        },
        {
            x: 370.0,
            y: 1018.1
        },
        {
            x: 433.0,
            y: 1018.1
        },
        {
            x: 433.0,
            y: 955.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 507.0,
            y: 955.6
        },
        {
            x: 444.0,
            y: 955.6
        },
        {
            x: 444.0,
            y: 1018.1
        },
        {
            x: 507.0,
            y: 1018.1
        },
        {
            x: 507.0,
            y: 955.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 581.0,
            y: 955.6
        },
        {
            x: 518.0,
            y: 955.6
        },
        {
            x: 518.0,
            y: 1018.1
        },
        {
            x: 581.0,
            y: 1018.1
        },
        {
            x: 581.0,
            y: 955.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 655.0,
            y: 955.6
        },
        {
            x: 592.0,
            y: 955.6
        },
        {
            x: 592.0,
            y: 1018.1
        },
        {
            x: 655.0,
            y: 1018.1
        },
        {
            x: 655.0,
            y: 955.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 729.0,
            y: 955.6
        },
        {
            x: 666.0,
            y: 955.6
        },
        {
            x: 666.0,
            y: 1018.1
        },
        {
            x: 729.0,
            y: 1018.1
        },
        {
            x: 729.0,
            y: 955.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 803.0,
            y: 955.6
        },
        {
            x: 740.0,
            y: 955.6
        },
        {
            x: 740.0,
            y: 1018.1
        },
        {
            x: 803.0,
            y: 1018.1
        },
        {
            x: 803.0,
            y: 955.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 877.0,
            y: 955.6
        },
        {
            x: 814.0,
            y: 955.6
        },
        {
            x: 814.0,
            y: 1018.1
        },
        {
            x: 877.0,
            y: 1018.1
        },
        {
            x: 877.0,
            y: 955.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 951.0,
            y: 955.6
        },
        {
            x: 888.0,
            y: 955.6
        },
        {
            x: 888.0,
            y: 1018.1
        },
        {
            x: 951.0,
            y: 1018.1
        },
        {
            x: 951.0,
            y: 955.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 1025.0,
            y: 955.6
        },
        {
            x: 962.0,
            y: 955.6
        },
        {
            x: 962.0,
            y: 1018.1
        },
        {
            x: 1025.0,
            y: 1018.1
        },
        {
            x: 1025.0,
            y: 955.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 1099.0,
            y: 955.6
        },
        {
            x: 1036.0,
            y: 955.6
        },
        {
            x: 1036.0,
            y: 1018.1
        },
        {
            x: 1099.0,
            y: 1018.1
        },
        {
            x: 1099.0,
            y: 955.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 63.0,
            y: 1029.1
        },
        {
            x: 0.0,
            y: 1029.1
        },
        {
            x: 0.0,
            y: 1091.6
        },
        {
            x: 63.0,
            y: 1091.6
        },
        {
            x: 63.0,
            y: 1029.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 137.0,
            y: 1029.1
        },
        {
            x: 74.0,
            y: 1029.1
        },
        {
            x: 74.0,
            y: 1091.6
        },
        {
            x: 137.0,
            y: 1091.6
        },
        {
            x: 137.0,
            y: 1029.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 211.0,
            y: 1029.1
        },
        {
            x: 148.0,
            y: 1029.1
        },
        {
            x: 148.0,
            y: 1091.6
        },
        {
            x: 211.0,
            y: 1091.6
        },
        {
            x: 211.0,
            y: 1029.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 285.0,
            y: 1029.1
        },
        {
            x: 222.0,
            y: 1029.1
        },
        {
            x: 222.0,
            y: 1091.6
        },
        {
            x: 285.0,
            y: 1091.6
        },
        {
            x: 285.0,
            y: 1029.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 359.0,
            y: 1029.1
        },
        {
            x: 296.0,
            y: 1029.1
        },
        {
            x: 296.0,
            y: 1091.6
        },
        {
            x: 359.0,
            y: 1091.6
        },
        {
            x: 359.0,
            y: 1029.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 433.0,
            y: 1029.1
        },
        {
            x: 370.0,
            y: 1029.1
        },
        {
            x: 370.0,
            y: 1091.6
        },
        {
            x: 433.0,
            y: 1091.6
        },
        {
            x: 433.0,
            y: 1029.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 507.0,
            y: 1029.1
        },
        {
            x: 444.0,
            y: 1029.1
        },
        {
            x: 444.0,
            y: 1091.6
        },
        {
            x: 507.0,
            y: 1091.6
        },
        {
            x: 507.0,
            y: 1029.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 581.0,
            y: 1029.1
        },
        {
            x: 518.0,
            y: 1029.1
        },
        {
            x: 518.0,
            y: 1091.6
        },
        {
            x: 581.0,
            y: 1091.6
        },
        {
            x: 581.0,
            y: 1029.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 655.0,
            y: 1029.1
        },
        {
            x: 592.0,
            y: 1029.1
        },
        {
            x: 592.0,
            y: 1091.6
        },
        {
            x: 655.0,
            y: 1091.6
        },
        {
            x: 655.0,
            y: 1029.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 729.0,
            y: 1029.1
        },
        {
            x: 666.0,
            y: 1029.1
        },
        {
            x: 666.0,
            y: 1091.6
        },
        {
            x: 729.0,
            y: 1091.6
        },
        {
            x: 729.0,
            y: 1029.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 803.0,
            y: 1029.1
        },
        {
            x: 740.0,
            y: 1029.1
        },
        {
            x: 740.0,
            y: 1091.6
        },
        {
            x: 803.0,
            y: 1091.6
        },
        {
            x: 803.0,
            y: 1029.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 877.0,
            y: 1029.1
        },
        {
            x: 814.0,
            y: 1029.1
        },
        {
            x: 814.0,
            y: 1091.6
        },
        {
            x: 877.0,
            y: 1091.6
        },
        {
            x: 877.0,
            y: 1029.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 951.0,
            y: 1029.1
        },
        {
            x: 888.0,
            y: 1029.1
        },
        {
            x: 888.0,
            y: 1091.6
        },
        {
            x: 951.0,
            y: 1091.6
        },
        {
            x: 951.0,
            y: 1029.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 1025.0,
            y: 1029.1
        },
        {
            x: 962.0,
            y: 1029.1
        },
        {
            x: 962.0,
            y: 1091.6
        },
        {
            x: 1025.0,
            y: 1091.6
        },
        {
            x: 1025.0,
            y: 1029.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 1099.0,
            y: 1029.1
        },
        {
            x: 1036.0,
            y: 1029.1
        },
        {
            x: 1036.0,
            y: 1091.6
        },
        {
            x: 1099.0,
            y: 1091.6
        },
        {
            x: 1099.0,
            y: 1029.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 803.0,
            y: 367.5
        },
        {
            x: 740.0,
            y: 367.5
        },
        {
            x: 740.0,
            y: 430.0
        },
        {
            x: 803.0,
            y: 430.0
        },
        {
            x: 803.0,
            y: 367.5
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 803.0,
            y: 441.0
        },
        {
            x: 740.0,
            y: 441.0
        },
        {
            x: 740.0,
            y: 503.6
        },
        {
            x: 803.0,
            y: 503.6
        },
        {
            x: 803.0,
            y: 441.0
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 803.0,
            y: 514.6
        },
        {
            x: 740.0,
            y: 514.6
        },
        {
            x: 740.0,
            y: 577.1
        },
        {
            x: 803.0,
            y: 577.1
        },
        {
            x: 803.0,
            y: 514.6
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 803.0,
            y: 588.1
        },
        {
            x: 740.0,
            y: 588.1
        },
        {
            x: 740.0,
            y: 650.6
        },
        {
            x: 803.0,
            y: 650.6
        },
        {
            x: 803.0,
            y: 588.1
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 803.0,
            y: 661.4
        },
        {
            x: 740.0,
            y: 661.4
        },
        {
            x: 740.0,
            y: 723.9
        },
        {
            x: 803.0,
            y: 723.9
        },
        {
            x: 803.0,
            y: 661.4
        },
    ], {
        fill: green
    }))



    canvas.add(new fabric.Polygon([{
            x: 726.5,
            y: 724.1
        },
        {
            x: 370.0,
            y: 724.1
        },
        {
            x: 370.0,
            y: 367.5
        },
        {
            x: 726.5,
            y: 367.5
        },
        {
            x: 726.5,
            y: 724.1
        },
    ], {
        fill: green
    }))



    canvas.forEachObject(function(obj) {
        obj.set({
            lockScalingX: true,
            lockScalingY: true,
            lockMovementX: true,
            lockMovementY: true,
            hasBorders: false,
            hasControls: false,
            lockUniScaling: true,
        });
    });
</script>
<script>
    canvas.setDimensions({
        width: 310,
        height: 310
    })
    canvas.setZoom(0.28)
</script>
<script>
    var activeObjectsCount = 0;

    function getActiveItemsCount() {
        activeObjectsCount = 0;
        canvas.forEachObject(function(obj) {
            if (obj.fill == purple) {
                activeObjectsCount++;
            }
        });
        console.log(activeObjectsCount);
    }
    canvas.on('selection:created', function(ev) {
        getActiveItemsCount()
    })

    function clearSelectedLands() {
        canvas.forEachObject(function(obj) {
            obj.set({
                fill: green,
                selectable: true,
            });

        });
        canvas.renderAll();
        activeObjectsCount = 0;
        console.log(activeObjectsCount);
    }
    $('button_clear').click(function() {

        clearSelectedLands();
    });
</script>
<?php /**PATH C:\Users\Dante\OneDrive\Desktop\Folders\partners\resources\views/components/map.blade.php ENDPATH**/ ?>