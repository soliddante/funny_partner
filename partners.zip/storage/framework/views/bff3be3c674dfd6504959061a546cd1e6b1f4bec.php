<header>
    <nav class="mt-[24px] px-[24px] flex justify-between items-center <?php echo e($navClass ?? ''); ?>">
        <a href="<?php echo e(route('.index')); ?>">
            <img src="img/logo.png" class="w-[123px]" alt="">
        </a>
        <right>
            <menuicon>
                <img src="img/menu.svg" class="w-[40px]">
            </menuicon>
        </right>
    </nav>
</header>
<?php /**PATH C:\Users\Dante\OneDrive\Desktop\Folders\partners\resources\views/components/layouts/header.blade.php ENDPATH**/ ?>